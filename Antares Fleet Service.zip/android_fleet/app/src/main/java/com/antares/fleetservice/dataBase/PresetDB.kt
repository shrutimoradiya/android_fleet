package com.antares.fleetservice.dataBase

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.antares.fleetservice.model.presentProduct.PresentProductCategories
import com.antares.fleetservice.model.users.Users

class PresetDB(context: Context?) : SQLiteOpenHelper(context, "Preset.db", null, 1) {

    // table name
    private val preset = "Preset"

    // row
    private val id          : String = "id"
    private val name        : String = "name"
    private val image       : String = "image"
    private val orderBy     : String = "orderBy"
    private val isVisible   : String = "isVisible"
    private val isDisplay   : String = "isDisplay"
    private val stepType    : String = "stepType"
    private val deleted     : String = "deleted"

    override fun onCreate(db: SQLiteDatabase?) {
        db?.execSQL(
            "create table "
                    + preset + " ("
                    + id           + " TEXT, "
                    + name         + " TEXT, "
                    + image        + " TEXT, "
                    + orderBy      + " TEXT, "
                    + isVisible    + " TEXT, "
                    + isDisplay    + " TEXT, "
                    + stepType     + " TEXT, "
                    + deleted      + " TEXT)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        println("oldVersion = $oldVersion | newVersion = $newVersion")
    }

    fun addData(data: PresentProductCategories): Boolean {
        val db = writableDatabase
        val values = ContentValues()
        values.put(id          , data.id          )
        values.put(name        , data.name        )
        values.put(image       , data.image       )
        values.put(orderBy     , data.orderBy     )
        values.put(isVisible   , data.isVisible   )
        values.put(isDisplay   , data.isDisplay   )
        values.put(stepType    , data.stepType    )
        values.put(deleted     , data.deleted     )

        val result = db.insert(preset, null, values)
        db.close()
        return result != -1L
    }

    fun viewData(): ArrayList<PresentProductCategories> {

        val cursor: Cursor = writableDatabase.rawQuery("select * from $preset", null)

        val arrayList = ArrayList<PresentProductCategories>()

        if (cursor.count != 0) {
            while (cursor.moveToNext()) {

                val temp = PresentProductCategories()

                temp.id           = cursor.getInt(0)
                temp.name         = cursor.getString(1)
                temp.image        = cursor.getString(2)
                temp.orderBy      = cursor.getString(3)
                temp.isVisible    = cursor.getString(4)
                temp.isDisplay    = cursor.getString(5)
                temp.stepType     = cursor.getString(6)
                temp.deleted      = cursor.getString(7)

                arrayList.add(temp)
            }
        }

        return arrayList
    }

    fun deleteData() {
        val db = writableDatabase
        db.execSQL("delete from $preset")
        db.close()
    }
}