package com.antares.fleetservice.dataBase

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.antares.fleetservice.model.ApiCallModel
import com.antares.fleetservice.model.mechanic.event.*
import com.antares.fleetservice.model.travel.TravelDetailEvent
import com.antares.fleetservice.model.travel.TravelDetailJson
import com.antares.fleetservice.model.travel.TravelDetailLead
import com.antares.fleetservice.model.travel.TravelDetailWorkPlan
import com.antares.fleetservice.utils.Constant

class ApiCallLeftDB(context: Context?) : SQLiteOpenHelper(context, "ApiCallLeftDB.db", null, 1) {

    // table name
    private val apiCallLeft = "ApiCallLeft"

    // row
    private val id: String = "id"
    private val api: String = "api"
    private val map: String = "map"

    override fun onCreate(db: SQLiteDatabase?) {
        db?.execSQL(
            "create table "
                    + apiCallLeft + " ("
                    + id  + " TEXT, "
                    + api + " TEXT, "
                    + map + " TEXT) "
        )
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        println("oldVersion = $oldVersion | newVersion = $newVersion")
    }


    fun addData(context:Context, apiData: String, mapData: String): Boolean {

        val db = writableDatabase
        val values = ContentValues()

        if (Constant.getData(context, Constant.SAVE_ID) == null) {
            Constant.saveData(context, Constant.SAVE_ID, 0)
        }

        Constant.saveData(
            context,
            Constant.SAVE_ID,
            (Constant.getData(context, Constant.SAVE_ID) + 1)
        )

        values.put(id, Constant.getData(context, Constant.SAVE_ID))
        values.put(api, apiData)
        values.put(map, mapData)


        val result = db.insert(apiCallLeft, null, values)
        if (db.isOpen) {
            db.close()
        }
        return result != -1L
    }

    fun viewData(): ArrayList<ApiCallModel> {

        val cursor: Cursor = writableDatabase.rawQuery(
            "select * from $apiCallLeft", null
        )

       val data = ArrayList<ApiCallModel>()

        if (cursor.count != 0) {
            while (cursor.moveToNext()) {

                val temp = ApiCallModel()

                temp.id = cursor.getInt(0)
                temp.api = cursor.getString(1)
                temp.map = cursor.getString(2)

                data.add(temp)
            }
        }

        cursor.close()

        return data
    }


    fun deleteData(idTemp: Int): Boolean {

        val db = writableDatabase

        val isDeleted = db.delete(
            apiCallLeft,
            "$id= ? \n", arrayOf(idTemp.toString())
        )
        db.close()
        return isDeleted != 0
    }
}