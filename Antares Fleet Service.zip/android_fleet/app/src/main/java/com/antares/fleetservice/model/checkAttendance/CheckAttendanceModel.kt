package com.antares.fleetservice.model.checkAttendance

import com.google.gson.annotations.SerializedName

data class CheckAttendanceModel(
    @SerializedName("code"          )   var     code        : Int?          = null,
    @SerializedName("attendance"    )   var     attendance  : Attendance?   = Attendance()
)
