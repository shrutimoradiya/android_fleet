package com.antares.fleetservice.model.carList

import com.google.gson.annotations.SerializedName

data class CarJson(
    @SerializedName("cars"  )   var     cars    : ArrayList<Cars> = arrayListOf()
)
