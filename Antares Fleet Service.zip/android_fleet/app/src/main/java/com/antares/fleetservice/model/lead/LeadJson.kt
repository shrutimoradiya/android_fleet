package com.antares.fleetservice.model.lead

import com.google.gson.annotations.SerializedName

data class LeadJson(
    @SerializedName("preset_categories" )   var     presetCategories    : ArrayList<LeadPresetCategory?>? = null,
    @SerializedName("cars"              )   var     cars                : ArrayList<LeadCar?>? = null
)
