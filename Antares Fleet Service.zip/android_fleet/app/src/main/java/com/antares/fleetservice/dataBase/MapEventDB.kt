package com.antares.fleetservice.dataBase

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.antares.fleetservice.model.mechanic.event.*
import com.antares.fleetservice.model.travel.TravelDetailEvent
import com.antares.fleetservice.model.travel.TravelDetailJson
import com.antares.fleetservice.model.travel.TravelDetailLead
import com.antares.fleetservice.model.travel.TravelDetailWorkPlan

class MapEventDB(context: Context?) : SQLiteOpenHelper(context, "MapEvent.db", null, 1) {

    // table name
    private val mapEvent = "MapEvent"
    private val travelDetailEvent = "TravelDetailEvent"
    private val travelDetailLead = "TravelDetailLead"
    private val travelDetailWorkPlan = "TravelDetailWorkPlan"


    // row
    private val travelEvent: String = "travelEvent"
    private val travelLead: String = "travelLead"
    private val breakDetail: String = "breakDetail"
    private val workPlan: String = "workPlan"
    private val eventId: String = "eventId"

    private val id: String = "id"
    private val leadId: String = "leadId"
    private val title: String = "title"
    private val description: String = "description"
    private val contactId: String = "contactId"
    private val createdBy: String = "createdBy"
    private val parentEventId: String = "parentEventId"
    private val calendarWorkPlanId: String = "calendarWorkPlanId"
    private val customerWorkPlanId: String = "customerWorkPlanId"
    private val objectType: String = "objectType"
    private val actionDate: String = "actionDate"
    private val mobileStationId: String = "mobileStationId"
    private val fileName: String = "fileName"
    private val fileLocation: String = "fileLocation"
    private val completed: String = "completed"
    private val assignTo: String = "assignTo"
    private val startDate: String = "startDate"
    private val endDate: String = "endDate"
    private val workWithUserId: String = "workWithUserId"
    private val appointmentRepeatCount: String = "appointmentRepeatCount"
    private val appointmentRepeatOption: String = "appointmentRepeatOption"
    private val remindCron: String = "remindCron"
    private val repeatAppointmentMainId: String = "repeatAppointmentMainId"
    private val isVisible: String = "isVisible"
    private val parentId: String = "parentId"
    private val isAllday: String = "isAllday"
    private val eventNotification: String = "eventNotification"
    private val notificationDuration: String = "notificationDuration"
    private val notificationOption: String = "notificationOption"
    private val mainEventId: String = "mainEventId"
    private val workWithIds: String = "workWithIds"
    private val isConfirm: String = "isConfirm"
    private val inviteEmail: String = "inviteEmail"
    private val callAppointment: String = "callAppointment"
    private val appointmentRequestFrom: String = "appointmentRequestFrom"
    private val isPending: String = "isPending"
    private val deleted: String = "deleted"
    private val confirmedAt: String = "confirmedAt"
    private val isClosed: String = "isClosed"
    private val closedAt: String = "closedAt"
    private val travelStart: String = "travelStart"
    private val travelEnd: String = "travelEnd"
    private val travelTime: String = "travelTime"
    private val totalKm: String = "totalKm"
    private val isEventStart: String = "isEventStart"
    private val isTravelCompleted: String = "isTravelCompleted"
    private val towRequestAccepted: String = "towRequestAccepted"
    private val isPicked: String = "isPicked"
    private val isManualReport: String = "isManualReport"
    private val isPauseTravel: String = "isPauseTravel"
    private val workStartTime: String = "workStartTime"
    private val workEndTime: String = "workEndTime"
    private val mechanicWorkStartTime: String = "mechanicWorkStartTime"
    private val mechanicWorkEndTime: String = "mechanicWorkEndTime"
    private val mechanicTravelStartTime: String = "mechanicTravelStartTime"
    private val mechanicTravelEndTime: String = "mechanicTravelEndTime"
    private val mechanicTravelBreakStart: String = "mechanicTravelBreakStart"
    private val mechanicTravelBreakEnd: String = "mechanicTravelBreakEnd"
    private val mechanicTravelRestart: String = "mechanicTravelRestart"
    private val mobileStationLat: String = "mobileStationLat"
    private val mobileStationLon: String = "mobileStationLon"
    private val sourceAddress: String = "sourceAddress"
    private val destinationAddress: String = "destinationAddress"
    private val dropAddress: String = "dropAddress"
    private val currentStep: String = "currentStep"
    private val closeReason: String = "closeReason"
    private val previousEventId: String = "previousEventId"
    private val isDayClose: String = "isDayClose"
    private val isReportConfirm: String = "isReportConfirm"
    private val isEventReopen: String = "isEventReopen"
    private val isReminderSent: String = "isReminderSent"
    private val carId: String = "carId"
    private val reportConfirmAt: String = "reportConfirmAt"
    private val reportConfirmBy: String = "reportConfirmBy"
    private val createdAt: String = "createdAt"
    private val updatedAt: String = "updatedAt"
    private val deletedAt: String = "deletedAt"
    private val userName: String = "userName"
    private val calendarColor: String = "calendarColor"
    private val businessName: String = "businessName"
    private val firstName: String = "firstName"
    private val lastName: String = "lastName"
    private val email: String = "email"
    private val mobile: String = "mobile"
    private val displayId: String = "displayId"
    private val numberPlate: String = "numberPlate"
    private val statusId: String = "statusId"
    private val priority: String = "priority"
    private val leadTypeId: String = "leadTypeId"
    private val orderId: String = "orderId"
    private val lat: String = "lat"
    private val lon: String = "lon"
    private val address: String = "address"
    private val dropLat: String = "dropLat"
    private val dropLon: String = "dropLon"
    private val enterKm: String = "enterKm"
    private val calendarWorkDisplayId: String = "calendarWorkDisplayId"
    private val note: String = "note"
    private val isNoteRead: String = "isNoteRead"
    private val sedeName: String = "sedeName"
    private val officeCalendarColor: String = "officeCalendarColor"
    private val makeName: String = "makeName"
    private val modelName: String = "modelName"

    private val parentLeadId: String = "parentLeadId"
    private val customerDisplayId: String = "customerDisplayId"
    private val customerDocumentId: String = "customerDocumentId"
    private val lastUpdatedBy: String = "lastUpdatedBy"
    private val leadTitle: String = "leadTitle"
    private val pipelineId: String = "pipelineId"
    private val phaseId: String = "phaseId"
    private val ownerId: String = "ownerId"
    private val leadValue: String = "leadValue"
    private val isArchived: String = "isArchived"
    private val billingAddressId: String = "billingAddressId"
    private val shippingAddressId: String = "shippingAddressId"
    private val officeLocationId: String = "officeLocationId"
    private val orderStatusId: String = "orderStatusId"
    private val trafficSource: String = "trafficSource"
    private val requestUrl: String = "requestUrl"
    private val mechanicId: String = "mechanicId"
    private val renewCounter: String = "renewCounter"
    private val accessToken: String = "accessToken"
    private val updatedBy: String = "updatedBy"
    private val locationType: String = "locationType"
    private val warehouseInstruction: String = "warehouseInstruction"
    private val stockNote: String = "stockNote"
    private val itemNote: String = "itemNote"
    private val isProblemIdentify: String = "isProblemIdentify"
    private val isWarningLight: String = "isWarningLight"
    private val warningLights: String = "warningLights"
    private val testCentral: String = "testCentral"
    private val isCreatedByMechanic: String = "isCreatedByMechanic"
    private val configuredBy: String = "configuredBy"
    private val isInspection: String = "isInspection"
    private val isNew: String = "isNew"
    private val isRead: String = "isRead"
    private val isManual: String = "isManual"
    private val isUrgent: String = "isUrgent"
    private val isFutureRequest: String = "isFutureRequest"
    private val sosIcon: String = "sosIcon"
    private val reportType: String = "reportType"
    private val reportDescription: String = "reportDescription"
    private val sosRequestId: String = "sosRequestId"
    private val configuredByLocationId: String = "configuredByLocationId"
    private val isWheelChange: String = "isWheelChange"
    private val isAuthorization: String = "isAuthorization"
    private val authorizationCode: String = "authorizationCode"
    private val driverCode: String = "driverCode"
    private val isGa: String = "isGa"
    private val offerPdf: String = "offerPdf"
    private val offerCreatedBy: String = "offerCreatedBy"
    private val emojiSelection: String = "emojiSelection"
    private val fullName: String = "fullName"
    private val ownerName: String = "ownerName"
    private val ownerEmail: String = "ownerEmail"
    private val ownerMobile: String = "ownerMobile"
    private val createdByName: String = "createdByName"
    private val configuredByName: String = "configuredByName"
    private val pipelineName: String = "pipelineName"
    private val phaseName: String = "phaseName"
    private val locationName: String = "locationName"
    private val locationAddress: String = "locationAddress"
    private val statusName: String = "statusName"
    private val vin: String = "vin"
    private val locationId: String = "locationId"
    private val appointmentCount: String = "appointmentCount"

    private val parentWorkPlanId: String = "parentWorkPlanId"
    private val customerId: String = "customerId"
    private val date: String = "date"
    private val isEmailSend: String = "isEmailSend"
    private val emailSentDate: String = "emailSentDate"
    private val icon: String = "icon"
    private val inchargeId: String = "inchargeId"
    private val isOrderNew: String = "isOrderNew"
    private val isMessageRead: String = "isMessageRead"
    private val createdByLocationId: String = "createdByLocationId"
    private val configuredAt: String = "configuredAt"
    private val noteReadAt: String = "noteReadAt"
    private val customerName: String = "customerName"
    private val inchargeName: String = "inchargeName"
    private val leadCount: String = "leadCount"

    override fun onCreate(db: SQLiteDatabase?) {
        db?.execSQL(
            "create table "
                    + mapEvent + " ("
                    + travelEvent + " TEXT, "
                    + travelLead + " TEXT, "
                    + breakDetail + " TEXT, "
                    + workPlan + " TEXT, "
                    + eventId + " TEXT) "
        )

        db?.execSQL(
            "create table "
                    + travelDetailEvent + " ("
                    + id + " TEXT, "
                    + leadId + " TEXT, "
                    + title + " TEXT, "
                    + description + " TEXT, "
                    + contactId + " TEXT, "
                    + createdBy + " TEXT, "
                    + parentEventId + " TEXT, "
                    + calendarWorkPlanId + " TEXT, "
                    + customerWorkPlanId + " TEXT, "
                    + objectType + " TEXT, "
                    + actionDate + " TEXT, "
                    + mobileStationId + " TEXT, "
                    + fileName + " TEXT, "
                    + fileLocation + " TEXT, "
                    + completed + " TEXT, "
                    + assignTo + " TEXT, "
                    + startDate + " TEXT, "
                    + endDate + " TEXT, "
                    + workWithUserId + " TEXT, "
                    + appointmentRepeatCount + " TEXT, "
                    + appointmentRepeatOption + " TEXT, "
                    + remindCron + " TEXT, "
                    + repeatAppointmentMainId + " TEXT, "
                    + isVisible + " TEXT, "
                    + parentId + " TEXT, "
                    + isAllday + " TEXT, "
                    + eventNotification + " TEXT, "
                    + notificationDuration + " TEXT, "
                    + notificationOption + " TEXT, "
                    + mainEventId + " TEXT, "
                    + workWithIds + " TEXT, "
                    + isConfirm + " TEXT, "
                    + inviteEmail + " TEXT, "
                    + callAppointment + " TEXT, "
                    + appointmentRequestFrom + " TEXT, "
                    + isPending + " TEXT, "
                    + deleted + " TEXT, "
                    + confirmedAt + " TEXT, "
                    + isClosed + " TEXT, "
                    + closedAt + " TEXT, "
                    + travelStart + " TEXT, "
                    + travelEnd + " TEXT, "
                    + travelTime + " TEXT, "
                    + totalKm + " TEXT, "
                    + isEventStart + " TEXT, "
                    + isTravelCompleted + " TEXT, "
                    + towRequestAccepted + " TEXT, "
                    + isPicked + " TEXT, "
                    + isManualReport + " TEXT, "
                    + isPauseTravel + " TEXT, "
                    + workStartTime + " TEXT, "
                    + workEndTime + " TEXT, "
                    + mechanicWorkStartTime + " TEXT, "
                    + mechanicWorkEndTime + " TEXT, "
                    + mechanicTravelStartTime + " TEXT, "
                    + mechanicTravelEndTime + " TEXT, "
                    + mechanicTravelBreakStart + " TEXT, "
                    + mechanicTravelBreakEnd + " TEXT, "
                    + mechanicTravelRestart + " TEXT, "
                    + mobileStationLat + " TEXT, "
                    + mobileStationLon + " TEXT, "
                    + sourceAddress + " TEXT, "
                    + destinationAddress + " TEXT, "
                    + dropAddress + " TEXT, "
                    + currentStep + " TEXT, "
                    + closeReason + " TEXT, "
                    + previousEventId + " TEXT, "
                    + isDayClose + " TEXT, "
                    + isReportConfirm + " TEXT, "
                    + isEventReopen + " TEXT, "
                    + isReminderSent + " TEXT, "
                    + carId + " TEXT, "
                    + reportConfirmAt + " TEXT, "
                    + reportConfirmBy + " TEXT, "
                    + createdAt + " TEXT, "
                    + updatedAt + " TEXT, "
                    + deletedAt + " TEXT, "
                    + userName + " TEXT, "
                    + calendarColor + " TEXT, "
                    + businessName + " TEXT, "
                    + firstName + " TEXT, "
                    + lastName + " TEXT, "
                    + email + " TEXT, "
                    + mobile + " TEXT, "
                    + displayId + " TEXT, "
                    + numberPlate + " TEXT, "
                    + statusId + " TEXT, "
                    + priority + " TEXT, "
                    + leadTypeId + " TEXT, "
                    + orderId + " TEXT, "
                    + lat + " TEXT, "
                    + lon + " TEXT, "
                    + address + " TEXT, "
                    + dropLat + " TEXT, "
                    + dropLon + " TEXT, "
                    + enterKm + " TEXT, "
                    + calendarWorkDisplayId + " TEXT, "
                    + note + " TEXT, "
                    + isNoteRead + " TEXT, "
                    + sedeName + " TEXT, "
                    + officeCalendarColor + " TEXT, "
                    + makeName + " TEXT, "
                    + modelName + " TEXT)"
        )

        db?.execSQL(
            "create table "
                    + travelDetailLead + " ("
                    + id + " TEXT, "
                    + displayId + " TEXT, "
                    + numberPlate + " TEXT, "
                    + contactId + " TEXT, "
                    + createdBy + " TEXT, "
                    + parentLeadId + " TEXT, "
                    + customerDisplayId + " TEXT, "
                    + customerDocumentId + " TEXT, "
                    + lastUpdatedBy + " TEXT, "
                    + leadTitle + " TEXT, "
                    + description + " TEXT, "
                    + pipelineId + " TEXT, "
                    + phaseId + " TEXT, "
                    + ownerId + " TEXT, "
                    + leadValue + " TEXT, "
                    + isArchived + " TEXT, "
                    + priority + " TEXT, "
                    + parentId + " TEXT, "
                    + billingAddressId + " TEXT, "
                    + shippingAddressId + " TEXT, "
                    + leadTypeId + " TEXT, "
                    + carId + " TEXT, "
                    + officeLocationId + " TEXT, "
                    + statusId + " TEXT, "
                    + orderStatusId + " TEXT, "
                    + trafficSource + " TEXT, "
                    + requestUrl + " TEXT, "
                    + mechanicId + " TEXT, "
                    + renewCounter + " TEXT, "
                    + accessToken + " TEXT, "
                    + updatedBy + " TEXT, "
                    + locationType + " TEXT, "
                    + lat + " TEXT, "
                    + lon + " TEXT, "
                    + address + " TEXT, "
                    + dropLat + " TEXT, "
                    + dropLon + " TEXT, "
                    + dropAddress + " TEXT, "
                    + warehouseInstruction + " TEXT, "
                    + stockNote + " TEXT, "
                    + itemNote + " TEXT, "
                    + isProblemIdentify + " TEXT, "
                    + isWarningLight + " TEXT, "
                    + warningLights + " TEXT, "
                    + testCentral + " TEXT, "
                    + orderId + " TEXT, "
                    + isCreatedByMechanic + " TEXT, "
                    + configuredBy + " TEXT, "
                    + isInspection + " TEXT, "
                    + isNew + " TEXT, "
                    + isRead + " TEXT, "
                    + isManual + " TEXT, "
                    + isUrgent + " TEXT, "
                    + isFutureRequest + " TEXT, "
                    + sosIcon + " TEXT, "
                    + customerWorkPlanId + " TEXT, "
                    + reportType + " TEXT, "
                    + isReportConfirm + " TEXT, "
                    + reportDescription + " TEXT, "
                    + sosRequestId + " TEXT, "
                    + enterKm + " TEXT, "
                    + isDayClose + " TEXT, "
                    + closeReason + " TEXT, "
                    + configuredByLocationId + " TEXT, "
                    + isWheelChange + " TEXT, "
                    + isAuthorization + " TEXT, "
                    + authorizationCode + " TEXT, "
                    + driverCode + " TEXT, "
                    + isGa + " TEXT, "
                    + offerPdf + " TEXT, "
                    + offerCreatedBy + " TEXT, "
                    + emojiSelection + " TEXT, "
                    + deleted + " TEXT, "
                    + createdAt + " TEXT, "
                    + updatedAt + " TEXT, "
                    + firstName + " TEXT, "
                    + lastName + " TEXT, "
                    + businessName + " TEXT, "
                    + fullName + " TEXT, "
                    + email + " TEXT, "
                    + mobile + " TEXT, "
                    + ownerName + " TEXT, "
                    + ownerEmail + " TEXT, "
                    + ownerMobile + " TEXT, "
                    + createdByName + " TEXT, "
                    + configuredByName + " TEXT, "
                    + pipelineName + " TEXT, "
                    + phaseName + " TEXT, "
                    + locationName + " TEXT, "
                    + locationAddress + " TEXT, "
                    + makeName + " TEXT, "
                    + modelName + " TEXT, "
                    + statusName + " TEXT, "
                    + vin + " TEXT, "
                    + locationId + " TEXT, "
                    + sedeName + " TEXT, "
                    + appointmentCount + " TEXT)"
        )

        db?.execSQL(
            "create table "
                    + travelDetailWorkPlan + " ("
                    + id + " TEXT, "
                    + displayId + " TEXT, "
                    + parentWorkPlanId + " TEXT, "
                    + customerId + " TEXT, "
                    + mobileStationId + " TEXT, "
                    + locationId + " TEXT, "
                    + date + " TEXT, "
                    + lat + " TEXT, "
                    + lon + " TEXT, "
                    + address + " TEXT, "
                    + isEmailSend + " TEXT, "
                    + emailSentDate + " TEXT, "
                    + createdBy + " TEXT, "
                    + icon + " TEXT, "
                    + statusId + " TEXT, "
                    + orderStatusId + " TEXT, "
                    + inchargeId + " TEXT, "
                    + isOrderNew + " TEXT, "
                    + isCreatedByMechanic + " TEXT, "
                    + isNew + " TEXT, "
                    + isRead + " TEXT, "
                    + isNoteRead + " TEXT, "
                    + calendarColor + " TEXT, "
                    + isMessageRead + " TEXT, "
                    + isReportConfirm + " TEXT, "
                    + configuredBy + " TEXT, "
                    + configuredByLocationId + " TEXT, "
                    + createdByLocationId + " TEXT, "
                    + note + " TEXT, "
                    + configuredAt + " TEXT, "
                    + noteReadAt + " TEXT, "
                    + deleted + " TEXT, "
                    + createdAt + " TEXT, "
                    + updatedAt + " TEXT, "
                    + customerName + " TEXT, "
                    + createdByName + " TEXT, "
                    + configuredByName + " TEXT, "
                    + inchargeName + " TEXT, "
                    + statusName + " TEXT, "
                    + locationName + " TEXT, "
                    + leadCount + " TEXT)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        println("oldVersion = $oldVersion | newVersion = $newVersion")
    }


    fun addData(data: TravelDetailJson): Boolean {

        addTravelEvent(data.travelEvent!!)
        addTravelDetailLead(data.travelLead!!)
        if (data.workPlan != null) {
            addTravelDetailWorkPlan(data.workPlan!!)
        }

        val db = writableDatabase
        val values = ContentValues()

        values.put(travelEvent, data.travelEvent!!.id)
        values.put(travelLead, data.travelLead!!.id)
        values.put(breakDetail, data.breakDetail)
        if (data.workPlan != null) {
            values.put(workPlan, data.workPlan!!.id)
        } else {
            values.put(workPlan, 0)
        }
        values.put(eventId, data.eventId)


        val result = db.insert(mapEvent, null, values)
        if (db.isOpen) {
            db.close()
        }
        return result != -1L
    }

    fun viewData(idTemp: Int): TravelDetailJson {

        val cursor: Cursor = writableDatabase.rawQuery(
            "select * from $mapEvent where $eventId = '$idTemp'", null
        )

        val temp = TravelDetailJson()

        if (cursor.count != 0) {
            while (cursor.moveToNext()) {

                temp.travelEvent = getTravelEvent(cursor.getInt(0))
                temp.travelLead = getTravelDetailLead(cursor.getInt(1))
                temp.breakDetail = cursor.getString(2)
                temp.workPlan = getTravelDetailWorkPlan(cursor.getInt(3))
                temp.eventId = cursor.getInt(4)
            }
        }

        cursor.close()

        return temp
    }


    private fun addTravelEvent(data: TravelDetailEvent): Boolean {

        val db = writableDatabase
        val values = ContentValues()

        values.put(id, data.id)
        values.put(leadId, data.leadId)
        values.put(title, data.title)
        values.put(description, data.description)
        values.put(contactId, data.contactId)
        values.put(createdBy, data.createdBy)
        values.put(parentEventId, data.parentEventId)
        values.put(calendarWorkPlanId, data.calendarWorkPlanId)
        values.put(customerWorkPlanId, data.customerWorkPlanId)
        values.put(objectType, data.objectType)
        values.put(actionDate, data.actionDate)
        values.put(mobileStationId, data.mobileStationId)
        values.put(fileName, data.fileName)
        values.put(fileLocation, data.fileLocation)
        values.put(completed, data.completed)
        values.put(assignTo, data.assignTo)
        values.put(startDate, data.startDate)
        values.put(endDate, data.endDate)
        values.put(workWithUserId, data.workWithUserId)
        values.put(appointmentRepeatCount, data.appointmentRepeatCount)
        values.put(appointmentRepeatOption, data.appointmentRepeatOption)
        values.put(remindCron, data.remindCron)
        values.put(repeatAppointmentMainId, data.repeatAppointmentMainId)
        values.put(isVisible, data.isVisible)
        values.put(parentId, data.parentId)
        values.put(isAllday, data.isAllday)
        values.put(eventNotification, data.eventNotification)
        values.put(notificationDuration, data.notificationDuration)
        values.put(notificationOption, data.notificationOption)
        values.put(mainEventId, data.mainEventId)
        values.put(workWithIds, data.workWithIds)
        values.put(isConfirm, data.isConfirm)
        values.put(inviteEmail, data.inviteEmail)
        values.put(callAppointment, data.callAppointment)
        values.put(appointmentRequestFrom, data.appointmentRequestFrom)
        values.put(isPending, data.isPending)
        values.put(deleted, data.deleted)
        values.put(confirmedAt, data.confirmedAt)
        values.put(isClosed, data.isClosed)
        values.put(closedAt, data.closedAt)
        values.put(travelStart, data.travelStart)
        values.put(travelEnd, data.travelEnd)
        values.put(travelTime, data.travelTime)
        values.put(totalKm, data.totalKm)
        values.put(isEventStart, data.isEventStart)
        values.put(isTravelCompleted, data.isTravelCompleted)
        values.put(towRequestAccepted, data.towRequestAccepted)
        values.put(isPicked, data.isPicked)
        values.put(isManualReport, data.isManualReport)
        values.put(isPauseTravel, data.isPauseTravel)
        values.put(workStartTime, data.workStartTime)
        values.put(workEndTime, data.workEndTime)
        values.put(mechanicWorkStartTime, data.mechanicWorkStartTime)
        values.put(mechanicWorkEndTime, data.mechanicWorkEndTime)
        values.put(mechanicTravelStartTime, data.mechanicTravelStartTime)
        values.put(mechanicTravelEndTime, data.mechanicTravelEndTime)
        values.put(mechanicTravelBreakStart, data.mechanicTravelBreakStart)
        values.put(mechanicTravelBreakEnd, data.mechanicTravelBreakEnd)
        values.put(mechanicTravelRestart, data.mechanicTravelRestart)
        values.put(mobileStationLat, data.mobileStationLat)
        values.put(mobileStationLon, data.mobileStationLon)
        values.put(sourceAddress, data.sourceAddress)
        values.put(destinationAddress, data.destinationAddress)
        values.put(dropAddress, data.dropAddress)
        values.put(currentStep, data.currentStep)
        values.put(closeReason, data.closeReason)
        values.put(previousEventId, data.previousEventId)
        values.put(isDayClose, data.isDayClose)
        values.put(isReportConfirm, data.isReportConfirm)
        values.put(isEventReopen, data.isEventReopen)
        values.put(isReminderSent, data.isReminderSent)
        values.put(carId, data.carId)
        values.put(reportConfirmAt, data.reportConfirmAt)
        values.put(reportConfirmBy, data.reportConfirmBy)
        values.put(createdAt, data.createdAt)
        values.put(updatedAt, data.updatedAt)
        values.put(deletedAt, data.deletedAt)
        values.put(userName, data.userName)
        values.put(calendarColor, data.calendarColor)
        values.put(businessName, data.businessName)
        values.put(firstName, data.firstName)
        values.put(lastName, data.lastName)
        values.put(email, data.email)
        values.put(mobile, data.mobile)
        values.put(displayId, data.displayId)
        values.put(numberPlate, data.numberPlate)
        values.put(statusId, data.statusId)
        values.put(priority, data.priority)
        values.put(leadTypeId, data.leadTypeId)
        values.put(orderId, data.orderId)
        values.put(lat, data.lat)
        values.put(lon, data.lon)
        values.put(address, data.address)
        values.put(dropLat, data.dropLat)
        values.put(dropLon, data.dropLon)
        values.put(enterKm, data.enterKm)
        values.put(calendarWorkDisplayId, data.calendarWorkDisplayId)
        values.put(note, data.note)
        values.put(isNoteRead, data.isNoteRead)
        values.put(sedeName, data.sedeName)
        values.put(officeCalendarColor, data.officeCalendarColor)
        values.put(makeName, data.makeName)
        values.put(modelName, data.modelName)


        val result = db.insert(travelDetailEvent, null, values)
        if (db.isOpen) {
            db.close()
        }
        return result != -1L
    }

    private fun getTravelEvent(idTemp: Int): TravelDetailEvent {

        val cursor: Cursor = writableDatabase.rawQuery(
            "select * from $travelDetailEvent where $id = '$idTemp'", null
        )

        val temp = TravelDetailEvent()

        if (cursor.count != 0) {
            while (cursor.moveToNext()) {

                temp.id = cursor.getInt(0)
                temp.leadId = cursor.getInt(1)
                temp.title = cursor.getString(2)
                temp.description = cursor.getString(3)
                temp.contactId = cursor.getInt(4)
                temp.createdBy = cursor.getInt(5)
                temp.parentEventId = cursor.getInt(6)
                temp.calendarWorkPlanId = cursor.getInt(7)
                temp.customerWorkPlanId = cursor.getInt(8)
                temp.objectType = cursor.getString(9)
                temp.actionDate = cursor.getString(10)
                temp.mobileStationId = cursor.getInt(11)
                temp.fileName = cursor.getString(12)
                temp.fileLocation = cursor.getString(13)
                temp.completed = cursor.getString(14)
                temp.assignTo = cursor.getInt(15)
                temp.startDate = cursor.getString(16)
                temp.endDate = cursor.getString(17)
                temp.workWithUserId = cursor.getString(18)
                temp.appointmentRepeatCount = cursor.getString(19)
                temp.appointmentRepeatOption = cursor.getString(20)
                temp.remindCron = cursor.getString(21)
                temp.repeatAppointmentMainId = cursor.getString(22)
                temp.isVisible = cursor.getInt(23)
                temp.parentId = cursor.getInt(24)
                temp.isAllday = cursor.getInt(25)
                temp.eventNotification = cursor.getString(26)
                temp.notificationDuration = cursor.getString(27)
                temp.notificationOption = cursor.getString(28)
                temp.mainEventId = cursor.getString(29)
                temp.workWithIds = cursor.getString(30)
                temp.isConfirm = cursor.getString(31)
                temp.inviteEmail = cursor.getString(32)
                temp.callAppointment = cursor.getString(33)
                temp.appointmentRequestFrom = cursor.getString(34)
                temp.isPending = cursor.getString(35)
                temp.deleted = cursor.getString(36)
                temp.confirmedAt = cursor.getString(37)
                temp.isClosed = cursor.getString(38)
                temp.closedAt = cursor.getString(39)
                temp.travelStart = cursor.getString(40)
                temp.travelEnd = cursor.getString(41)
                temp.travelTime = cursor.getDouble(42)
                temp.totalKm = cursor.getFloat(43)
                temp.isEventStart = cursor.getString(44)
                temp.isTravelCompleted = cursor.getString(45)
                temp.towRequestAccepted = cursor.getString(46)
                temp.isPicked = cursor.getString(47)
                temp.isManualReport = cursor.getString(48)
                temp.isPauseTravel = cursor.getString(49)
                temp.workStartTime = cursor.getString(50)
                temp.workEndTime = cursor.getString(51)
                temp.mechanicWorkStartTime = cursor.getString(52)
                temp.mechanicWorkEndTime = cursor.getString(53)
                temp.mechanicTravelStartTime = cursor.getString(54)
                temp.mechanicTravelEndTime = cursor.getString(55)
                temp.mechanicTravelBreakStart = cursor.getString(56)
                temp.mechanicTravelBreakEnd = cursor.getString(57)
                temp.mechanicTravelRestart = cursor.getString(58)
                temp.mobileStationLat = cursor.getDouble(59)
                temp.mobileStationLon = cursor.getDouble(60)
                temp.sourceAddress = cursor.getString(61)
                temp.destinationAddress = cursor.getString(62)
                temp.dropAddress = cursor.getString(63)
                temp.currentStep = cursor.getString(64)
                temp.closeReason = cursor.getString(65)
                temp.previousEventId = cursor.getString(66)
                temp.isDayClose = cursor.getString(67)
                temp.isReportConfirm = cursor.getString(68)
                temp.isEventReopen = cursor.getString(69)
                temp.isReminderSent = cursor.getString(70)
                temp.carId = cursor.getInt(71)
                temp.reportConfirmAt = cursor.getString(72)
                temp.reportConfirmBy = cursor.getString(73)
                temp.createdAt = cursor.getString(74)
                temp.updatedAt = cursor.getString(75)
                temp.deletedAt = cursor.getString(76)
                temp.userName = cursor.getString(77)
                temp.calendarColor = cursor.getString(78)
                temp.businessName = cursor.getString(79)
                temp.firstName = cursor.getString(80)
                temp.lastName = cursor.getString(81)
                temp.email = cursor.getString(82)
                temp.mobile = cursor.getString(83)
                temp.displayId = cursor.getString(84)
                temp.numberPlate = cursor.getString(85)
                temp.statusId = cursor.getInt(86)
                temp.priority = cursor.getInt(87)
                temp.leadTypeId = cursor.getInt(88)
                temp.orderId = cursor.getInt(89)
                temp.lat = cursor.getDouble(90)
                temp.lon = cursor.getDouble(91)
                temp.address = cursor.getString(92)
                temp.dropLat = cursor.getString(93)
                temp.dropLon = cursor.getString(94)
                temp.enterKm = cursor.getInt(95)
                temp.calendarWorkDisplayId = cursor.getString(96)
                temp.note = cursor.getString(97)
                temp.isNoteRead = cursor.getString(98)
                temp.sedeName = cursor.getString(99)
                temp.officeCalendarColor = cursor.getString(100)
                temp.makeName = cursor.getString(101)
                temp.modelName = cursor.getString(102)

            }
        }

        cursor.close()

        return temp
    }


    private fun addTravelDetailLead(data: TravelDetailLead): Boolean {

        val db = writableDatabase
        val values = ContentValues()

        values.put(id, data.id)
        values.put(displayId, data.displayId)
        values.put(numberPlate, data.numberPlate)
        values.put(contactId, data.contactId)
        values.put(createdBy, data.createdBy)
        values.put(parentLeadId, data.parentLeadId)
        values.put(customerDisplayId, data.customerDisplayId)
        values.put(customerDocumentId, data.customerDocumentId)
        values.put(lastUpdatedBy, data.lastUpdatedBy)
        values.put(leadTitle, data.leadTitle)
        values.put(description, data.description)
        values.put(pipelineId, data.pipelineId)
        values.put(phaseId, data.phaseId)
        values.put(ownerId, data.ownerId)
        values.put(leadValue, data.leadValue)
        values.put(isArchived, data.isArchived)
        values.put(priority, data.priority)
        values.put(parentId, data.parentId)
        values.put(billingAddressId, data.billingAddressId)
        values.put(shippingAddressId, data.shippingAddressId)
        values.put(leadTypeId, data.leadTypeId)
        values.put(carId, data.carId)
        values.put(officeLocationId, data.officeLocationId)
        values.put(statusId, data.statusId)
        values.put(orderStatusId, data.orderStatusId)
        values.put(trafficSource, data.trafficSource)
        values.put(requestUrl, data.requestUrl)
        values.put(mechanicId, data.mechanicId)
        values.put(renewCounter, data.renewCounter)
        values.put(accessToken, data.accessToken)
        values.put(updatedBy, data.updatedBy)
        values.put(locationType, data.locationType)
        values.put(lat, data.lat)
        values.put(lon, data.lon)
        values.put(address, data.address)
        values.put(dropLat, data.dropLat)
        values.put(dropLon, data.dropLon)
        values.put(dropAddress, data.dropAddress)
        values.put(warehouseInstruction, data.warehouseInstruction)
        values.put(stockNote, data.stockNote)
        values.put(itemNote, data.itemNote)
        values.put(isProblemIdentify, data.isProblemIdentify)
        values.put(isWarningLight, data.isWarningLight)
        values.put(warningLights, data.warningLights)
        values.put(testCentral, data.testCentral)
        values.put(orderId, data.orderId)
        values.put(isCreatedByMechanic, data.isCreatedByMechanic)
        values.put(configuredBy, data.configuredBy)
        values.put(isInspection, data.isInspection)
        values.put(isNew, data.isNew)
        values.put(isRead, data.isRead)
        values.put(isManual, data.isManual)
        values.put(isUrgent, data.isUrgent)
        values.put(isFutureRequest, data.isFutureRequest)
        values.put(sosIcon, data.sosIcon)
        values.put(customerWorkPlanId, data.customerWorkPlanId)
        values.put(reportType, data.reportType)
        values.put(isReportConfirm, data.isReportConfirm)
        values.put(reportDescription, data.reportDescription)
        values.put(sosRequestId, data.sosRequestId)
        values.put(enterKm, data.enterKm)
        values.put(isDayClose, data.isDayClose)
        values.put(closeReason, data.closeReason)
        values.put(configuredByLocationId, data.configuredByLocationId)
        values.put(isWheelChange, data.isWheelChange)
        values.put(isAuthorization, data.isAuthorization)
        values.put(authorizationCode, data.authorizationCode)
        values.put(driverCode, data.driverCode)
        values.put(isGa, data.isGa)
        values.put(offerPdf, data.offerPdf)
        values.put(offerCreatedBy, data.offerCreatedBy)
        values.put(emojiSelection, data.emojiSelection)
        values.put(deleted, data.deleted)
        values.put(createdAt, data.createdAt)
        values.put(updatedAt, data.updatedAt)
        values.put(firstName, data.firstName)
        values.put(lastName, data.lastName)
        values.put(businessName, data.businessName)
        values.put(fullName, data.fullName)
        values.put(email, data.email)
        values.put(mobile, data.mobile)
        values.put(ownerName, data.ownerName)
        values.put(ownerEmail, data.ownerEmail)
        values.put(ownerMobile, data.ownerMobile)
        values.put(createdByName, data.createdByName)
        values.put(configuredByName, data.configuredByName)
        values.put(pipelineName, data.pipelineName)
        values.put(phaseName, data.phaseName)
        values.put(locationName, data.locationName)
        values.put(locationAddress, data.locationAddress)
        values.put(makeName, data.makeName)
        values.put(modelName, data.modelName)
        values.put(statusName, data.statusName)
        values.put(vin, data.vin)
        values.put(locationId, data.locationId)
        values.put(sedeName, data.sedeName)
        values.put(appointmentCount, data.appointmentCount)

        val result = db.insert(travelDetailLead, null, values)
        if (db.isOpen) {
            db.close()
        }
        return result != -1L
    }

    private fun getTravelDetailLead(idTemp: Int): TravelDetailLead {

        val cursor: Cursor = writableDatabase.rawQuery(
            "select * from $travelDetailLead where $id = '$idTemp'", null
        )

        val temp = TravelDetailLead()

        if (cursor.count != 0) {
            while (cursor.moveToNext()) {

                temp.id = cursor.getInt(0)
                temp.displayId = cursor.getString(1)
                temp.numberPlate = cursor.getString(2)
                temp.contactId = cursor.getInt(3)
                temp.createdBy = cursor.getInt(4)
                temp.parentLeadId = cursor.getString(5)
                temp.customerDisplayId = cursor.getString(6)
                temp.customerDocumentId = cursor.getString(7)
                temp.lastUpdatedBy = cursor.getString(8)
                temp.leadTitle = cursor.getString(9)
                temp.description = cursor.getString(10)
                temp.pipelineId = cursor.getString(11)
                temp.phaseId = cursor.getString(12)
                temp.ownerId = cursor.getInt(13)
                temp.leadValue = cursor.getString(14)
                temp.isArchived = cursor.getString(15)
                temp.priority = cursor.getInt(16)
                temp.parentId = cursor.getInt(17)
                temp.billingAddressId = cursor.getString(18)
                temp.shippingAddressId = cursor.getString(19)
                temp.leadTypeId = cursor.getInt(20)
                temp.carId = cursor.getInt(21)
                temp.officeLocationId = cursor.getInt(22)
                temp.statusId = cursor.getInt(23)
                temp.orderStatusId = cursor.getString(24)
                temp.trafficSource = cursor.getString(25)
                temp.requestUrl = cursor.getString(26)
                temp.mechanicId = cursor.getString(27)
                temp.renewCounter = cursor.getString(28)
                temp.accessToken = cursor.getString(29)
                temp.updatedBy = cursor.getInt(30)
                temp.locationType = cursor.getString(31)
                temp.lat = cursor.getDouble(32)
                temp.lon = cursor.getDouble(33)
                temp.address = cursor.getString(34)
                temp.dropLat = cursor.getString(35)
                temp.dropLon = cursor.getString(36)
                temp.dropAddress = cursor.getString(37)
                temp.warehouseInstruction = cursor.getString(38)
                temp.stockNote = cursor.getString(39)
                temp.itemNote = cursor.getString(40)
                temp.isProblemIdentify = cursor.getString(41)
                temp.isWarningLight = cursor.getString(42)
                temp.warningLights = cursor.getString(43)
                temp.testCentral = cursor.getString(44)
                temp.orderId = cursor.getInt(45)
                temp.isCreatedByMechanic = cursor.getString(46)
                temp.configuredBy = cursor.getInt(47)
                temp.isInspection = cursor.getString(48)
                temp.isNew = cursor.getString(49)
                temp.isRead = cursor.getString(50)
                temp.isManual = cursor.getString(51)
                temp.isUrgent = cursor.getString(52)
                temp.isFutureRequest = cursor.getString(53)
                temp.sosIcon = cursor.getString(54)
                temp.customerWorkPlanId = cursor.getInt(55)
                temp.reportType = cursor.getString(56)
                temp.isReportConfirm = cursor.getString(57)
                temp.reportDescription = cursor.getString(58)
                temp.sosRequestId = cursor.getString(59)
                temp.enterKm = cursor.getInt(60)
                temp.isDayClose = cursor.getString(61)
                temp.closeReason = cursor.getString(62)
                temp.configuredByLocationId = cursor.getString(63)
                temp.isWheelChange = cursor.getString(64)
                temp.isAuthorization = cursor.getString(65)
                temp.authorizationCode = cursor.getString(66)
                temp.driverCode = cursor.getString(67)
                temp.isGa = cursor.getString(68)
                temp.offerPdf = cursor.getString(69)
                temp.offerCreatedBy = cursor.getString(70)
                temp.emojiSelection = cursor.getString(71)
                temp.deleted = cursor.getString(72)
                temp.createdAt = cursor.getString(73)
                temp.updatedAt = cursor.getString(74)
                temp.firstName = cursor.getString(75)
                temp.lastName = cursor.getString(76)
                temp.businessName = cursor.getString(77)
                temp.fullName = cursor.getString(78)
                temp.email = cursor.getString(79)
                temp.mobile = cursor.getString(80)
                temp.ownerName = cursor.getString(81)
                temp.ownerEmail = cursor.getString(82)
                temp.ownerMobile = cursor.getString(83)
                temp.createdByName = cursor.getString(84)
                temp.configuredByName = cursor.getString(85)
                temp.pipelineName = cursor.getString(86)
                temp.phaseName = cursor.getString(87)
                temp.locationName = cursor.getString(88)
                temp.locationAddress = cursor.getString(89)
                temp.makeName = cursor.getString(90)
                temp.modelName = cursor.getString(91)
                temp.statusName = cursor.getString(92)
                temp.vin = cursor.getString(93)
                temp.locationId = cursor.getInt(94)
                temp.sedeName = cursor.getString(95)
                temp.appointmentCount = cursor.getInt(96)

            }
        }

        cursor.close()

        return temp
    }


    private fun addTravelDetailWorkPlan(data: TravelDetailWorkPlan): Boolean {

        val db = writableDatabase
        val values = ContentValues()

        values.put(id, data.id)
        values.put(displayId, data.displayId)
        values.put(parentWorkPlanId, data.parentWorkPlanId)
        values.put(customerId, data.customerId)
        values.put(mobileStationId, data.mobileStationId)
        values.put(locationId, data.locationId)
        values.put(date, data.date)
        values.put(lat, data.lat)
        values.put(lon, data.lon)
        values.put(address, data.address)
        values.put(isEmailSend, data.isEmailSend)
        values.put(emailSentDate, data.emailSentDate)
        values.put(createdBy, data.createdBy)
        values.put(icon, data.icon)
        values.put(statusId, data.statusId)
        values.put(orderStatusId, data.orderStatusId)
        values.put(inchargeId, data.inchargeId)
        values.put(isOrderNew, data.isOrderNew)
        values.put(isCreatedByMechanic, data.isCreatedByMechanic)
        values.put(isNew, data.isNew)
        values.put(isRead, data.isRead)
        values.put(isNoteRead, data.isNoteRead)
        values.put(calendarColor, data.calendarColor)
        values.put(isMessageRead, data.isMessageRead)
        values.put(isReportConfirm, data.isReportConfirm)
        values.put(configuredBy, data.configuredBy)
        values.put(configuredByLocationId, data.configuredByLocationId)
        values.put(createdByLocationId, data.createdByLocationId)
        values.put(note, data.note)
        values.put(configuredAt, data.configuredAt)
        values.put(noteReadAt, data.noteReadAt)
        values.put(deleted, data.deleted)
        values.put(createdAt, data.createdAt)
        values.put(updatedAt, data.updatedAt)
        values.put(customerName, data.customerName)
        values.put(createdByName, data.createdByName)
        values.put(configuredByName, data.configuredByName)
        values.put(inchargeName, data.inchargeName)
        values.put(statusName, data.statusName)
        values.put(locationName, data.locationName)
        values.put(leadCount, data.leadCount)

        val result = db.insert(travelDetailWorkPlan, null, values)
        if (db.isOpen) {
            db.close()
        }
        return result != -1L
    }

    private fun getTravelDetailWorkPlan(idTemp: Int): TravelDetailWorkPlan {

        val cursor: Cursor = writableDatabase.rawQuery(
            "select * from $travelDetailWorkPlan where $id = '$idTemp'", null
        )

        val temp = TravelDetailWorkPlan()

        if (cursor.count != 0) {
            while (cursor.moveToNext()) {

                temp.id = cursor.getInt(0)
                temp.displayId = cursor.getString(1)
                temp.parentWorkPlanId = cursor.getString(2)
                temp.customerId = cursor.getInt(3)
                temp.mobileStationId = cursor.getInt(4)
                temp.locationId = cursor.getInt(5)
                temp.date = cursor.getString(6)
                temp.lat = cursor.getDouble(7)
                temp.lon = cursor.getDouble(8)
                temp.address = cursor.getString(9)
                temp.isEmailSend = cursor.getString(10)
                temp.emailSentDate = cursor.getString(11)
                temp.createdBy = cursor.getInt(12)
                temp.icon = cursor.getString(13)
                temp.statusId = cursor.getInt(14)
                temp.orderStatusId = cursor.getInt(15)
                temp.inchargeId = cursor.getString(16)
                temp.isOrderNew = cursor.getString(17)
                temp.isCreatedByMechanic = cursor.getString(18)
                temp.isNew = cursor.getString(19)
                temp.isRead = cursor.getString(20)
                temp.isNoteRead = cursor.getString(21)
                temp.calendarColor = cursor.getString(22)
                temp.isMessageRead = cursor.getString(23)
                temp.isReportConfirm = cursor.getString(24)
                temp.configuredBy = cursor.getInt(25)
                temp.configuredByLocationId = cursor.getInt(26)
                temp.createdByLocationId = cursor.getInt(27)
                temp.note = cursor.getString(28)
                temp.configuredAt = cursor.getString(29)
                temp.noteReadAt = cursor.getString(30)
                temp.deleted = cursor.getString(31)
                temp.createdAt = cursor.getString(32)
                temp.updatedAt = cursor.getString(33)
                temp.customerName = cursor.getString(34)
                temp.createdByName = cursor.getString(35)
                temp.configuredByName = cursor.getString(36)
                temp.inchargeName = cursor.getString(37)
                temp.statusName = cursor.getString(38)
                temp.locationName = cursor.getString(39)
                temp.leadCount = cursor.getInt(40)

            }
        }

        cursor.close()

        return temp
    }


    fun deleteData(idTemp: Int): Boolean {

        val cursor: Cursor = writableDatabase.rawQuery(
            "select * from $mapEvent where $eventId = '$idTemp'", null
        )

        var cur0 = ""
        var cur1 = ""
        var cur3 = ""

        if (cursor.count != 0) {
            while (cursor.moveToNext()) {
                cur0 = cursor.getString(0)
                cur1 = cursor.getString(1)
                cur3 = cursor.getString(3) ?: ""
            }
        }

        cursor.close()

        val db = writableDatabase

        db.delete(travelDetailEvent, "$id= ? \n", arrayOf(cur0))
        db.delete(travelDetailLead, "$id= ? \n", arrayOf(cur1))
        db.delete(travelDetailWorkPlan, "$id= ? \n", arrayOf(cur3))

        val isDeleted = db.delete(
            mapEvent,
            "$eventId= ? \n", arrayOf(idTemp.toString())
        )
        db.close()
        return isDeleted != 0
    }
}