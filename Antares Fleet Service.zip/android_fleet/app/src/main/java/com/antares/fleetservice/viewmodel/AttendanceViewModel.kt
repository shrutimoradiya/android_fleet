package com.antares.fleetservice.viewmodel

import android.util.ArrayMap
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.MutableLiveData
import com.antares.fleetservice.model.CommonResponse
import com.antares.fleetservice.model.checkAttendance.CheckAttendanceModel
import com.antares.fleetservice.model.mechanicAttendance.MechanicAttendanceResponse
import com.antares.fleetservice.view.widget.dialog.ProgressDialog

class AttendanceViewModel : BaseViewModel() {

    internal var checkAttendanceData = MutableLiveData<CheckAttendanceModel>()
    internal var mechanicAttendanceData = MutableLiveData<MechanicAttendanceResponse>()
    internal var saveAttendanceData = MutableLiveData<CommonResponse>()

    fun checkAttendance(context: AppCompatActivity, map: ArrayMap<String?, Any?>) {
        val dialog = ProgressDialog(context)
        dialog.show()
        fleetRepository?.checkAttendance(map)?.observeForever {
            it?.let {
                dialog.dismiss()
                checkAttendanceData.value = it
            }
        }
    }


    fun getMechanicAttendance(context: AppCompatActivity, map: ArrayMap<String?, Any?>) {
//        val dialog = ProgressDialog(context)
//        dialog.show()
        fleetRepository?.getMechanicAttendance(map)?.observeForever {
            it?.let {
//                dialog.dismiss()
                mechanicAttendanceData.value = it
            }
        }
    }

    fun saveAttendance(context: AppCompatActivity, map: ArrayMap<String?, Any?>) {
        val dialog = ProgressDialog(context)
        dialog.show()
        fleetRepository?.saveAttendance(map)?.observeForever {
            it?.let {
                dialog.dismiss()
                saveAttendanceData.value = it
            }
        }
    }


}
