package com.antares.fleetservice.model.mechanic.event

import com.google.gson.annotations.SerializedName

data class MechanicKmDetail(
    @SerializedName("lead"                              )   var     lead                            : MechanicKmLead? = null,
    @SerializedName("last_request"                      )   var     lastRequest                     : MechanicKmLastRequest? = null,
    @SerializedName("previous_request_event"            )   var     previousRequestEvent            : MechanicKmPreviousRequestEvent? = null,
    @SerializedName("previous_request_mobile_station"   )   var     previousRequestMobileStation    : MechanicKmPreviousRequestMobileStation? = null
)
