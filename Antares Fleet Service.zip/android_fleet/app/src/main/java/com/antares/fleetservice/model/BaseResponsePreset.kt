package com.antares.fleetservice.model

import com.google.gson.annotations.SerializedName

data class BaseResponsePreset(
    @SerializedName("code"              )   var     code            : Int? = null,
    @SerializedName("msg"               )   var     msg             : String? = null,
    @SerializedName("order_detail"      )   var     orderDetail     : OrderDetail? = OrderDetail(),
    @SerializedName("work_report_step"  )   var     workReportStep  : WorkReportStep? = WorkReportStep()

)
