package com.antares.fleetservice.model.mechanic.event

import com.google.gson.annotations.SerializedName

data class DamagePhotos (
    @SerializedName("id"                 ) var id               : Int?    = null,
    @SerializedName("lead_id"            ) var leadId           : Int?    = null,
    @SerializedName("step_id"            ) var stepId           : String? = null,
    @SerializedName("car_id"             ) var carId            : Int?    = null,
    @SerializedName("driver_id"          ) var driverId         : String? = null,
    @SerializedName("category_id"        ) var categoryId       : Int?    = null,
    @SerializedName("preset_category_id" ) var presetCategoryId : Int?    = null,
    @SerializedName("order_detail_id"    ) var orderDetailId    : Int?    = null,
    @SerializedName("file_name"          ) var fileName         : String? = null,
    @SerializedName("file_location"      ) var fileLocation     : String? = null,
    @SerializedName("option_type"        ) var optionType       : String? = null,
    @SerializedName("file_type"          ) var fileType         : String? = null,
    @SerializedName("format_type"        ) var formatType       : String? = null,
    @SerializedName("wheel_type"         ) var wheelType        : String? = null,
    @SerializedName("general_type"       ) var generalType      : String? = null,
    @SerializedName("created_by"         ) var createdBy        : Int?    = null,
    @SerializedName("deleted"            ) var deleted          : String? = null,
    @SerializedName("created_at"         ) var createdAt        : String? = null,
    @SerializedName("updated_at"         ) var updatedAt        : String? = null,
    @SerializedName("step_name"          ) var stepName         : String? = null,
    @SerializedName("driver_name"        ) var driverName       : String? = null,
    @SerializedName("created_by_role"    ) var createdByRole    : String? = null,
    @SerializedName("created_at_date"    ) var createdAtDate    : String? = null
)