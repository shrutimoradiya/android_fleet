package com.antares.fleetservice.model.event

import com.google.gson.annotations.SerializedName

data class CalendarEvent(
    @SerializedName("id"                )   var     id              : Int? = null,
    @SerializedName("action_date"       )   var     actionDate      : String? = null,
    @SerializedName("lead_id"           )   var     leadId          : Int? = null,
    @SerializedName("mobile_station_id" )   var     mobileStationId : Int? = null,
    @SerializedName("assign_to"         )   var     assignId        : Int? = null
)
