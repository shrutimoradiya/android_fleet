package com.antares.fleetservice.model

import com.google.gson.annotations.SerializedName

abstract class BaseResponse(
    @SerializedName("code"  )   var     code    : Int? = null,
    @SerializedName("msg"   )   var     msg     : String? = null
)
