package com.antares.fleetservice.model.mechanic.home

import com.antares.fleetservice.model.BaseResponse
import com.google.gson.annotations.SerializedName

data class MechanicHomeResponse(
    @SerializedName("json"  )   var     homeDetail  : MechanicHomeJson? = null
) : BaseResponse()