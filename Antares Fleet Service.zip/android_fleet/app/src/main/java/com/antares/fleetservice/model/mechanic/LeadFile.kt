package com.antares.fleetservice.model.mechanic

import com.google.gson.annotations.SerializedName

data class LeadFile (
    @SerializedName("lead_id"            ) var leadId           : String? = null,
    @SerializedName("car_id"             ) var carId            : String? = null,
    @SerializedName("category_id"        ) var categoryId       : String? = null,
    @SerializedName("preset_category_id" ) var presetCategoryId : String? = null,
    @SerializedName("file_location"      ) var fileLocation     : String? = null,
    @SerializedName("file_type"          ) var fileType         : String? = null,
    @SerializedName("general_type"       ) var generalType      : String? = null,
    @SerializedName("created_by"         ) var createdBy        : Int?    = null,
    @SerializedName("updated_at"         ) var updatedAt        : String? = null,
    @SerializedName("created_at"         ) var createdAt        : String? = null,
    @SerializedName("id"                 ) var id               : Int?    = null
)