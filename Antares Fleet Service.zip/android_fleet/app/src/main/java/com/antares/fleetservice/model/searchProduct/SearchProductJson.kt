package com.antares.fleetservice.model.searchProduct

import com.google.gson.annotations.SerializedName

data class SearchProductJson(
    @SerializedName("products"  )   var     products    : ArrayList<SearchProduct> = arrayListOf()
)