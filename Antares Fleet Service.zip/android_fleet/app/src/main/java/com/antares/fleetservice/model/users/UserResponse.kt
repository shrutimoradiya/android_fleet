package com.antares.fleetservice.model.users

import com.antares.fleetservice.model.BaseResponse
import com.google.gson.annotations.SerializedName

data class UserResponse(
    @SerializedName("json"  )   var     json    : UserJson? = null
) : BaseResponse()

