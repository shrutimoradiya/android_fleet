package com.antares.fleetservice.viewmodel

import android.util.ArrayMap
import androidx.lifecycle.MutableLiveData
import com.antares.fleetservice.model.users.Users
import kotlin.collections.ArrayList

class ContactViewModel : BaseViewModel() {

    internal var arrayList = MutableLiveData<ArrayList<Users>>()

    fun getContactList(map: ArrayMap<String?, Any?>) {
        fleetRepository?.getUserList(map)?.observeForever {
            it?.let {
                arrayList.value = it
            }
        }
    }

}
