package com.antares.fleetservice.model.models

import com.google.gson.annotations.SerializedName

data class ModelsJson(
    @SerializedName("models"    )   var     models  : ArrayList<Models> = arrayListOf()
)