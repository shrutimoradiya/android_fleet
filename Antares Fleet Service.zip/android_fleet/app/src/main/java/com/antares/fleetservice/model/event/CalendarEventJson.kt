package com.antares.fleetservice.model.event

import com.google.gson.annotations.SerializedName

data class CalendarEventJson(
    @SerializedName("events"    )   var     eventsList  : ArrayList<CalendarEvent> = arrayListOf()
)