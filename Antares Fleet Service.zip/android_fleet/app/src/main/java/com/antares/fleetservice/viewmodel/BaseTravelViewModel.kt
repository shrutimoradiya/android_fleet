package com.antares.fleetservice.viewmodel

import android.util.ArrayMap
import androidx.lifecycle.MutableLiveData
import com.antares.fleetservice.model.travel.TravelDetailJson
import java.util.*

abstract class BaseTravelViewModel : BaseViewModel() {

    internal val cal = Calendar.getInstance()
    internal var travelData = MutableLiveData<TravelDetailJson>()
    internal var eventCompleted = MutableLiveData<Boolean>()

    fun getTravelStartEnd(map: ArrayMap<String?, Any?>) {
        fleetRepository?.getTravelStartEnd(map)?.observeForever {
            it?.let {
                eventCompleted.value = it.msg == "Dati Salvati"
            }
        }
    }
}
