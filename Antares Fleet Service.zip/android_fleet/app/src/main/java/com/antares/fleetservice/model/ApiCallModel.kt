package com.antares.fleetservice.model

class ApiCallModel(
    var     id                  : Int?      = null,
    var     api                 : String?   = null,
    var     map                 : String?   = null,
    var     leadId              : Int?      = null,
    var     presetCategoryId    : Int?      = null,
)