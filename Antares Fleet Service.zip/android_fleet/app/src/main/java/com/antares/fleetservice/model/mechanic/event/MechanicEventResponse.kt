package com.antares.fleetservice.model.mechanic.event

import com.antares.fleetservice.model.BaseResponse
import com.google.gson.annotations.SerializedName

data class MechanicEventResponse(
    @SerializedName("json"  )   var     eventJson   : MechanicEventJson? = null
) : BaseResponse()