package com.antares.fleetservice.model

data class SubModel(
    var     title       : String,
    var     model_no    : String,
    var     isSelected  : Boolean = false
)