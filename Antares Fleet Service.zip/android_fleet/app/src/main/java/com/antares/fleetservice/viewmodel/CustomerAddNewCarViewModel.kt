package com.antares.fleetservice.viewmodel

import android.util.ArrayMap
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.MutableLiveData
import com.antares.fleetservice.model.CommonResponse
import com.antares.fleetservice.model.models.ModelsJson
import com.antares.fleetservice.view.widget.dialog.ProgressDialog
import com.antares.fleetservice.viewCustomer.model.CustomerAddcar.CustomerAddCarResponse


class CustomerAddNewCarViewModel : BaseViewModel() {

    internal var carDetailData = MutableLiveData<CustomerAddCarResponse>()
    internal var modelData = MutableLiveData<ModelsJson>()
    internal var saveData = MutableLiveData<CommonResponse>()


    fun getCarDetail(context: AppCompatActivity, map: ArrayMap<String?, Any?>) {
        val dialog = ProgressDialog(context)
        dialog.show()
        fleetRepository?.getCustomerAddCar(map)?.observeForever {
            it?.let {
                dialog.dismiss()
                 carDetailData.value = it
            }
        }
    }


    fun getModelDetail(context: AppCompatActivity, map: ArrayMap<String?, Any?>) {
        val dialog = ProgressDialog(context)
        dialog.show()
        fleetRepository?.getModelDetail(map)?.observeForever {
            it?.let {
                dialog.dismiss()
                modelData.value = it
            }
        }
    }

    fun saveNewCar(context: AppCompatActivity, map: ArrayMap<String?, Any?>) {
        val dialog = ProgressDialog(context)
        dialog.show()
        fleetRepository?.saveAddNewCar(map)?.observeForever {
            it?.let {
                dialog.dismiss()
                saveData.value = it
            }
        }
    }

}