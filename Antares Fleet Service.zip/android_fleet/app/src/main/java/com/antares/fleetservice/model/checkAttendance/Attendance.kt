package com.antares.fleetservice.model.checkAttendance

import com.google.gson.annotations.SerializedName

data class Attendance (
    @SerializedName("id"                    )   var     id                  : Int?      = null,
    @SerializedName("date"                  )   var     date                : String?   = null,
    @SerializedName("user_id"               )   var     userId              : Int?      = null,
    @SerializedName("work_with_user_id"     )   var     workWithUserId      : Int?      = null,
    @SerializedName("mobile_station_id"     )   var     mobileStationId     : Int?      = null,
    @SerializedName("created_by"            )   var     createdBy           : Int?      = null,
    @SerializedName("created_from"          )   var     createdFrom         : String?   = null,
    @SerializedName("created_at"            )   var     createdAt           : String?   = null,
    @SerializedName("updated_at"            )   var     updatedAt           : String?   = null,
    @SerializedName("user_name"             )   var     userName            : String?   = null,
    @SerializedName("work_with_name"        )   var     workWithName        : String?   = null,
    @SerializedName("location_name"         )   var     locationName        : String?   = null
)