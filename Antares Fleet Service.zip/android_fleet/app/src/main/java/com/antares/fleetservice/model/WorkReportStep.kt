package com.antares.fleetservice.model

import com.google.gson.annotations.SerializedName

data class WorkReportStep (
    @SerializedName("car_id"                )   var     carId               : Int?    = null,
    @SerializedName("lead_id"               )   var     leadId              : String? = null,
    @SerializedName("preset_category_id"    )   var     presetCategoryId    : String? = null,
    @SerializedName("updated_at"            )   var     updatedAt           : String? = null,
    @SerializedName("created_at"            )   var     createdAt           : String? = null,
    @SerializedName("id"                    )   var     id                  : Int?    = null,
    @SerializedName("is_completed"          )   var     isCompleted         : String? = null,
    @SerializedName("created_by"            )   var     createdBy           : Int?    = null,
    @SerializedName("deleted"               )   var     deleted             : String? = null
)