package com.antares.fleetservice.dataBase

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.antares.fleetservice.model.users.Users

class ContactUsDB(context: Context?) : SQLiteOpenHelper(context, "ContactUs.db", null, 1) {

    // table name
    private val contactUs = "ContactUs"

    // row
    private val id: String = "id"
    private val firstName: String = "firstName"
    private val lastName: String = "lastName"
    private val email: String = "email"
    private val role: String = "role"
    private val piva: String = "piva"
    private val fiscalCode: String = "fiscalCode"
    private val contactType: String = "contactType"
    private val mobile: String = "mobile"
    private val calendarColor: String = "calendarColor"
    private val photo: String = "photo"
    private val parentId: String = "parentId"
    private val isMainUser: String = "isMainUser"
    private val deleted: String = "deleted"
    private val createdAt: String = "createdAt"
    private val fullName: String = "fullName"
    private val locationName: String = "locationName"
    private val locationAddress: String = "locationAddress"
    private val displayName: String = "displayName"
    private val businessName: String = "businessName"
    private val userType: String = "userType"


    override fun onCreate(db: SQLiteDatabase?) {
        db?.execSQL(
            "create table "
                    + contactUs + " ("
                    + id + " TEXT, "
                    + firstName + " TEXT, "
                    + lastName + " TEXT, "
                    + email + " TEXT, "
                    + role + " TEXT, "
                    + piva + " TEXT, "
                    + fiscalCode + " TEXT, "
                    + contactType + " TEXT, "
                    + mobile + " TEXT, "
                    + calendarColor + " TEXT, "
                    + photo + " TEXT, "
                    + parentId + " TEXT, "
                    + isMainUser + " TEXT, "
                    + deleted + " TEXT, "
                    + createdAt + " TEXT, "
                    + fullName + " TEXT, "
                    + locationName + " TEXT, "
                    + locationAddress + " TEXT, "
                    + displayName + " TEXT, "
                    + businessName + " TEXT, "
                    + userType + " TEXT)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        println("oldVersion = $oldVersion | newVersion = $newVersion")
    }

    fun addData(data: Users): Boolean {
        val db = writableDatabase
        val values = ContentValues()
        values.put(id, data.id)
        values.put(firstName, data.firstName)
        values.put(lastName, data.lastName)
        values.put(email, data.email)
        values.put(role, data.role)
        values.put(piva, data.piva)
        values.put(fiscalCode, data.fiscalCode)
        values.put(contactType, data.contactType)
        values.put(mobile, data.mobile)
        values.put(calendarColor, data.calendarColor)
        values.put(photo, data.photo)
        values.put(parentId, data.parentId)
        values.put(isMainUser, data.isMainUser)
        values.put(deleted, data.deleted)
        values.put(createdAt, data.createdAt)
        values.put(fullName, data.fullName)
        values.put(locationName, data.locationName)
        values.put(locationAddress, data.locationAddress)
        values.put(displayName, data.displayName)
        values.put(businessName, data.businessName)
        values.put(userType, data.userType)

        val result = db.insert(contactUs, null, values)
        db.close()
        return result != -1L
    }

    fun viewData(): ArrayList<Users> {

        val cursor: Cursor = writableDatabase.rawQuery("select * from $contactUs", null)

        val arrayList = ArrayList<Users>()

        if (cursor.count != 0) {
            while (cursor.moveToNext()) {

                val temp = Users()

                temp.id = cursor.getInt(0)
                temp.firstName = cursor.getString(1)
                temp.lastName = cursor.getString(2)
                temp.email = cursor.getString(3)
                temp.role = cursor.getString(4)
                temp.piva = cursor.getString(5)
                temp.fiscalCode = cursor.getString(6)
                temp.contactType = cursor.getString(7)
                temp.mobile = cursor.getString(8)
                temp.calendarColor = cursor.getString(9)
                temp.photo = cursor.getString(10)
                temp.parentId = cursor.getInt(11)
                temp.isMainUser = cursor.getString(12)
                temp.deleted = cursor.getString(13)
                temp.createdAt = cursor.getString(14)
                temp.fullName = cursor.getString(15)
                temp.locationName = cursor.getString(16)
                temp.locationAddress = cursor.getString(17)
                temp.displayName = cursor.getString(18)
                temp.businessName = cursor.getString(19)
                temp.userType = cursor.getString(20)

                arrayList.add(temp)
            }
        }

        return arrayList
    }

    fun deleteData() {
        val db = writableDatabase
        db.execSQL("delete from $contactUs")
        db.close()
    }
}