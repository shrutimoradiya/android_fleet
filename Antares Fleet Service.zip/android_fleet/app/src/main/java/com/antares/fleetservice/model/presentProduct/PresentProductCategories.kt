package com.antares.fleetservice.model.presentProduct

import com.google.gson.annotations.SerializedName

data class PresentProductCategories(
    @SerializedName("id"            )   var     id          : Int? = null,
    @SerializedName("name"          )   var     name        : String? = null,
    @SerializedName("image"         )   var     image       : String? = null,
    @SerializedName("order_by"      )   var     orderBy     : String? = null,
    @SerializedName("is_visible"    )   var     isVisible   : String? = null,
    @SerializedName("is_display"    )   var     isDisplay   : String? = null,
    @SerializedName("step_type"     )   var     stepType    : String? = null,
    @SerializedName("deleted"       )   var     deleted     : String? = null,
    @SerializedName("created_at"    )   var     createdAt   : String? = null,
    @SerializedName("updated_at"    )   var     updatedAt   : String? = null,
                                        var     isSelected  : Boolean? = false,
                                        var     description : String? = null
)