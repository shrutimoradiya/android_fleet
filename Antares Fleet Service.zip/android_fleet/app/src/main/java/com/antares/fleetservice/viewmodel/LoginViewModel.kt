package com.antares.fleetservice.viewmodel

import android.content.Intent
import android.util.ArrayMap
import android.util.Patterns
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.antares.fleetservice.R
import com.antares.fleetservice.utils.Constant
import com.antares.fleetservice.utils.SharedPref
import com.antares.fleetservice.view.activity.MainActivity
import com.antares.fleetservice.view.widget.dialog.ProgressDialog
import com.antares.fleetservice.viewCustomer.activity.MainCustomerActivity
import com.google.gson.Gson

class LoginViewModel : BaseViewModel() {

    fun login(context: AppCompatActivity, username: String?, password: String?) {
        val dialog = ProgressDialog(context)

        username?.let { user ->
            password?.let { pwd ->
                if (!isUserNameValid(user)) {
                    Toast.makeText(
                        context,
                        context.resources.getString(R.string.invalid_username),
                        Toast.LENGTH_SHORT
                    ).show()
                    return@login
                }
                if (!isPasswordValid(pwd)) {
                    Toast.makeText(
                        context,
                        context.resources.getString(R.string.invalid_password),
                        Toast.LENGTH_SHORT
                    ).show()
                    return@login
                }
                dialog.show()

                val map: ArrayMap<String?, Any?> = ArrayMap<String?, Any?>()
                map["created_from"] = Constant.createFrom
                map["email"] = user
                map["password"] = pwd

                fleetRepository?.getLogin(context, map)?.observeForever {
                    dialog.dismiss()
                    it?.let {
                        val pref = SharedPref(context)
                        pref.userInfo = Gson().toJson(it)

                        if (it.role?.trim()?.lowercase() == "mechanic") {
                            pref.isLogin = true
                            context.finishAffinity()
                            context.startActivity(Intent(context, MainActivity::class.java))
                        } else if (it.role?.trim()?.lowercase() == "admin" ||
                            it.role?.trim()?.lowercase() == "manager"
                        ) {
                            pref.isCustomerLogin = true
                            context.finishAffinity()
                            context.startActivity(Intent(context, MainCustomerActivity::class.java))
                        }
                    }
                }
            } ?: run {
                Toast.makeText(
                    context,
                    context.resources.getString(R.string.invalid_password),
                    Toast.LENGTH_SHORT
                ).show()
            }
        } ?: run {
            Toast.makeText(
                context,
                context.resources.getString(R.string.invalid_username),
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun isUserNameValid(username: String?): Boolean {
        if (username == null || username == "") {
            return false
        }
        return if (username.contains("@")) {
            Patterns.EMAIL_ADDRESS.matcher(username).matches()
        } else {
            !username.isEmpty()
        }
    }

    private fun isPasswordValid(password: String?): Boolean {
        return password != null && password.trim { it <= ' ' }.length > 5
    }
}
