package com.antares.fleetservice.model.models

import com.google.gson.annotations.SerializedName

data class Models(
    @SerializedName("id"            )   var     id          : Int? = null,
    @SerializedName("model_name"    )   var     modelName   : String? = null,
    @SerializedName("make_id"       )   var     makeId      : Int? = null,
    @SerializedName("auto_model_id" )   var     autoModelId : Int? = null,
    @SerializedName("is_scraped"    )   var     isScraped   : String? = null,
    @SerializedName("created_at"    )   var     createdAt   : String? = null,
    @SerializedName("updated_at"    )   var     updatedAt   : String? = null,
                                        var     isSelected  : Boolean = false
)