package com.antares.fleetservice.dataBase

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.antares.fleetservice.model.travel.TravelDetailLead
import com.antares.fleetservice.utils.Constant
import java.util.*

class FutureLeadsDB(context: Context?) : SQLiteOpenHelper(context, "FutureLeads.db", null, 1) {

    // table name
    private val futureLeads = "FutureLeads"

    // row
    private val id: String = "id"
    private val displayId: String = "displayId"
    private val numberPlate: String = "numberPlate"
    private val contactId: String = "contactId"
    private val createdBy: String = "createdBy"
    private val parentLeadId: String = "parentLeadId"
    private val customerDisplayId: String = "customerDisplayId"
    private val customerDocumentId: String = "customerDocumentId"
    private val lastUpdatedBy: String = "lastUpdatedBy"
    private val leadTitle: String = "leadTitle"
    private val description: String = "description"
    private val pipelineId: String = "pipelineId"
    private val phaseId: String = "phaseId"
    private val ownerId: String = "ownerId"
    private val leadValue: String = "leadValue"
    private val isArchived: String = "isArchived"
    private val priority: String = "priority"
    private val parentId: String = "parentId"
    private val billingAddressId: String = "billingAddressId"
    private val shippingAddressId: String = "shippingAddressId"
    private val leadTypeId: String = "leadTypeId"
    private val carId: String = "carId"
    private val officeLocationId: String = "officeLocationId"
    private val statusId: String = "statusId"
    private val orderStatusId: String = "orderStatusId"
    private val trafficSource: String = "trafficSource"
    private val requestUrl: String = "requestUrl"
    private val mechanicId: String = "mechanicId"
    private val renewCounter: String = "renewCounter"
    private val accessToken: String = "accessToken"
    private val updatedBy: String = "updatedBy"
    private val locationType: String = "locationType"
    private val lat: String = "lat"
    private val lon: String = "lon"
    private val address: String = "address"
    private val dropLat: String = "dropLat"
    private val dropLon: String = "dropLon"
    private val dropAddress: String = "dropAddress"
    private val warehouseInstruction: String = "warehouseInstruction"
    private val stockNote: String = "stockNote"
    private val itemNote: String = "itemNote"
    private val isProblemIdentify: String = "isProblemIdentify"
    private val isWarningLight: String = "isWarningLight"
    private val warningLights: String = "warningLights"
    private val testCentral: String = "testCentral"
    private val orderId: String = "orderId"
    private val isCreatedByMechanic: String = "isCreatedByMechanic"
    private val configuredBy: String = "configuredBy"
    private val isInspection: String = "isInspection"
    private val isNew: String = "isNew"
    private val isRead: String = "isRead"
    private val isManual: String = "isManual"
    private val isUrgent: String = "isUrgent"
    private val isFutureRequest: String = "isFutureRequest"
    private val sosIcon: String = "sosIcon"
    private val customerWorkPlanId: String = "customerWorkPlanId"
    private val reportType: String = "reportType"
    private val isReportConfirm: String = "isReportConfirm"
    private val reportDescription: String = "reportDescription"
    private val sosRequestId: String = "sosRequestId"
    private val enterKm: String = "enterKm"
    private val isDayClose: String = "isDayClose"
    private val closeReason: String = "closeReason"
    private val configuredByLocationId: String = "configuredByLocationId"
    private val isWheelChange: String = "isWheelChange"
    private val isAuthorization: String = "isAuthorization"
    private val authorizationCode: String = "authorizationCode"
    private val driverCode: String = "driverCode"
    private val isGa: String = "isGa"
    private val offerPdf: String = "offerPdf"
    private val offerCreatedBy: String = "offerCreatedBy"
    private val emojiSelection: String = "emojiSelection"
    private val deleted: String = "deleted"
    private val createdAt: String = "createdAt"
    private val updatedAt: String = "updatedAt"
    private val firstName: String = "firstName"
    private val lastName: String = "lastName"
    private val businessName: String = "businessName"
    private val fullName: String = "fullName"
    private val email: String = "email"
    private val mobile: String = "mobile"
    private val ownerName: String = "ownerName"
    private val ownerEmail: String = "ownerEmail"
    private val ownerMobile: String = "ownerMobile"
    private val createdByName: String = "createdByName"
    private val configuredByName: String = "configuredByName"
    private val pipelineName: String = "pipelineName"
    private val phaseName: String = "phaseName"
    private val locationName: String = "locationName"
    private val locationAddress: String = "locationAddress"
    private val makeName: String = "makeName"
    private val modelName: String = "modelName"
    private val statusName: String = "statusName"
    private val vin: String = "vin"
    private val locationId: String = "locationId"
    private val sedeName: String = "sedeName"
    private val appointmentCount: String = "appointmentCount"


    override fun onCreate(db: SQLiteDatabase?) {
        db?.execSQL(
            "create table "
                    + futureLeads + " ("
                    + id + " TEXT, "
                    + displayId + " TEXT, "
                    + numberPlate + " TEXT, "
                    + contactId + " TEXT, "
                    + createdBy + " TEXT, "
                    + parentLeadId + " TEXT, "
                    + customerDisplayId + " TEXT, "
                    + customerDocumentId + " TEXT, "
                    + lastUpdatedBy + " TEXT, "
                    + leadTitle + " TEXT, "
                    + description + " TEXT, "
                    + pipelineId + " TEXT, "
                    + phaseId + " TEXT, "
                    + ownerId + " TEXT, "
                    + leadValue + " TEXT, "
                    + isArchived + " TEXT, "
                    + priority + " TEXT, "
                    + parentId + " TEXT, "
                    + billingAddressId + " TEXT, "
                    + shippingAddressId + " TEXT, "
                    + leadTypeId + " TEXT, "
                    + carId + " TEXT, "
                    + officeLocationId + " TEXT, "
                    + statusId + " TEXT, "
                    + orderStatusId + " TEXT, "
                    + trafficSource + " TEXT, "
                    + requestUrl + " TEXT, "
                    + mechanicId + " TEXT, "
                    + renewCounter + " TEXT, "
                    + accessToken + " TEXT, "
                    + updatedBy + " TEXT, "
                    + locationType + " TEXT, "
                    + lat + " TEXT, "
                    + lon + " TEXT, "
                    + address + " TEXT, "
                    + dropLat + " TEXT, "
                    + dropLon + " TEXT, "
                    + dropAddress + " TEXT, "
                    + warehouseInstruction + " TEXT, "
                    + stockNote + " TEXT, "
                    + itemNote + " TEXT, "
                    + isProblemIdentify + " TEXT, "
                    + isWarningLight + " TEXT, "
                    + warningLights + " TEXT, "
                    + testCentral + " TEXT, "
                    + orderId + " TEXT, "
                    + isCreatedByMechanic + " TEXT, "
                    + configuredBy + " TEXT, "
                    + isInspection + " TEXT, "
                    + isNew + " TEXT, "
                    + isRead + " TEXT, "
                    + isManual + " TEXT, "
                    + isUrgent + " TEXT, "
                    + isFutureRequest + " TEXT, "
                    + sosIcon + " TEXT, "
                    + customerWorkPlanId + " TEXT, "
                    + reportType + " TEXT, "
                    + isReportConfirm + " TEXT, "
                    + reportDescription + " TEXT, "
                    + sosRequestId + " TEXT, "
                    + enterKm + " TEXT, "
                    + isDayClose + " TEXT, "
                    + closeReason + " TEXT, "
                    + configuredByLocationId + " TEXT, "
                    + isWheelChange + " TEXT, "
                    + isAuthorization + " TEXT, "
                    + authorizationCode + " TEXT, "
                    + driverCode + " TEXT, "
                    + isGa + " TEXT, "
                    + offerPdf + " TEXT, "
                    + offerCreatedBy + " TEXT, "
                    + emojiSelection + " TEXT, "
                    + deleted + " TEXT, "
                    + createdAt + " TEXT, "
                    + updatedAt + " TEXT, "
                    + firstName + " TEXT, "
                    + lastName + " TEXT, "
                    + businessName + " TEXT, "
                    + fullName + " TEXT, "
                    + email + " TEXT, "
                    + mobile + " TEXT, "
                    + ownerName + " TEXT, "
                    + ownerEmail + " TEXT, "
                    + ownerMobile + " TEXT, "
                    + createdByName + " TEXT, "
                    + configuredByName + " TEXT, "
                    + pipelineName + " TEXT, "
                    + phaseName + " TEXT, "
                    + locationName + " TEXT, "
                    + locationAddress + " TEXT, "
                    + makeName + " TEXT, "
                    + modelName + " TEXT, "
                    + statusName + " TEXT, "
                    + vin + " TEXT, "
                    + locationId + " TEXT, "
                    + sedeName + " TEXT, "
                    + appointmentCount + " TEXT)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        println("oldVersion = $oldVersion | newVersion = $newVersion")
    }

    fun addData(data: TravelDetailLead): Boolean {
        val db = writableDatabase
        val values = ContentValues()
        values.put(id, data.id)
        values.put(displayId, data.displayId)
        values.put(numberPlate, data.numberPlate)
        values.put(contactId, data.contactId)
        values.put(createdBy, data.createdBy)
        values.put(parentLeadId, data.parentLeadId)
        values.put(customerDisplayId, data.customerDisplayId)
        values.put(customerDocumentId, data.customerDocumentId)
        values.put(lastUpdatedBy, data.lastUpdatedBy)
        values.put(leadTitle, data.leadTitle)
        values.put(description, data.description)
        values.put(pipelineId, data.pipelineId)
        values.put(phaseId, data.phaseId)
        values.put(ownerId, data.ownerId)
        values.put(leadValue, data.leadValue)
        values.put(isArchived, data.isArchived)
        values.put(priority, data.priority)
        values.put(parentId, data.parentId)
        values.put(billingAddressId, data.billingAddressId)
        values.put(shippingAddressId, data.shippingAddressId)
        values.put(leadTypeId, data.leadTypeId)
        values.put(carId, data.carId)
        values.put(officeLocationId, data.officeLocationId)
        values.put(statusId, data.statusId)
        values.put(orderStatusId, data.orderStatusId)
        values.put(trafficSource, data.trafficSource)
        values.put(requestUrl, data.requestUrl)
        values.put(mechanicId, data.mechanicId)
        values.put(renewCounter, data.renewCounter)
        values.put(accessToken, data.accessToken)
        values.put(updatedBy, data.updatedBy)
        values.put(locationType, data.locationType)
        values.put(lat, data.lat)
        values.put(lon, data.lon)
        values.put(address, data.address)
        values.put(dropLat, data.dropLat)
        values.put(dropLon, data.dropLon)
        values.put(dropAddress, data.dropAddress)
        values.put(warehouseInstruction, data.warehouseInstruction)
        values.put(stockNote, data.stockNote)
        values.put(itemNote, data.itemNote)
        values.put(isProblemIdentify, data.isProblemIdentify)
        values.put(isWarningLight, data.isWarningLight)
        values.put(warningLights, data.warningLights)
        values.put(testCentral, data.testCentral)
        values.put(orderId, data.orderId)
        values.put(isCreatedByMechanic, data.isCreatedByMechanic)
        values.put(configuredBy, data.configuredBy)
        values.put(isInspection, data.isInspection)
        values.put(isNew, data.isNew)
        values.put(isRead, data.isRead)
        values.put(isManual, data.isManual)
        values.put(isUrgent, data.isUrgent)
        values.put(isFutureRequest, data.isFutureRequest)
        values.put(sosIcon, data.sosIcon)
        values.put(customerWorkPlanId, data.customerWorkPlanId)
        values.put(reportType, data.reportType)
        values.put(isReportConfirm, data.isReportConfirm)
        values.put(reportDescription, data.reportDescription)
        values.put(sosRequestId, data.sosRequestId)
        values.put(enterKm, data.enterKm)
        values.put(isDayClose, data.isDayClose)
        values.put(closeReason, data.closeReason)
        values.put(configuredByLocationId, data.configuredByLocationId)
        values.put(isWheelChange, data.isWheelChange)
        values.put(isAuthorization, data.isAuthorization)
        values.put(authorizationCode, data.authorizationCode)
        values.put(driverCode, data.driverCode)
        values.put(isGa, data.isGa)
        values.put(offerPdf, data.offerPdf)
        values.put(offerCreatedBy, data.offerCreatedBy)
        values.put(emojiSelection, data.emojiSelection)
        values.put(deleted, data.deleted)
        values.put(createdAt, data.createdAt)
        values.put(updatedAt, data.updatedAt)
        values.put(firstName, data.firstName)
        values.put(lastName, data.lastName)
        values.put(businessName, data.businessName)
        values.put(fullName, data.fullName)
        values.put(email, data.email)
        values.put(mobile, data.mobile)
        values.put(ownerName, data.ownerName)
        values.put(ownerEmail, data.ownerEmail)
        values.put(ownerMobile, data.ownerMobile)
        values.put(createdByName, data.createdByName)
        values.put(configuredByName, data.configuredByName)
        values.put(pipelineName, data.pipelineName)
        values.put(phaseName, data.phaseName)
        values.put(locationName, data.locationName)
        values.put(locationAddress, data.locationAddress)
        values.put(makeName, data.makeName)
        values.put(modelName, data.modelName)
        values.put(statusName, data.statusName)
        values.put(vin, data.vin)
        values.put(locationId, data.locationId)
        values.put(sedeName, data.sedeName)
        values.put(appointmentCount, data.appointmentCount)

        val result = db.insert(futureLeads, null, values)
        db.close()
        return result != -1L
    }

    fun viewData(date: Calendar): ArrayList<TravelDetailLead> {

        val cursor: Cursor = writableDatabase.rawQuery("select * from $futureLeads", null)

        val arrayList = ArrayList<TravelDetailLead>()

        if (cursor.count != 0) {
            while (cursor.moveToNext()) {

                val createdAt = cursor.getString(73)

                var dateFinal = ""

                val dates = createdAt.split(" ")
                if (dates.isNotEmpty()) {
                    val finalDate = dates[0]
                    val dateDisplay = finalDate.split("-")
                    dateFinal = "${dateDisplay[0]}-${dateDisplay[1]}-${dateDisplay[2]}"
                }

                if (dateFinal == Constant.fullDateFormat(date)) {

                    val temp = TravelDetailLead()

                    temp.id = cursor.getInt(0)
                    temp.displayId = cursor.getString(1)
                    temp.numberPlate = cursor.getString(2)
                    temp.contactId = cursor.getInt(3)
                    temp.createdBy = cursor.getInt(4)
                    temp.parentLeadId = cursor.getString(5)
                    temp.customerDisplayId = cursor.getString(6)
                    temp.customerDocumentId = cursor.getString(7)
                    temp.lastUpdatedBy = cursor.getString(8)
                    temp.leadTitle = cursor.getString(9)
                    temp.description = cursor.getString(10)
                    temp.pipelineId = cursor.getString(11)
                    temp.phaseId = cursor.getString(12)
                    temp.ownerId = cursor.getInt(13)
                    temp.leadValue = cursor.getString(14)
                    temp.isArchived = cursor.getString(15)
                    temp.priority = cursor.getInt(16)
                    temp.parentId = cursor.getInt(17)
                    temp.billingAddressId = cursor.getString(18)
                    temp.shippingAddressId = cursor.getString(19)
                    temp.leadTypeId = cursor.getInt(20)
                    temp.carId = cursor.getInt(21)
                    temp.officeLocationId = cursor.getInt(22)
                    temp.statusId = cursor.getInt(23)
                    temp.orderStatusId = cursor.getString(24)
                    temp.trafficSource = cursor.getString(25)
                    temp.requestUrl = cursor.getString(26)
                    temp.mechanicId = cursor.getString(27)
                    temp.renewCounter = cursor.getString(28)
                    temp.accessToken = cursor.getString(29)
                    temp.updatedBy = cursor.getInt(30)
                    temp.locationType = cursor.getString(31)
                    temp.lat = cursor.getDouble(32)
                    temp.lon = cursor.getDouble(33)
                    temp.address = cursor.getString(34)
                    temp.dropLat = cursor.getString(35)
                    temp.dropLon = cursor.getString(36)
                    temp.dropAddress = cursor.getString(37)
                    temp.warehouseInstruction = cursor.getString(38)
                    temp.stockNote = cursor.getString(39)
                    temp.itemNote = cursor.getString(40)
                    temp.isProblemIdentify = cursor.getString(41)
                    temp.isWarningLight = cursor.getString(42)
                    temp.warningLights = cursor.getString(43)
                    temp.testCentral = cursor.getString(44)
                    temp.orderId = cursor.getInt(45)
                    temp.isCreatedByMechanic = cursor.getString(46)
                    temp.configuredBy = cursor.getInt(47)
                    temp.isInspection = cursor.getString(48)
                    temp.isNew = cursor.getString(49)
                    temp.isRead = cursor.getString(50)
                    temp.isManual = cursor.getString(51)
                    temp.isUrgent = cursor.getString(52)
                    temp.isFutureRequest = cursor.getString(53)
                    temp.sosIcon = cursor.getString(54)
                    temp.customerWorkPlanId = cursor.getInt(55)
                    temp.reportType = cursor.getString(56)
                    temp.isReportConfirm = cursor.getString(57)
                    temp.reportDescription = cursor.getString(58)
                    temp.sosRequestId = cursor.getString(59)
                    temp.enterKm = cursor.getInt(60)
                    temp.isDayClose = cursor.getString(61)
                    temp.closeReason = cursor.getString(62)
                    temp.configuredByLocationId = cursor.getString(63)
                    temp.isWheelChange = cursor.getString(64)
                    temp.isAuthorization = cursor.getString(65)
                    temp.authorizationCode = cursor.getString(66)
                    temp.driverCode = cursor.getString(67)
                    temp.isGa = cursor.getString(68)
                    temp.offerPdf = cursor.getString(69)
                    temp.offerCreatedBy = cursor.getString(70)
                    temp.emojiSelection = cursor.getString(71)
                    temp.deleted = cursor.getString(72)
                    temp.createdAt = cursor.getString(73)
                    temp.updatedAt = cursor.getString(74)
                    temp.firstName = cursor.getString(75)
                    temp.lastName = cursor.getString(76)
                    temp.businessName = cursor.getString(77)
                    temp.fullName = cursor.getString(78)
                    temp.email = cursor.getString(79)
                    temp.mobile = cursor.getString(80)
                    temp.ownerName = cursor.getString(81)
                    temp.ownerEmail = cursor.getString(82)
                    temp.ownerMobile = cursor.getString(83)
                    temp.createdByName = cursor.getString(84)
                    temp.configuredByName = cursor.getString(85)
                    temp.pipelineName = cursor.getString(86)
                    temp.phaseName = cursor.getString(87)
                    temp.locationName = cursor.getString(88)
                    temp.locationAddress = cursor.getString(89)
                    temp.makeName = cursor.getString(90)
                    temp.modelName = cursor.getString(91)
                    temp.statusName = cursor.getString(92)
                    temp.vin = cursor.getString(93)
                    temp.locationId = cursor.getInt(94)
                    temp.sedeName = cursor.getString(95)
                    temp.appointmentCount = cursor.getInt(96)

                    arrayList.add(temp)
                }
            }
        }

        return arrayList
    }

    fun deleteData(date: Calendar) {

        val arrayList: ArrayList<TravelDetailLead> = viewData(date)

        for (temp in arrayList) {
            val db = writableDatabase
            db.delete(
                futureLeads,
                "$id= ? \n", arrayOf(temp.id.toString())
            )
            db.close()
        }
    }

}