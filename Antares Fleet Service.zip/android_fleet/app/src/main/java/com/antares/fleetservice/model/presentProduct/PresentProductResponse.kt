package com.antares.fleetservice.model.presentProduct

import com.google.gson.annotations.SerializedName

data class PresentProductResponse(
    @SerializedName("code"  )   var     code    : Int? = null,
    @SerializedName("json"  )   var     json    : PresentProductJson? = PresentProductJson()
)