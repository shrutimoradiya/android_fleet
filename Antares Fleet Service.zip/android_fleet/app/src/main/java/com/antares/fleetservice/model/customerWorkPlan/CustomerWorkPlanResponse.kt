package com.antares.fleetservice.model.customerWorkPlan

import com.google.gson.annotations.SerializedName

data class CustomerWorkPlanResponse(
    @SerializedName("code"  )   var     code    : Int? = null,
    @SerializedName("msg"   )   var     msg    : String? = null,
    @SerializedName("json"  )   var     json    : CustomerWorkPlanJson? = CustomerWorkPlanJson()
)