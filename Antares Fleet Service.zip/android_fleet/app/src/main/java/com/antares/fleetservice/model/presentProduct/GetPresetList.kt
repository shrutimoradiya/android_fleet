package com.antares.fleetservice.model.presentProduct

import com.google.gson.annotations.SerializedName

data class GetPresetList (

    @SerializedName("code"                  )   var     code                : Int? = null,
    @SerializedName("preset_categories"     )   var     presetCategories    : ArrayList<PresentProductCategories> = arrayListOf()

)