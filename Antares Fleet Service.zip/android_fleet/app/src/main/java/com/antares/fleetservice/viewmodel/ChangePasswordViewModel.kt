package com.antares.fleetservice.viewmodel

import android.util.ArrayMap
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.MutableLiveData
import com.antares.fleetservice.R
import com.antares.fleetservice.utils.Constant
import com.antares.fleetservice.view.widget.dialog.ProgressDialog

class ChangePasswordViewModel : BaseViewModel() {

    internal var isChanged = MutableLiveData<Boolean>()

    fun changePassword(
        context: AppCompatActivity,
        oldPassword: String?,
        password: String?,
        confirm_password: String?
    ) {
        oldPassword?.let { oldPwd ->
            password?.let { pwd ->

                if (!isPasswordValid(oldPwd)) {
                    Toast.makeText(
                        context,
                        context.resources.getString(R.string.invalid_old_password),
                        Toast.LENGTH_SHORT
                    ).show()
                    return@changePassword
                }

                if (!isPasswordValid(pwd)) {
                    Toast.makeText(
                        context,
                        context.resources.getString(R.string.invalid_password),
                        Toast.LENGTH_SHORT
                    ).show()
                    return@changePassword
                }

                if (pwd != confirm_password) {
                    Toast.makeText(
                        context,
                        context.resources.getString(R.string.password_not_match),
                        Toast.LENGTH_SHORT
                    ).show()
                    return@changePassword
                }

                val dialog = ProgressDialog(context)
                dialog.show()

                val map: ArrayMap<String?, Any?> = ArrayMap<String?, Any?>()
                map["created_from"] = Constant.createFrom
                map["old_password"] = oldPwd
                map["password"] = pwd

                fleetRepository?.changePassword(map)?.observeForever {
                    it?.let {
                        isChanged.value = !(isChanged.value ?: false)
                        Toast.makeText(context, it.msg, Toast.LENGTH_SHORT).show()
                        dialog.dismiss()
                    }
                }

            } ?: run {
                Toast.makeText(
                    context,
                    context.resources.getString(R.string.invalid_password),
                    Toast.LENGTH_SHORT
                ).show()
            }
        } ?: run {
            Toast.makeText(
                context,
                context.resources.getString(R.string.invalid_old_password),
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun isPasswordValid(password: String?): Boolean {
        return password != null && password.trim { it <= ' ' }.length > 5
    }
}
