package com.antares.fleetservice.viewmodel

import android.util.ArrayMap
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.MutableLiveData
import com.antares.fleetservice.model.CommonResponse
import com.antares.fleetservice.model.checkAttendance.CheckAttendanceModel
import com.antares.fleetservice.model.getCarDetail.CarDetailJson
import com.antares.fleetservice.model.models.ModelsJson
import com.antares.fleetservice.model.seda.SedaJson
import com.antares.fleetservice.view.widget.dialog.ProgressDialog

class MainViewModel : BaseViewModel() {

}
