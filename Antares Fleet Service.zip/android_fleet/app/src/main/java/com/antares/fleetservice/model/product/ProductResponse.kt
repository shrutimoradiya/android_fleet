package com.antares.fleetservice.model.product

import com.antares.fleetservice.model.BaseResponse
import com.google.gson.annotations.SerializedName

data class ProductResponse(
    @SerializedName("json"  )   var     productData : ProductJson? = null
) : BaseResponse()