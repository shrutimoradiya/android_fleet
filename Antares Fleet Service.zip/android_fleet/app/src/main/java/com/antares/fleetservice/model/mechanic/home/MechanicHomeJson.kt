package com.antares.fleetservice.model.mechanic.home

import com.google.gson.annotations.SerializedName

data class MechanicHomeJson(
    @SerializedName("events"                            )   var     events                      : ArrayList<MechanicHomeEvent> = arrayListOf(),
    @SerializedName("mobile_station_location_detail"    )   var     mobileStationLocationDetail : MobileStationLocationDetail? = null,
    @SerializedName("mobile_station_car_detail"         )   var     mobileStationCarDetail      : MobileStationCarDetail? = null,
    @SerializedName("day_close_history"                 )   var     dayCloseHistory             : DayCloseHistory? = null,
    @SerializedName("version"                           )   var     version                     : String? = null,
    @SerializedName("apk_url"                           )   var     apk_url                     : String? = null
)