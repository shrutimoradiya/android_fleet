package com.antares.fleetservice.viewmodel

import android.content.Intent
import android.os.Bundle
import android.util.ArrayMap
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.antares.fleetservice.R
import com.antares.fleetservice.app.ServiceApp
import com.antares.fleetservice.dataBase.ApiCallLeftDB
import com.antares.fleetservice.dataBase.PostCallApiDB
import com.antares.fleetservice.model.login.LoginUser
import com.antares.fleetservice.utils.Constant
import com.antares.fleetservice.utils.SharedPref
import com.antares.fleetservice.view.activity.AddNewCarActivity
import com.antares.fleetservice.view.widget.dialog.*
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class ApiCallViewModel : BaseViewModel() {

    fun apiCall(contexts: AppCompatActivity) {
        val myDbh = ApiCallLeftDB(ServiceApp.context as ServiceApp)
        val list = myDbh.viewData()

        if (list.size != 0) {
            when (list[0].api) {
                Constant.food -> {
                    foodData(contexts, list[0].map, list[0].id!!, list.size)
                }
                Constant.addCar -> {
                    customerWorkPlanList(contexts, list[0].map, list[0].id!!, list.size)
                }
                Constant.futureCar -> {
                    addFutureCar(contexts, list[0].map, list[0].id!!, list.size)
                }
                Constant.profile -> {
                    profileUpdate(contexts, list[0].map, list[0].id!!, list.size)
                }
                Constant.saveKm -> {
                    saveKM(contexts, list[0].map, list[0].id!!, list.size)
                }
                Constant.checkData -> {
                    checkData(contexts, list[0].map, list[0].id!!, list.size)
                }
                Constant.photo -> {
                    photo(contexts, list[0].map, list[0].id!!, list.size)
                }
                Constant.map -> {
                    mapStartEnd(contexts, list[0].map, list[0].id!!, list.size)
                }
                Constant.chiudiLavoraione -> {
                    chiudiLavorazioneClick(contexts, list[0].map, list[0].id!!, list.size)
                }
                Constant.furgoneDaNonFare -> {
                    furgoneDaNonFareClick(contexts, list[0].map, list[0].id!!, list.size)
                }
                Constant.riapriLavorazione -> {
                    riapriLavorazione(contexts, list[0].map, list[0].id!!, list.size)
                }
                Constant.addPreset -> {
                    addPreset(contexts, list[0].map, list[0].id!!, list.size)
                }
                Constant.saveTagliando -> {
                    saveTagliando(contexts, list[0].map, list[0].id!!, list.size)
                }
                Constant.saveDesc -> {
                    saveDesc(contexts, list[0].map, list[0].id!!, list.size)
                }
                Constant.saveWheel -> {
                    saveWheel(contexts, list[0].map, list[0].id!!, list.size)
                }
                Constant.deletePhoto -> {
                    deletePhoto(contexts, list[0].map, list[0].id!!, list.size)
                }
                Constant.deleteStep -> {
                    deleteStep(contexts, list[0].map, list[0].id!!, list.size)
                }
            }
        }
    }

    private fun deleteStep(context: AppCompatActivity, map: String?, id: Int, size: Int) {
        val dialog = ProgressTextDialog(context, size)
        dialog.show()

        fleetRepository?.deleteRecord(
            map = Gson().fromJson(
                map,
                object : TypeToken<ArrayMap<String?, Any?>>() {}.type
            )
        )?.observeForever {
            if (!it?.msg?.contains("Dati Salvati")!! || size == 1) {
                Toast.makeText(context, it.msg, Toast.LENGTH_SHORT).show()
            }
            dialog.dismiss()
            val myDbh = ApiCallLeftDB(ServiceApp.context as ServiceApp)
            myDbh.deleteData(id)
            apiCall(context)
        }
    }

    private fun deletePhoto(context: AppCompatActivity, map: String?, id: Int, size: Int) {
        val dialog = ProgressTextDialog(context, size)
        dialog.show()

        fleetRepository?.deleteRecord(
            map = Gson().fromJson(
                map,
                object : TypeToken<ArrayMap<String?, Any?>>() {}.type
            )
        )?.observeForever {
            if (!it?.msg?.contains("Dati Salvati")!! || size == 1) {
                Toast.makeText(context, it.msg, Toast.LENGTH_SHORT).show()
            }
            dialog.dismiss()
            val myDbh = ApiCallLeftDB(ServiceApp.context as ServiceApp)
            myDbh.deleteData(id)
            apiCall(context)
        }
    }

    private fun saveDesc(context: AppCompatActivity, map: String?, id: Int, size: Int) {
        val dialog = ProgressTextDialog(context, size)
        dialog.show()

        fleetRepository?.postPresetClose(
            map = Gson().fromJson(
                map,
                object : TypeToken<ArrayMap<String?, Any?>>() {}.type
            )
        )?.observeForever {
            if (!it?.msg?.contains("Dati Salvati")!! || size == 1) {
                Toast.makeText(context, it.msg, Toast.LENGTH_SHORT).show()
            }
            dialog.dismiss()
            val myDbh = ApiCallLeftDB(ServiceApp.context as ServiceApp)
            myDbh.deleteData(id)
            apiCall(context)
        }
    }

    private fun saveWheel(context: AppCompatActivity, map: String?, id: Int, size: Int) {
        val dialog = ProgressTextDialog(context, size)
        dialog.show()

        fleetRepository?.postPresetClose(
            map = Gson().fromJson(
                map,
                object : TypeToken<ArrayMap<String?, Any?>>() {}.type
            )
        )?.observeForever {
            if (!it?.msg?.contains("Dati Salvati")!! || size == 1) {
                Toast.makeText(context, it.msg, Toast.LENGTH_SHORT).show()
            }
            dialog.dismiss()
            val myDbh = ApiCallLeftDB(ServiceApp.context as ServiceApp)
            myDbh.deleteData(id)
            apiCall(context)
        }
    }

    private fun saveTagliando(context: AppCompatActivity, map: String?, id: Int, size: Int) {
        val dialog = ProgressTextDialog(context, size)
        dialog.show()

        fleetRepository?.postPresetClose(
            map = Gson().fromJson(
                map,
                object : TypeToken<ArrayMap<String?, Any?>>() {}.type
            )
        )?.observeForever {
            if (!it?.msg?.contains("Dati Salvati")!! || size == 1) {
                Toast.makeText(context, it.msg, Toast.LENGTH_SHORT).show()
            }
            dialog.dismiss()
            val myDbh = ApiCallLeftDB(ServiceApp.context as ServiceApp)
            myDbh.deleteData(id)
            apiCall(context)
        }
    }

    private fun addPreset(context: AppCompatActivity, map: String?, id: Int, size: Int) {
        val dialog = ProgressTextDialog(context, size)
        dialog.show()

        fleetRepository?.postProductsList(
            map = Gson().fromJson(
                map,
                object : TypeToken<ArrayMap<String?, Any?>>() {}.type
            )
        )?.observeForever {
            val myDbh2 = PostCallApiDB(ServiceApp.context as ServiceApp)
            val list = myDbh2.viewData()

            val mapMaster: ArrayMap<String?, Any?> =
                Gson().fromJson(map, object : TypeToken<ArrayMap<String?, Any?>>() {}.type)

            if (list.size != 0) {

                for (temp in list) {
                    if (temp.api == Constant.photo) {
                        val data1: Int = temp.leadId!!
                        val data2: Int = (mapMaster["lead_id"]).toString().toInt()

                        if (data1 == data2) {
                            val orderDetailId = it?.orderDetail?.id

                            val mapTemp: ArrayMap<String?, Any?> =
                                Gson().fromJson(
                                    temp.map,
                                    object : TypeToken<ArrayMap<String?, Any?>>() {}.type
                                )
                            mapTemp["order_detail_id"] = orderDetailId

                            fleetRepository?.postReportImagesMap(mapTemp)?.observeForever {
                                myDbh2.deleteData(temp.id!!)
                                dialog.dismiss()
                            }
                        }
                    } else if (temp.api == Constant.saveDesc) {
                        val data1: Int = temp.leadId!!
                        val data2: Int = (mapMaster["lead_id"]).toString().toInt()

                        if (data1 == data2) {
                            val orderDetailId = it?.orderDetail?.id
                            val workReportStepId = it?.workReportStep?.id

                            val mapTemp: ArrayMap<String?, Any?> =
                                Gson().fromJson(
                                    temp.map,
                                    object : TypeToken<ArrayMap<String?, Any?>>() {}.type
                                )

                            mapTemp["order_detail_id[0]"] = orderDetailId
                            mapTemp["work_report_step_id"] = workReportStepId

                            fleetRepository?.postPresetClose(mapTemp)?.observeForever {
                                myDbh2.deleteData(temp.id!!)
                                dialog.dismiss()
                            }
                        }
                    } else if (temp.api == Constant.saveTagliando) {
                        val data1: Int = temp.leadId!!
                        val data2: Int = (mapMaster["lead_id"]).toString().toInt()

                        if (data1 == data2) {
                            val orderDetailId = it?.orderDetail?.id
                            val workReportStepId = it?.workReportStep?.id

                            val mapTemp: ArrayMap<String?, Any?> =
                                Gson().fromJson(
                                    temp.map,
                                    object : TypeToken<ArrayMap<String?, Any?>>() {}.type
                                )

                            mapTemp["order_detail_id[0]"] = orderDetailId
                            mapTemp["work_report_step_id"] = workReportStepId

                            fleetRepository?.postPresetClose(mapTemp)?.observeForever {
                                myDbh2.deleteData(temp.id!!)
                                dialog.dismiss()
                            }
                        }
                    } else if (temp.api == Constant.saveWheel) {
                        val data1: Int = temp.leadId!!
                        val data2: Int = (mapMaster["lead_id"]).toString().toInt()

                        if (data1 == data2) {
                            val workReportStepId = it?.workReportStep?.id

                            val mapTemp: ArrayMap<String?, Any?> =
                                Gson().fromJson(
                                    temp.map,
                                    object : TypeToken<ArrayMap<String?, Any?>>() {}.type
                                )

                            mapTemp["work_report_step_id"] = workReportStepId

                            fleetRepository?.postPresetClose(mapTemp)?.observeForever {
                                myDbh2.deleteData(temp.id!!)
                                dialog.dismiss()
                            }
                        }
                    } else if (temp.api == Constant.deleteStep) {
                        val data1: Int = temp.leadId!!
                        val data2: Int = (mapMaster["lead_id"]).toString().toInt()

                        if (data1 == data2) {
                            val workReportStepId = it?.workReportStep?.id

                            val mapTemp: ArrayMap<String?, Any?> =
                                Gson().fromJson(
                                    temp.map,
                                    object : TypeToken<ArrayMap<String?, Any?>>() {}.type
                                )

                            mapTemp["delete_id"] = workReportStepId

                            fleetRepository?.deleteRecord(mapTemp)?.observeForever {
                                myDbh2.deleteData(temp.id!!)
                                dialog.dismiss()
                            }
                        }
                    }
                }

                if (!it?.msg?.contains("Dati Salvati")!! || size == 1) {
                    Toast.makeText(context, it.msg, Toast.LENGTH_SHORT).show()
                }
                dialog.dismiss()
                val myDbh = ApiCallLeftDB(ServiceApp.context as ServiceApp)
                myDbh.deleteData(id)
                apiCall(context)

            } else {
                if (!it?.msg?.contains("Dati Salvati")!! || size == 1) {
                    Toast.makeText(context, it.msg, Toast.LENGTH_SHORT).show()
                }
                dialog.dismiss()
                val myDbh = ApiCallLeftDB(ServiceApp.context as ServiceApp)
                myDbh.deleteData(id)
                apiCall(context)
            }
        }
    }

    private fun chiudiLavorazioneClick(
        context: AppCompatActivity,
        map: String?,
        id: Int,
        size: Int
    ) {
        val dialog = ProgressTextDialog(context, size)
        dialog.show()

        fleetRepository?.chiudiLavorazioneClick(
            map = Gson().fromJson(
                map,
                object : TypeToken<ArrayMap<String?, Any?>>() {}.type
            )
        )?.observeForever {
            if (it != null) {
                if (!it.msg?.contains("Dati Salvati")!! || size == 1) {
                    Toast.makeText(context, it.msg, Toast.LENGTH_SHORT).show()
                }
            }

            dialog.dismiss()
            val myDbh = ApiCallLeftDB(ServiceApp.context as ServiceApp)
            myDbh.deleteData(id)
            apiCall(context)
        }
    }

    private fun furgoneDaNonFareClick(
        context: AppCompatActivity,
        map: String?,
        id: Int,
        size: Int
    ) {
        val dialog = ProgressTextDialog(context, size)
        dialog.show()

        fleetRepository?.singleLeadCloseDay(
            map = Gson().fromJson(
                map,
                object : TypeToken<ArrayMap<String?, Any?>>() {}.type
            )
        )?.observeForever {
            if (it != null) {
                if (!it.msg?.contains("Dati Salvati")!! || size == 1) {
                    Toast.makeText(context, it.msg, Toast.LENGTH_SHORT).show()
                }
            }

            dialog.dismiss()
            val myDbh = ApiCallLeftDB(ServiceApp.context as ServiceApp)
            myDbh.deleteData(id)
            apiCall(context)
        }
    }

    private fun riapriLavorazione(
        context: AppCompatActivity,
        map: String?,
        id: Int,
        size: Int
    ) {
        val dialog = ProgressTextDialog(context, size)
        dialog.show()

        fleetRepository?.reOpenEvent(
            map = Gson().fromJson(
                map,
                object : TypeToken<ArrayMap<String?, Any?>>() {}.type
            )
        )?.observeForever {
            if (it != null) {
                if (!it.msg?.contains("Dati Salvati")!! || size == 1) {
                    Toast.makeText(context, it.msg, Toast.LENGTH_SHORT).show()
                }
            }

            dialog.dismiss()
            val myDbh = ApiCallLeftDB(ServiceApp.context as ServiceApp)
            myDbh.deleteData(id)
            apiCall(context)
        }
    }

    private fun mapStartEnd(context: AppCompatActivity, map: String?, id: Int, size: Int) {
        val dialog = ProgressTextDialog(context, size)
        dialog.show()

        fleetRepository?.getTravelStartEnd(
            map = Gson().fromJson(
                map,
                object : TypeToken<ArrayMap<String?, Any?>>() {}.type
            )
        )?.observeForever {
            dialog.dismiss()
            val myDbh = ApiCallLeftDB(ServiceApp.context as ServiceApp)
            myDbh.deleteData(id)
            apiCall(context)
        }
    }

    private fun photo(context: AppCompatActivity, map: String?, id: Int, size: Int) {
        val dialog = ProgressTextDialog(context, size)
        dialog.show()

        fleetRepository?.postReportImagesMap(
            map = Gson().fromJson(
                map,
                object : TypeToken<ArrayMap<String?, Any?>>() {}.type
            )
        )?.observeForever { it ->
            dialog.dismiss()
            it?.let {
                if (!it.msg?.contains("Dati Salvati")!! || size == 1) {
                    Toast.makeText(context, it.msg, Toast.LENGTH_SHORT).show()
                }

                val myDbh = ApiCallLeftDB(ServiceApp.context as ServiceApp)
                myDbh.deleteData(id)
                apiCall(context)
            }
        }
    }

    private fun checkData(context: AppCompatActivity, map: String?, id: Int, size: Int) {
        val dialog = ProgressTextDialog(context, size)
        dialog.show()

        fleetRepository?.checkAllData(
            map = Gson().fromJson(
                map,
                object : TypeToken<ArrayMap<String?, Any?>>() {}.type
            )
        )?.observeForever { it ->
            dialog.dismiss()
            it?.let {
                if (!it.msg?.contains("Dati Salvati")!! || size == 1) {
                    Toast.makeText(context, it.msg, Toast.LENGTH_SHORT).show()
                }

                val myDbh = ApiCallLeftDB(ServiceApp.context as ServiceApp)
                myDbh.deleteData(id)
                apiCall(context)
            }
        }
    }

    private fun saveKM(context: AppCompatActivity, map: String?, id: Int, size: Int) {
        val dialog = ProgressTextDialog(context, size)
        dialog.show()

        fleetRepository?.postWorkReportEnterKmMap(
            map = Gson().fromJson(
                map,
                object : TypeToken<ArrayMap<String?, Any?>>() {}.type
            )
        )?.observeForever { it ->
            dialog.dismiss()
            it?.let {
                if (!it.msg?.contains("Dati Salvati")!! || size == 1) {
                    Toast.makeText(context, it.msg, Toast.LENGTH_SHORT).show()
                }

                val myDbh = ApiCallLeftDB(ServiceApp.context as ServiceApp)
                myDbh.deleteData(id)
                apiCall(context)
            }
        }
    }

    private fun profileUpdate(context: AppCompatActivity, map: String?, id: Int, size: Int) {
        val dialog = ProgressTextDialog(context, size)
        dialog.show()

        fleetRepository?.changeProfileMap(
            map = Gson().fromJson(
                map,
                object : TypeToken<ArrayMap<String?, Any?>>() {}.type
            )
        )?.observeForever { it ->
            dialog.dismiss()
            it?.let { it1 ->
                if (!it.msg?.contains("Dati Salvati")!! || size == 1) {
                    Toast.makeText(context, it.msg, Toast.LENGTH_SHORT).show()
                }

                it1.json?.user?.let {
                    SharedPref(context).userInfo = Gson().toJson(it)
                }

                val myDbh = ApiCallLeftDB(ServiceApp.context as ServiceApp)
                myDbh.deleteData(id)
                apiCall(context)
            }
        }
    }

    private fun addFutureCar(context: AppCompatActivity, map: String?, id: Int, size: Int) {
        val dialog = ProgressTextDialog(context, size)
        dialog.show()
        fleetRepository?.addFutureCarOffline(
            map = Gson().fromJson(
                map,
                object : TypeToken<ArrayMap<String?, Any?>>() {}.type
            )
        )?.observeForever { it ->
            it?.let { it1 ->
                when (it1.code) {
                    300 -> {
                        it1.msg?.let {
                            AlertDialog(
                                context,
                                (ServiceApp.context as ServiceApp).getString(R.string.car_error),
                                it,
                                false,
                                object : AlertDialog.OnOptionSelected {
                                    override fun onConfirmClick() {
                                        val myDbh = ApiCallLeftDB(ServiceApp.context as ServiceApp)
                                        myDbh.deleteData(id)
                                        apiCall(context)

                                        dialog.dismiss()
                                    }

                                    override fun onAggiungiMezzoClick() {}
                                }
                            ).show()
                        }
                    }
                    202 -> {
                        it1.msg?.let {
                            ThreeButtonAlertDialog(
                                context,
                                (ServiceApp.context as ServiceApp).getString(R.string.car_error),
                                it,
                                "Elimina Lavorazione Futura",
                                "Modifica Targa",
                                "Aggiungi Targa Al Database",
                                object : ThreeButtonAlertDialog.OnOptionSelected {
                                    override fun onBtn1Click() {
                                        val myDbh = ApiCallLeftDB(ServiceApp.context as ServiceApp)
                                        myDbh.deleteData(id)
                                        apiCall(context)
                                        dialog.dismiss()
                                    }

                                    override fun onBtn2Click() {
                                        EditDialog(
                                            context,
                                            it.substring(0, 7),
                                            object : EditDialog.quantitaSend {
                                                override fun quantitaSendData(text: String) {
                                                    val mapMaster: ArrayMap<String?, Any?> =
                                                        Gson().fromJson(
                                                            map,
                                                            object :
                                                                TypeToken<ArrayMap<String?, Any?>>() {}.type
                                                        )

                                                    mapMaster.remove("number_plate")
                                                    mapMaster["number_plate"] = text

                                                    val myDbh = ApiCallLeftDB(context)

                                                    myDbh.addData(
                                                        context,
                                                        Constant.futureCar,
                                                        Gson().toJson(mapMaster)
                                                    )

                                                    val myDbh2 =
                                                        ApiCallLeftDB(ServiceApp.context as ServiceApp)
                                                    myDbh2.deleteData(id)

                                                    apiCall(context)
                                                    dialog.dismiss()
                                                }
                                            }
                                        ).show()
                                    }

                                    override fun onBtn3Click() {
                                        val intent = Intent(context, AddNewCarActivity::class.java)
                                        val mBundle = Bundle()

                                        val mapForDate: ArrayMap<String?, Any?> = Gson().fromJson(
                                            map,
                                            object : TypeToken<ArrayMap<String?, Any?>>() {}.type
                                        )

                                        mBundle.putSerializable(
                                            Constant.DATE_KEY,
                                            Constant.strToCalender(mapForDate["date"] as String)
                                        )
                                        mBundle.putString("searchText", it.substring(0, 7))
                                        mBundle.putString("get_type", "add_report")
                                        intent.putExtras(mBundle)
                                        context.startActivity(intent)
                                        dialog.dismiss()
                                    }
                                }
                            ).show()
                        }
                    }
                    else -> {
                        Toast.makeText(context, it.msg, Toast.LENGTH_SHORT).show()
                        val myDbh = ApiCallLeftDB(ServiceApp.context as ServiceApp)
                        myDbh.deleteData(id)
                        apiCall(context)

                        dialog.dismiss()
                    }
                }
            } ?: run {
                dialog.dismiss()
                Toast.makeText(
                    context,
                    context.resources?.getString(R.string.somthing_wrong),
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    private fun customerWorkPlanList(context: AppCompatActivity, map: String?, id: Int, size: Int) {

        var customerId = 0
        var locationId = 0

        val travelDetailViewModel: TravelDetailViewModel? = context.application?.let {
            ViewModelProvider.AndroidViewModelFactory
                .getInstance(it)
                .create(TravelDetailViewModel::class.java)
        }

        SharedPref(context).userInfo?.let {
            try {
                Gson().fromJson(it, LoginUser::class.java)?.let { it1 ->
                    customerId = it1.id ?: customerId
                    locationId = it1.locationId ?: locationId
                }
            } catch (exp: Exception) {

            }
        }

        val mapMaster: ArrayMap<String?, Any?> = Gson().fromJson(
            map,
            object : TypeToken<ArrayMap<String?, Any?>>() {}.type
        )
        mapMaster["customer_id"] = customerId
        mapMaster["location_id"] = locationId

        travelDetailViewModel?.let { viewModel ->

            viewModel.customerWorkPlanList(context, mapMaster)

            viewModel.carLocation.observeForever { it1 ->

                when (it1.code) {
                    300 -> {
                        it1.msg?.let {
                            AlertDialog(
                                context,
                                (ServiceApp.context as ServiceApp).getString(R.string.car_error),
                                it,
                                false,
                                object : AlertDialog.OnOptionSelected {
                                    override fun onConfirmClick() {
                                        val myDbh = ApiCallLeftDB(ServiceApp.context as ServiceApp)
                                        myDbh.deleteData(id)
                                        apiCall(context)

                                    }

                                    override fun onAggiungiMezzoClick() {}
                                }
                            ).show()
                        }
                    }
                    202 -> {
                        it1.msg?.let {
                            ThreeButtonAlertDialog(
                                context,
                                (ServiceApp.context as ServiceApp).getString(R.string.car_error),
                                it,
                                "Elimina Rapporto Di Lavaro",
                                "Modifica Targa",
                                "Aggiungi Targa Al Database",
                                object : ThreeButtonAlertDialog.OnOptionSelected {
                                    override fun onBtn1Click() {
                                        val myDbh = ApiCallLeftDB(ServiceApp.context as ServiceApp)
                                        myDbh.deleteData(id)
                                        apiCall(context)
                                    }

                                    override fun onBtn2Click() {
                                        EditDialog(
                                            context,
                                            it.substring(0, 7),
                                            object : EditDialog.quantitaSend {
                                                override fun quantitaSendData(text: String) {
                                                    val mapMaster1: ArrayMap<String?, Any?> =
                                                        Gson().fromJson(
                                                            map,
                                                            object :
                                                                TypeToken<ArrayMap<String?, Any?>>() {}.type
                                                        )

                                                    mapMaster1.remove("number_plate")
                                                    mapMaster1["number_plate"] = text

                                                    val myDbh = ApiCallLeftDB(context)

                                                    myDbh.addData(
                                                        context,
                                                        Constant.futureCar,
                                                        Gson().toJson(mapMaster1)
                                                    )

                                                    val myDbh2 =
                                                        ApiCallLeftDB(ServiceApp.context as ServiceApp)
                                                    myDbh2.deleteData(id)

                                                    apiCall(context)
                                                }
                                            }
                                        ).show()
                                    }

                                    override fun onBtn3Click() {
                                        val intent = Intent(context, AddNewCarActivity::class.java)
                                        val mBundle = Bundle()

                                        val mapForDate: ArrayMap<String?, Any?> = Gson().fromJson(
                                            map,
                                            object : TypeToken<ArrayMap<String?, Any?>>() {}.type
                                        )

                                        mBundle.putSerializable(
                                            Constant.DATE_KEY,
                                            Constant.strToCalender(mapForDate["date"] as String)
                                        )
                                        mBundle.putString("searchText", it.substring(0, 7))
                                        mBundle.putString("get_type", "add_report")
                                        intent.putExtras(mBundle)
                                        context.startActivity(intent)
                                    }
                                }
                            ).show()
                        }
                    }
                    else -> {

                        it1.json?.locations?.let { data ->
                            if (data.isNotEmpty()) {

                                ConfirmDialog(
                                    context,
                                    "LA TARGA " + mapMaster["number_plate"] + " E DI UNA SEDE DIVERSA DA QUELLE PLANIFICATE PER OGGI. \n\n VOUI MODIFICARE LA SEDE?",
                                    object : ConfirmDialog.OnOptionSelected {
                                        override fun onConfirmClick() {
                                            CarLocationChangeDialog(
                                                context,
                                                data,
                                                object : CarLocationChangeDialog.OnOptionSelected {
                                                    override fun onCalenderLockTextModelClick(
                                                        selectedItem: String
                                                    ) {
                                                        for (temp in data) {
                                                            if (temp.id == selectedItem.toInt()) {
                                                                temp.locationId?.let {

                                                                    val map3: ArrayMap<String?, Any?> =
                                                                        ArrayMap<String?, Any?>()
                                                                    map3["created_from"] =
                                                                        Constant.createFrom
                                                                    map3["type"] =
                                                                        "car-change-location"
                                                                    map3["location_id"] = it
                                                                    map3["number_plate"] =
                                                                        mapMaster["number_plate"]

                                                                    viewModel.changeCarLocation(
                                                                        context,
                                                                        map3
                                                                    )

                                                                    viewModel.carAddStatus2.observeForever {

                                                                        val map2: ArrayMap<String?, Any?> =
                                                                            ArrayMap<String?, Any?>()
                                                                        map2["created_from"] =
                                                                            Constant.createFrom
                                                                        map2["number_plate"] =
                                                                            mapMaster["number_plate"]
                                                                        map2["date"] =
                                                                            mapMaster["date"]

                                                                        viewModel.addCar(
                                                                            context,
                                                                            map2
                                                                        )

                                                                        viewModel.carAddStatus.observeForever {

                                                                            val myDbh =
                                                                                ApiCallLeftDB(
                                                                                    ServiceApp.context as ServiceApp
                                                                                )
                                                                            myDbh.deleteData(id)
                                                                            apiCall(context)
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            ).show()
                                        }

                                        override fun onNotConfirmClick() {

                                            val map2: ArrayMap<String?, Any?> =
                                                ArrayMap<String?, Any?>()
                                            map2["created_from"] = Constant.createFrom
                                            map2["number_plate"] = mapMaster["number_plate"]
                                            map2["date"] = mapMaster["date"]

                                            viewModel.addCar(context, map2)

                                            viewModel.carAddStatus.observeForever {

                                                val myDbh =
                                                    ApiCallLeftDB(ServiceApp.context as ServiceApp)
                                                myDbh.deleteData(id)
                                                apiCall(context)
                                            }
                                        }
                                    }
                                ).show()

                            } else {
                                val map1: ArrayMap<String?, Any?> = ArrayMap<String?, Any?>()
                                map1["created_from"] = Constant.createFrom
                                map1["number_plate"] = mapMaster["number_plate"]
                                map1["date"] = mapMaster["date"]

                                viewModel.addCar(context, map1)

                                viewModel.carAddStatus.observeForever {

                                    val myDbh = ApiCallLeftDB(ServiceApp.context as ServiceApp)
                                    myDbh.deleteData(id)
                                    apiCall(context)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private fun foodData(context: AppCompatActivity, map: String?, id: Int, size: Int) {
        val dialog = ProgressTextDialog(context, size)
        dialog.show()

        fleetRepository?.postFoodData(
            map = Gson().fromJson(
                map,
                object : TypeToken<ArrayMap<String?, Any?>>() {}.type
            )
        )?.observeForever {
            dialog.dismiss()
            it?.let {
                if (!it.msg?.contains("Dati Salvati")!! || size == 1) {
                    Toast.makeText(context, it.msg, Toast.LENGTH_SHORT).show()
                }

                val myDbh = ApiCallLeftDB(ServiceApp.context as ServiceApp)
                myDbh.deleteData(id)
                apiCall(context)
            }
        }
    }

}

