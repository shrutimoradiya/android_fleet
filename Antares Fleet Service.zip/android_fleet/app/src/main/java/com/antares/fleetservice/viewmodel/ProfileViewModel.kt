package com.antares.fleetservice.viewmodel

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.Drawable
import android.net.Uri
import android.util.ArrayMap
import android.util.Base64
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.net.toUri
import com.antares.fleetservice.R
import com.antares.fleetservice.dataBase.ApiCallLeftDB
import com.antares.fleetservice.utils.Constant
import com.antares.fleetservice.utils.SharedPref
import com.antares.fleetservice.view.widget.dialog.ProgressDialog
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.google.gson.Gson
import java.io.ByteArrayOutputStream
import java.io.File

class ProfileViewModel : BaseViewModel() {

    fun changeProfileData(
        context: AppCompatActivity,
        user_id: Int,
        first_name: String?,
        last_name: String?,
        mobile: String?,
        photo: File?
    ) {
        val dialog = ProgressDialog(context)
        if ((first_name ?: "").isEmpty()) {
            Toast.makeText(
                context,
                context.resources.getString(R.string.enter_first_name),
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        if ((last_name ?: "").isEmpty()) {
            Toast.makeText(
                context,
                context.resources.getString(R.string.enter_last_name),
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        if ((mobile ?: "").isEmpty()) {
            Toast.makeText(
                context,
                context.resources.getString(R.string.enter_mobile_number),
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        if (Constant.isOnline(context)) {
            dialog.show()
            fleetRepository?.changeProfile(
                user_id = user_id,
                first_name = first_name ?: "",
                last_name = last_name ?: "",
                mobile = mobile ?: "",
                photo = photo
            )?.observeForever { it ->
                dialog.dismiss()
                it?.let { it1 ->
                    it1.json?.user?.let {
                        SharedPref(context).userInfo = Gson().toJson(it)
                    }
                }
            }
        } else {

            val map: ArrayMap<String?, Any?> = ArrayMap<String?, Any?>()
            map["created_from"] = Constant.createFrom
            map["user_id"] = user_id
            map["first_name"] = first_name ?: ""
            map["last_name"] = last_name ?: ""
            map["mobile"] = mobile ?: ""
            map["date_time"] = Constant.dateForApi()

            if (photo != null) {

                createBase64(context, photo.toUri(), map)

            } else {
                val myDbh = ApiCallLeftDB(context)
                myDbh.addData(context, Constant.profile, Gson().toJson(map))
                Toast.makeText(context, "Data Save", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun createBase64(context: AppCompatActivity, uri: Uri, map: ArrayMap<String?, Any?>) {

        val dialog = ProgressDialog(context)
        dialog.show()

        Glide.with(context)
            .asBitmap()
            .load(uri)
            .into(object : CustomTarget<Bitmap>() {
                override fun onResourceReady(
                    imageBitmap: Bitmap,
                    transition: Transition<in Bitmap>?
                ) {
                    val outputStream = ByteArrayOutputStream()
                    imageBitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream)
                    var imageBytes = outputStream.toByteArray()

                    while (imageBytes.size > 500000) {

                        val bitmap = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.size)
                        val resized = Bitmap.createScaledBitmap(
                            bitmap,
                            (bitmap.width * 0.8).toInt(),
                            (bitmap.height * 0.8).toInt(),
                            true
                        )

                        val stream = ByteArrayOutputStream()
                        resized.compress(Bitmap.CompressFormat.PNG, 100, stream)
                        imageBytes = stream.toByteArray()
                    }
                    val image = Base64.encodeToString(imageBytes, Base64.DEFAULT)

                    map["photo_type"] =
                        "data:image/png;base64,${image.replace("\\s+".toRegex(), "")}"

                    val myDbh = ApiCallLeftDB(context)
                    myDbh.addData(context, Constant.profile, Gson().toJson(map))
                    Toast.makeText(context, "Data Save", Toast.LENGTH_SHORT).show()

                    dialog.dismiss()
                }

                override fun onLoadCleared(placeholder: Drawable?) {}
            })
    }

}
