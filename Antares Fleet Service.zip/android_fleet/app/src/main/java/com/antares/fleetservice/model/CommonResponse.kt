package com.antares.fleetservice.model

class CommonResponse : BaseResponse()
