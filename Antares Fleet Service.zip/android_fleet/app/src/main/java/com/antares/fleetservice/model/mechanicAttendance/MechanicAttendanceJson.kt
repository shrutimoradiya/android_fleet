package com.antares.fleetservice.model.mechanicAttendance

import com.google.gson.annotations.SerializedName

data class MechanicAttendanceJson(
    @SerializedName("mechanics") var mechanics: ArrayList<Mechanics> = arrayListOf(),
    @SerializedName("mobile_stations") var mobileStations: ArrayList<MobileStations> = arrayListOf()
)
