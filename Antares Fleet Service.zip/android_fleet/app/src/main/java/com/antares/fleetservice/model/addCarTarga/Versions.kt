package com.antares.fleetservice.model.addCarTarga

import com.google.gson.annotations.SerializedName

data class Versions (
    @SerializedName("make"                   ) var make                 : String? = null,
    @SerializedName("model"                  ) var model                : String? = null,
    @SerializedName("version"                ) var version              : String? = null,
    @SerializedName("body_type_name"         ) var bodyTypeName         : String? = null,
    @SerializedName("fuel_type_name"         ) var fuelTypeName         : String? = null,
    @SerializedName("transmission_type_name" ) var transmissionTypeName : String? = null,
    @SerializedName("total_doors"            ) var totalDoors           : Int?    = null,
    @SerializedName("seats"                  ) var seats                : String? = null,
    @SerializedName("value"                  ) var value                : String? = null,
    @SerializedName("field"                  ) var field                : String? = null,
    @SerializedName("make_id"                ) var makeId               : Int?    = null,
    @SerializedName("model_id"               ) var modelId              : Int?    = null,
    @SerializedName("body_type"              ) var bodyType             : String?    = null,
    @SerializedName("fuel_type"              ) var fuelType             : String? = null,
    @SerializedName("year"                   ) var year                 : String? = null,
    @SerializedName("month"                  ) var month                : String? = null,
    @SerializedName("power_type"             ) var powerType            : String? = null,
    @SerializedName("transmission_type"      ) var transmissionType     : String? = null,
    @SerializedName("vin"                    ) var vin                  : String? = null,
    @SerializedName("total_seats"            ) var totalSeats           : String? = null,
    @SerializedName("total_weight"           ) var totalWeight          : String? = null,
    @SerializedName("consumption_mixed"      ) var consumptionMixed     : String? = null,
    @SerializedName("consumption_city"       ) var consumptionCity      : String? = null,
    @SerializedName("consumption_highway"    ) var consumptionHighway   : String? = null,
    @SerializedName("total_gears"            ) var totalGears           : String? = null,
    @SerializedName("co2"                    ) var co2                  : String? = null,
    @SerializedName("total_cylinder"         ) var totalCylinder        : String? = null
        )