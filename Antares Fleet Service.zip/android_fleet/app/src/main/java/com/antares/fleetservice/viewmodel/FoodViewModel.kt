package com.antares.fleetservice.viewmodel

import android.util.ArrayMap
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.MutableLiveData
import com.antares.fleetservice.R
import com.antares.fleetservice.dataBase.ApiCallLeftDB
import com.antares.fleetservice.dataBase.FoodDB
import com.antares.fleetservice.model.food.FoodLunch
import com.antares.fleetservice.utils.Constant
import com.antares.fleetservice.view.widget.dialog.ProgressDialog
import com.google.gson.Gson
import java.util.*
import kotlin.collections.ArrayList

class FoodViewModel : BaseViewModel() {

    internal var getFoodList = MutableLiveData<ArrayList<FoodLunch>>()

    fun foodData(
        context: AppCompatActivity,
        mobile_station_id: Int,
        date: String,
        file_type: String?,
        lunch_type: String?,
        to_time: String?,
        from_time: String?
    ) {
        val dialog = ProgressDialog(context)
        if ((lunch_type ?: "").isEmpty()) {
            Toast.makeText(
                context,
                context.resources.getString(R.string.select_lunch_type),
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        if ((to_time ?: "").isEmpty()) {
            Toast.makeText(
                context,
                context.resources.getString(R.string.select_to_time),
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        if ((from_time ?: "").isEmpty()) {
            Toast.makeText(
                context,
                context.resources.getString(R.string.select_from_time),
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        if ((file_type ?: "").isEmpty()) {
            Toast.makeText(
                context,
                context.resources.getString(R.string.select_picture),
                Toast.LENGTH_SHORT
            ).show()
            return
        }
        dialog.show()

        val map: ArrayMap<String?, Any?> = ArrayMap<String?, Any?>()

        map["created_from"] = Constant.createFrom
        map["type"] = "travel-break-info"
        map["mobile_station_id"] = mobile_station_id
        map["date"] = date
        map["file_type"] = file_type
        map["lunch_type"] = lunch_type
        map["to_time"] = to_time
        map["from_time"] = from_time
        map["date_time"] = Constant.dateForApi()

        if (Constant.isOnline(context)) {
            fleetRepository?.postFoodData(map = map)?.observeForever {
                dialog.dismiss()
                it?.let { it1 ->
                    Toast.makeText(context, it1.msg, Toast.LENGTH_SHORT).show()
                    it1.foodLunch.let { it2 ->
                        getFoodList.value = it2
                    }
                }
            }
        } else {
            val myDbh = ApiCallLeftDB(context)
            val myDbh2 = FoodDB(context)

            myDbh.addData(context, Constant.food, Gson().toJson(map))

            myDbh2.addData(
                FoodLunch(
                    date = date,
                    fromTime = from_time,
                    toTime = to_time,
                    type = lunch_type
                )
            )

            val list: ArrayList<FoodLunch> = myDbh2.viewData(date)

            getFoodList.value = list

            dialog.dismiss()
        }
    }

    fun getFoodData(context: AppCompatActivity, map: ArrayMap<String?, Any?>) {
        val dialog = ProgressDialog(context)
        dialog.show()
        fleetRepository?.getFoodData(map)?.observeForever { it ->
            dialog.dismiss()
            it?.let { it1 ->
                it1.json?.breakLists?.let { it2 ->
                    getFoodList.value = it2
                }
            }
        }
    }
}
