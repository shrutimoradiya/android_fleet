package com.antares.fleetservice.model.calendarLock

import com.antares.fleetservice.model.mechanic.home.MobileStationLocationDetail
import com.google.gson.annotations.SerializedName

data class CalendarLockJson(
    @SerializedName("events"                            )   var     events                      : ArrayList<CalendarLockEvent> = arrayListOf(),
    @SerializedName("mobile_station_location_detail"    )   var     mobileStationLocationDetail : MobileStationLocationDetail? = MobileStationLocationDetail(),
)