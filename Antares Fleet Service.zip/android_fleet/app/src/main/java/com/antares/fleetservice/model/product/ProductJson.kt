package com.antares.fleetservice.model.product

import com.google.gson.annotations.SerializedName

data class ProductJson(
    @SerializedName("products"  )   var     products    : ArrayList<Product?>? = null
)
