package com.antares.fleetservice.model.mechanic.home

import com.google.gson.annotations.SerializedName

data class DayCloseHistory(
    @SerializedName("id"                )   var     id              : Int? = null,
    @SerializedName("date"              )   var     date            : String? = null,
    @SerializedName("mobile_station_id" )   var     mobileStationId : Int? = null,
    @SerializedName("closed_by"         )   var     closedBy        : Int? = null,
    @SerializedName("created_from"      )   var     createdFrom     : Int? = null,
    @SerializedName("created_at"        )   var     createdAt       : String? = null,
    @SerializedName("updated_at"        )   var     updatedAt       : String? = null
)