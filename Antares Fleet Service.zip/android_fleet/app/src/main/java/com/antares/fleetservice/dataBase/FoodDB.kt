package com.antares.fleetservice.dataBase

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.antares.fleetservice.model.food.FoodLunch

class FoodDB(context: Context?) : SQLiteOpenHelper(context, "Food.db", null, 1) {

    // table name
    private val food = "Food"

    // row
    private val id: String = "id"
    private val mobileStationId: String = "mobileStationId"
    private val leadActionId: String = "leadActionId"
    private val date: String = "date"
    private val fromTime: String = "fromTime"
    private val toTime: String = "toTime"
    private val photo: String = "photo"
    private val type: String = "type"
    private val createdBy: String = "createdBy"
    private val status: String = "status"
    private val createdAt: String = "createdAt"
    private val updatedAt: String = "updatedAt"


    override fun onCreate(db: SQLiteDatabase?) {
        db?.execSQL(
            "create table "
                    + food + " ("
                    + id + " TEXT, "
                    + mobileStationId + " TEXT, "
                    + leadActionId + " TEXT, "
                    + date + " TEXT, "
                    + fromTime + " TEXT, "
                    + toTime + " TEXT, "
                    + photo + " TEXT, "
                    + type + " TEXT, "
                    + createdBy + " TEXT, "
                    + status + " TEXT, "
                    + createdAt + " TEXT, "
                    + updatedAt + " TEXT)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        println("oldVersion = $oldVersion | newVersion = $newVersion")
    }

    fun addData(data: FoodLunch): Boolean {
        val db = writableDatabase
        val values = ContentValues()

        values.put(id, data.id)
        values.put(mobileStationId, data.mobileStationId)
        values.put(leadActionId, data.leadActionId)
        values.put(date, data.date)
        values.put(fromTime, data.fromTime)
        values.put(toTime, data.toTime)
        values.put(photo, data.photo)
        values.put(type, data.type)
        values.put(createdBy, data.createdBy)
        values.put(status, data.status)
        values.put(createdAt, data.createdAt)
        values.put(updatedAt, data.updatedAt)

        val result = db.insert(food, null, values)
        db.close()
        return result != -1L
    }

    fun viewData(tempDate: String): ArrayList<FoodLunch> {

        val cursor: Cursor =
            writableDatabase.rawQuery("select * from $food where $date = '$tempDate'", null)

        val arrayList = ArrayList<FoodLunch>()

        if (cursor.count != 0) {
            while (cursor.moveToNext()) {

                val temp = FoodLunch()

                temp.id = cursor.getInt(0)
                temp.mobileStationId = cursor.getInt(1)
                temp.leadActionId = cursor.getString(2)
                temp.date = cursor.getString(3)
                temp.fromTime = cursor.getString(4)
                temp.toTime = cursor.getString(5)
                temp.photo = cursor.getString(6)
                temp.type = cursor.getString(7)
                temp.createdBy = cursor.getInt(8)
                temp.status = cursor.getString(9)
                temp.createdAt = cursor.getString(10)
                temp.updatedAt = cursor.getString(11)

                arrayList.add(temp)
            }
        }

        return arrayList
    }

    fun deleteData(tempDate: String): Boolean {

        val db = writableDatabase

        val isDeleted = db.delete(
            food,
            "$date= ? \n", arrayOf(tempDate)
        )
        db.close()
        return isDeleted != 0
    }
}