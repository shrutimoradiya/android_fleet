package com.antares.fleetservice.utils

import android.content.Context
import android.graphics.Typeface

object FontsManager {
    var OPEN_SANS_REGULAR = "poppins_regular.ttf"
    fun getTypeface(font: String = "", context: Context): Typeface = Typeface.createFromAsset(context.assets,"font/$font")
}