package com.antares.fleetservice.model.searchProduct

import com.google.gson.annotations.SerializedName

data class SearchProduct(
    @SerializedName("id"            )   var     id              : Int? = null,
    @SerializedName("image"         )   var     image           : String? = null,
    @SerializedName("brand_image"   )   var     brandImage      : String? = null,
    @SerializedName("brand_name"    )   var     brandName       : String? = null,
    @SerializedName("brand_code"    )   var     brandCode       : String? = null,
    @SerializedName("product_link"  )   var     productLink     : String? = null,
    @SerializedName("sku"           )   var     sku             : String? = null,
    @SerializedName("barcode"       )   var     barcode         : String? = null,
    @SerializedName("title"         )   var     title           : String? = null,
    @SerializedName("description"   )   var     description     : String? = null,
    @SerializedName("old_price"     )   var     oldPrice        : Double? = null,
    @SerializedName("new_price"     )   var     newPrice        : Double? = null,
    @SerializedName("is_favourite"  )   var     isFavourite     : String? = null,
    @SerializedName("deleted"       )   var     deleted         : String? = null,
    @SerializedName("created_at"    )   var     createdAt       : String? = null,
    @SerializedName("updated_at"    )   var     updatedAt       : String? = null
)