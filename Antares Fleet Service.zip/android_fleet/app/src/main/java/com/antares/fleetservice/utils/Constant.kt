package com.antares.fleetservice.utils

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.ConnectivityManager
import android.util.Base64
import okhttp3.MediaType
import okhttp3.RequestBody
import java.io.ByteArrayOutputStream
import java.io.File
import java.text.SimpleDateFormat
import java.util.*


object Constant {
    var DD_FORMAT = "dd"
    var MONTH_FORMAT = "MMM"
    var YEAR_FORMAT = "yyyy"
    var DAYS_FORMAT = "EEE"
    var EVENT_ID_KEY = "event_id_key"
    var DATE_KEY = "date_key"
    var FROM_CAL_KEY = "cal"
    var FROM_TIME_KEY = "time"
    var FROM_KEY = ""

    var REQUEST_ID_MULTIPLE_PERMISSIONS = 101
    var REQUEST_ID_CAMERA_PERMISSIONS = 104
    var REQUEST_ID_GALLERY_PERMISSIONS = 105
    var CAMERA_REQUEST_CODE = 102
    var GALLERY_REQUEST_CODE = 103

    const val createFrom = "new_app"
    const val isUpdate = "isUpdate"
    const val apkUrl = "apkUrl"
    const val SAVE_ID = "id"
    const val SAVE_DATE = "date"
    const val food = "food"
    const val addCar = "add_car"
    const val futureCar = "futureCar"
    const val connection = "connection"
    const val profile = "profile"
    const val saveKm = "saveKm"
    const val checkData = "checkData"
    const val photo = "photo"
    const val map = "map"
    const val chiudiLavoraione = "chiudiLavoraione"
    const val furgoneDaNonFare = "furgoneDaNonFare"
    const val riapriLavorazione = "riapriLavorazione"
    const val deletePhoto = "daletePhoto"
    const val addPreset = "addPreset"
    const val saveTagliando = "saveTagliando"
    const val saveLampadine = "saveLampadine"
    const val saveDesc = "saveDesc"
    const val saveWheel = "saveWheel"
    const val deleteStep = "deleteStep"
    const val rechiestaMultipla = "rechiestaMultipla"
    const val id = "id"
    const val from = "from"
    const val statusId = "statusId"
    const val isEmailSend = "isEmailSend"
    const val first = "first"
    const val second = "second"
    private const val FILENAME = "PREFERENCES_FILE"
    const val ids = "ids"
    const val button = "button"


    fun fullDateFormat(date: Calendar): String {
        return SimpleDateFormat("yyyy-MM-dd").format(date.time)
    }

    fun dateForApi(): String {
        return SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Calendar.getInstance().time)
    }

    fun dateForApi1(date: Calendar): String {
        return SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date.time)
    }

    fun timeForShow(): String {
        return SimpleDateFormat("HH:mm:ss").format(Calendar.getInstance().time)
    }

    fun dateForSave(): String {
        return SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Calendar.getInstance().time)
    }

    fun dateForShow(date: Calendar): String {
        return SimpleDateFormat("dd-MM-yyyy").format(date.time)
    }

    fun dateForShowCalendar(date: Calendar): String {
        return SimpleDateFormat("dd MMMM yyyy").format(date.time)
    }

    fun timeShow(date: Calendar): String {
        return SimpleDateFormat("HH:mm aaa").format(date.time)
    }

    fun dateForShow1(date: Calendar): String {
        return SimpleDateFormat("d/M/yyyy").format(date.time)
    }

    fun strToCalender(date: String): Calendar {

        val dateMaster = Calendar.getInstance()
        date.split("-").let {
            dateMaster.set(
                it[0].toInt(),
                it[1].toInt().minus(1),
                it[2].toInt(),
            )
        }

        return dateMaster
    }

    fun strDTToCalender(date: String): String {

        val dateMaster = Calendar.getInstance()
        date.split(" ").let { day ->
            day[0].split("-").let {
                dateMaster.set(
                    it[0].toInt(),
                    it[1].toInt().minus(1),
                    it[2].toInt(),
                )
            }
        }

        return SimpleDateFormat("dd-MM-yyyy").format(dateMaster.time)
    }

    fun strDTToCalender122(date: String): Calendar {

        val dateMaster = Calendar.getInstance()
        date.split(" ").let { day ->
            day[0].split("-").let {
                dateMaster.set(
                    it[0].toInt(),
                    it[1].toInt().minus(1),
                    it[2].toInt(),
                )
            }
        }

        return dateMaster
    }

    fun strDTToCalender1(date: String): Calendar {

        val dateMaster = Calendar.getInstance()
        date.split("T").let { day ->
            day[0].split("-").let { ddd ->
                day[1].split(":").let { time ->
                    dateMaster.set(
                        ddd[0].toInt(),
                        ddd[1].toInt().minus(1),
                        ddd[2].toInt(),
                        time[0].toInt(),
                        time[1].toInt(),
                        time[2].toInt()
                    )
                }
            }
        }

        return dateMaster
    }

    fun strDTToCalender2(date: String): Calendar {

        val dateMaster = Calendar.getInstance()
        date.split(" ").let { day ->
            day[0].split("-").let { ddd ->
                day[1].split(":").let { time ->
                    dateMaster.set(
                        ddd[0].toInt(),
                        ddd[1].toInt().minus(1),
                        ddd[2].toInt(),
                        time[0].toInt(),
                        time[1].toInt(),
                        time[2].toInt()
                    )
                }
            }
        }

        return dateMaster
    }


    fun strAppCalender(date: String): String {

        val dateMaster = Calendar.getInstance()
        date.split(" ").let { day ->
            day[0].split("-").let { ddd ->
                day[1].split(":").let { time ->
                    dateMaster.set(
                        ddd[0].toInt(),
                        ddd[1].toInt().minus(1),
                        ddd[2].toInt(),
                        time[0].toInt(),
                        time[1].toInt(),
                        time[2].toInt()
                    )
                }
            }
        }

        return SimpleDateFormat("dd MMM, yyyy | HH:mm").format(dateMaster.time)
    }

    fun isOnline(context: Context): Boolean {
        val conMgr =
            context.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val netInfo = conMgr.activeNetworkInfo
        return !(netInfo == null || !netInfo.isConnected || !netInfo.isAvailable)
    }

    fun saveData(context: Context, key: String, data: Int) {
        val sharedPreferences = context.getSharedPreferences(FILENAME, Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putInt(key, data)
        editor.apply()
    }

    fun getData(context: Context, key: String): Int {
        val sharedPreferences = context.getSharedPreferences(FILENAME, Context.MODE_PRIVATE)
        return sharedPreferences.getInt(key, 0)
    }

    fun saveDataStr(context: Context, key: String?, data: String?) {
        val sharedPreferences = context.getSharedPreferences(FILENAME, Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putString(key, data)
        editor.apply()
    }

    fun getDataStr(context: Context, key: String?): String? {
        val sharedPreferences = context.getSharedPreferences(FILENAME, Context.MODE_PRIVATE)
        return sharedPreferences.getString(key, null)
    }

    fun saveBool(context: Context, key: String, data: Boolean) {
        val sharedPreferences = context.getSharedPreferences(FILENAME, Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putBoolean(key, data)
        editor.apply()
    }

    fun getBool(context: Context, key: String): Boolean {
        val sharedPreferences = context.getSharedPreferences(FILENAME, Context.MODE_PRIVATE)
        return sharedPreferences.getBoolean(key, false)
    }

    fun getBodyData(value: String): RequestBody {
        return RequestBody.create(
            MediaType.parse("text/plain"),
            value
        )
    }

    fun createBase64(file: File): String {
        val bm = BitmapFactory.decodeFile(file.path)
        val baos = ByteArrayOutputStream()
        bm.compress(Bitmap.CompressFormat.JPEG, 30, baos)

        val b = baos.toByteArray()
        val encodedImage = Base64.encodeToString(b, Base64.DEFAULT)

        return "data:image/png;base64,${encodedImage.replace("\\s+".toRegex(), "")}"
    }

}