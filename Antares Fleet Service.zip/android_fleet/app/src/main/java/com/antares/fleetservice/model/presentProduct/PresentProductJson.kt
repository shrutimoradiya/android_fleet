package com.antares.fleetservice.model.presentProduct

import com.google.gson.annotations.SerializedName

data class PresentProductJson(
    @SerializedName("lead"              )   var     lead                : PresentProductLead? = PresentProductLead(),
    @SerializedName("preset_categories" )   var     presetCategories    : ArrayList<PresentProductCategories> = arrayListOf(),
    @SerializedName("report_step"       )   var     reportStep          : ArrayList<Int> = arrayListOf(),
    @SerializedName("car"               )   var     car                 : PresentProductCar? = PresentProductCar()
)