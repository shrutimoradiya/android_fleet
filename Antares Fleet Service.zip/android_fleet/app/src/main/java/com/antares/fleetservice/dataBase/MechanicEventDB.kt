package com.antares.fleetservice.dataBase

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.antares.fleetservice.model.mechanic.event.*
import com.google.gson.annotations.SerializedName

class MechanicEventDB(context: Context?) : SQLiteOpenHelper(context, "MechanicEvent.db", null, 1) {

    // table name
    private val mechanicEvent = "MechanicEvent"
    private val event = "Event"
    private val kmDetailData = "KmDetailData"
    private val kmLeadData = "KmLeadData"
    private val kmPhoto = "KmPhoto"
    private val kmLastRequest = "KmLastRequest"
    private val kmPreviousRequestEvent = "PreviousRequestEvent"
    private val kmPreviousRequestMobileStation = "PreviousRequestMobileStation"
    private val eventWorkReportSteps = "EventWorkReportSteps"
    private val kmLeadItems = "KmLeadItems"
    private val kmCategories = "KmCategories"
    private val kmProducts = "kmProducts"
    private val montataData = "Montata"
    private val kmOrderDetails = "kmOrderDetails"


    // row
    private val eventDetail: String = "eventDetail"
    private val kmDetail: String = "kmDetail"
    private val workReportSteps: String = "workReportSteps"

    private val id: String = "id"
    private val leadId: String = "leadId"
    private val title: String = "title"
    private val description: String = "description"
    private val contactId: String = "contactId"
    private val createdBy: String = "createdBy"
    private val parentEventId: String = "parentEventId"
    private val calendarWorkPlanId: String = "calendarWorkPlanId"
    private val customerWorkPlanId: String = "customerWorkPlanId"
    private val objectType: String = "objectType"
    private val actionDate: String = "actionDate"
    private val mobileStationId: String = "mobileStationId"
    private val fileName: String = "fileName"
    private val fileLocation: String = "fileLocation"
    private val completed: String = "completed"
    private val assignTo: String = "assignTo"
    private val startDate: String = "startDate"
    private val endDate: String = "endDate"
    private val workWithUserId: String = "workWithUserId"
    private val appointmentRepeatCount: String = "appointmentRepeatCount"
    private val appointmentRepeatOption: String = "appointmentRepeatOption"
    private val remindCron: String = "remindCron"
    private val repeatAppointmentMainId: String = "repeatAppointmentMainId"
    private val isVisible: String = "isVisible"
    private val parentId: String = "parentId"
    private val isAllday: String = "isAllday"
    private val eventNotification: String = "eventNotification"
    private val notificationDuration: String = "notificationDuration"
    private val notificationOption: String = "notificationOption"
    private val mainEventId: String = "mainEventId"
    private val workWithIds: String = "workWithIds"
    private val isConfirm: String = "isConfirm"
    private val inviteEmail: String = "inviteEmail"
    private val callAppointment: String = "callAppointment"
    private val appointmentRequestFrom: String = "appointmentRequestFrom"
    private val isPending: String = "isPending"
    private val deleted: String = "deleted"
    private val confirmedAt: String = "confirmedAt"
    private val isClosed: String = "isClosed"
    private val isWorkNotDone: String = "isWorkNotDone"
    private val closedAt: String = "closedAt"
    private val travelStart: String = "travelStart"
    private val travelEnd: String = "travelEnd"
    private val travelTime: String = "travelTime"
    private val totalKm: String = "totalKm"
    private val isEventStart: String = "isEventStart"
    private val isTravelCompleted: String = "isTravelCompleted"
    private val towRequestAccepted: String = "towRequestAccepted"
    private val isPicked: String = "isPicked"
    private val isManualReport: String = "isManualReport"
    private val isPauseTravel: String = "isPauseTravel"
    private val workStartTime: String = "workStartTime"
    private val workEndTime: String = "workEndTime"
    private val mechanicWorkStartTime: String = "mechanicWorkStartTime"
    private val mechanicWorkEndTime: String = "mechanicWorkEndTime"
    private val mechanicTravelStartTime: String = "mechanicTravelStartTime"
    private val mechanicTravelEndTime: String = "mechanicTravelEndTime"
    private val mechanicTravelBreakStart: String = "mechanicTravelBreakStart"
    private val mechanicTravelBreakEnd: String = "mechanicTravelBreakEnd"
    private val mechanicTravelRestart: String = "mechanicTravelRestart"
    private val mobileStationLat: String = "mobileStationLat"
    private val mobileStationLon: String = "mobileStationLon"
    private val sourceAddress: String = "sourceAddress"
    private val destinationAddress: String = "destinationAddress"
    private val dropAddress: String = "dropAddress"
    private val currentStep: String = "currentStep"
    private val closeReason: String = "closeReason"
    private val previousEventId: String = "previousEventId"
    private val isDayClose: String = "isDayClose"
    private val isReportConfirm: String = "isReportConfirm"
    private val isEventReopen: String = "isEventReopen"
    private val isReminderSent: String = "isReminderSent"
    private val carId: String = "carId"
    private val reportConfirmAt: String = "reportConfirmAt"
    private val reportConfirmBy: String = "reportConfirmBy"
    private val createdAt: String = "createdAt"
    private val updatedAt: String = "updatedAt"
    private val deletedAt: String = "deletedAt"
    private val userName: String = "userName"
    private val calendarColor: String = "calendarColor"
    private val businessName: String = "businessName"
    private val firstName: String = "firstName"
    private val lastName: String = "lastName"
    private val email: String = "email"
    private val mobile: String = "mobile"
    private val displayId: String = "displayId"
    private val numberPlate: String = "numberPlate"
    private val statusId: String = "statusId"
    private val priority: String = "priority"
    private val leadTypeId: String = "leadTypeId"
    private val orderId: String = "orderId"
    private val lat: String = "lat"
    private val lon: String = "lon"
    private val address: String = "address"
    private val dropLon: String = "dropLon"
    private val enterKm: String = "enterKm"
    private val calendarWorkDisplayId: String = "calendarWorkDisplayId"
    private val note: String = "note"
    private val isNoteRead: String = "isNoteRead"
    private val sedeName: String = "sedeName"
    private val officeCalendarColor: String = "officeCalendarColor"
    private val makeName: String = "makeName"
    private val modelName: String = "modelName"

    private val lead: String = "lead"
    private val lastRequest: String = "lastRequest"
    private val previousRequestEvent: String = "previousRequestEvent"
    private val previousRequestMobileStation: String = "previousRequestMobileStation"

    private val parentLeadId: String = "parentLeadId"
    private val customerDisplayId: String = "customerDisplayId"
    private val customerDocumentId: String = "customerDocumentId"
    private val lastUpdatedBy: String = "lastUpdatedBy"
    private val leadTitle: String = "leadTitle"
    private val pipelineId: String = "pipelineId"
    private val phaseId: String = "phaseId"
    private val ownerId: String = "ownerId"
    private val leadValue: String = "leadValue"
    private val isArchived: String = "isArchived"
    private val billingAddressId: String = "billingAddressId"
    private val shippingAddressId: String = "shippingAddressId"
    private val officeLocationId: String = "officeLocationId"
    private val orderStatusId: String = "orderStatusId"
    private val trafficSource: String = "trafficSource"
    private val requestUrl: String = "requestUrl"
    private val mechanicId: String = "mechanicId"
    private val renewCounter: String = "renewCounter"
    private val accessToken: String = "accessToken"
    private val updatedBy: String = "updatedBy"
    private val locationType: String = "locationType"
    private val dropLat: String = "dropLat"
    private val warehouseInstruction: String = "warehouseInstruction"
    private val stockNote: String = "stockNote"
    private val itemNote: String = "itemNote"
    private val isProblemIdentify: String = "isProblemIdentify"
    private val isWarningLight: String = "isWarningLight"
    private val warningLights: String = "warningLights"
    private val testCentral: String = "testCentral"
    private val isCreatedByMechanic: String = "isCreatedByMechanic"
    private val configuredBy: String = "configuredBy"
    private val isInspection: String = "isInspection"
    private val isNew: String = "isNew"
    private val isRead: String = "isRead"
    private val isManual: String = "isManual"
    private val isUrgent: String = "isUrgent"
    private val isFutureRequest: String = "isFutureRequest"
    private val sosIcon: String = "sosIcon"
    private val reportType: String = "reportType"
    private val reportDescription: String = "reportDescription"
    private val sosRequestId: String = "sosRequestId"
    private val configuredByLocationId: String = "configuredByLocationId"
    private val isWheelChange: String = "isWheelChange"
    private val isAuthorization: String = "isAuthorization"
    private val authorizationCode: String = "authorizationCode"
    private val driverCode: String = "driverCode"
    private val isGa: String = "isGa"
    private val offerPdf: String = "offerPdf"
    private val offerCreatedBy: String = "offerCreatedBy"
    private val createdFrom: String = "createdFrom"
    private val emojiSelection: String = "emojiSelection"
    private val fullName: String = "fullName"
    private val ownerName: String = "ownerName"
    private val ownerEmail: String = "ownerEmail"
    private val ownerMobile: String = "ownerMobile"
    private val createdByName: String = "createdByName"
    private val configuredByName: String = "configuredByName"
    private val pipelineName: String = "pipelineName"
    private val phaseName: String = "phaseName"
    private val locationName: String = "locationName"
    private val locationAddress: String = "locationAddress"
    private val statusName: String = "statusName"
    private val vin: String = "vin"
    private val locationId: String = "locationId"
    private val appointmentCount: String = "appointmentCount"
    private val kmPhotos: String = "kmPhotos"
    private val eventId: String = "eventId"

    private val stepId: String = "stepId"
    private val driverId: String = "driverId"
    private val categoryId: String = "categoryId"
    private val presetCategoryId: String = "presetCategoryId"
    private val presetDescription: String = "presetDescription"
    private val orderDetailId: String = "orderDetailId"
    private val optionType: String = "optionType"
    private val fileType: String = "fileType"
    private val wheelType: String = "wheelType"
    private val generalType: String = "generalType"
    private val stepName: String = "stepName"
    private val driverName: String = "driverName"

    private val updatedByName: String = "updatedByName"
    private val customerWorkPlanStatusId: String = "customerWorkPlanStatusId"
    private val workHours: String = "workHours"
    private val name: String = "name"
    private val state: String = "state"
    private val postalCode: String = "postalCode"
    private val customerId: String = "customerId"
    private val officeIcon: String = "officeIcon"
    private val partnerName: String = "partnerName"
    private val latitude: String = "latitude"
    private val longitude: String = "longitude"
    private val mslid: String = "mslid"

    private val season: String = "season"
    private val width: String = "width"
    private val ratio: String = "ratio"
    private val diameter: String = "diameter"
    private val wheelBrand: String = "wheelBrand"
    private val oldSeason: String = "oldSeason"
    private val oldWidth: String = "oldWidth"
    private val oldRatio: String = "oldRatio"
    private val oldDiameter: String = "oldDiameter"
    private val oldWheelBrand: String = "oldWheelBrand"
    private val newWheelSeason: String = "newWheelSeason"
    private val check1: String = "check1"
    private val check2: String = "check2"
    private val check3: String = "check3"
    private val isCompleted: String = "isCompleted"
    private val isSkip: String = "isSkip"
    private val reason: String = "reason"
    private val presetCategoryName: String = "presetCategoryName"
    private val icon: String = "icon"
    private val stepType: String = "stepType"
    private val leadItems: String = "leadItems"
    private val categories: String = "categories"
    private val images: String = "images"

    private val supplierId: String = "supplierId"
    private val productId: String = "productId"
    private val subCategoryId: String = "subCategoryId"
    private val categorySideId: String = "categorySideId"
    private val installType: String = "installType"
    private val reportNote: String = "reportNote"
    private val inspectionDescription: String = "inspectionDescription"
    private val mechanicNote: String = "mechanicNote"
    private val photos: String = "photos"
    private val documents: String = "documents"
    private val sku: String = "sku"
    private val qty: String = "qty"
    private val itemCost: String = "itemCost"
    private val itemRealCost: String = "itemRealCost"
    private val installedQty: String = "installedQty"
    private val isInstalled: String = "isInstalled"
    private val installedDescription: String = "installedDescription"
    private val installedImages: String = "installedImages"
    private val repairSuggestion: String = "repairSuggestion"
    private val damageLevel: String = "damageLevel"
    private val hourQty: String = "hourQty"
    private val hourCost: String = "hourCost"
    private val hourRealCost: String = "hourRealCost"
    private val totalItemCost: String = "totalItemCost"
    private val totalHourCost: String = "totalHourCost"
    private val totalRealItemCost: String = "totalRealItemCost"
    private val totalRealHourCost: String = "totalRealHourCost"
    private val itemMarginDiscount: String = "itemMarginDiscount"
    private val wheelMm: String = "wheelMm"
    private val wheelPercentage: String = "wheelPercentage"
    private val isAvailable: String = "isAvailable"
    private val isCaricato: String = "isCaricato"
    private val isOrdered: String = "isOrdered"
    private val isArrived: String = "isArrived"
    private val isLoaded: String = "isLoaded"
    private val isTicket: String = "isTicket"
    private val isBufferStock: String = "isBufferStock"
    private val deliveryDate: String = "deliveryDate"
    private val expectedDeliveryDate: String = "expectedDeliveryDate"
    private val userId: String = "userId"
    private val orderDate: String = "orderDate"
    private val itemAvailable: String = "itemAvailable"
    private val itemToOrder: String = "itemToOrder"
    private val isRejected: String = "isRejected"
    private val tempStatus: String = "tempStatus"
    private val isFlag: String = "isFlag"
    private val categoryName: String = "categoryName"
    private val categoryImage: String = "categoryImage"
    private val subCategoryName: String = "subCategoryName"
    private val subCategoryImage: String = "subCategoryImage"
    private val productImage: String = "productImage"
    private val brandImage: String = "brandImage"
    private val productDescription: String = "productDescription"
    private val brandName: String = "brandName"
    private val brandCode: String = "brandCode"
    private val supplierLoginEnable: String = "supplierLoginEnable"
    private val supplierName: String = "supplierName"

    private val orderBy: String = "orderBy"
    private val testDriveId: String = "testDriveId"
    private val image: String = "image"
    private val autoPartiId: String = "autoPartiId"
    private val categoryLink: String = "categoryLink"
    private val categoryType: String = "categoryType"
    private val option1: String = "option1"
    private val option2: String = "option2"
    private val option3: String = "option3"
    private val option4: String = "option4"
    private val option5: String = "option5"
    private val option6: String = "option6"
    private val option7: String = "option7"
    private val option8: String = "option8"
    private val option9: String = "option9"
    private val isPhoto: String = "isPhoto"
    private val montata: String = "montata"
    private val sMontata: String = "sMontata"
    private val photoMontata: String = "photoMontata"
    private val photoSpessimetro: String = "photoSpessimetro"
    private val photoDot: String = "photoDot"
    private val isSelected: String = "isSelected"
    private val isDottedFileUpload: String = "isDottedFileUpload"
    private val isDottedFileUpload2: String = "isDottedFileUpload2"
    private val products: String = "products"

    private val productLink: String = "product_link"
    private val barcode: String = "barcode"
    private val oldPrice: String = "old_price"
    private val newPrice: String = "new_price"
    private val isFavourite: String = "is_favourite"
    private val orderDetails: String = "order_details"

    private val isRecover: String = "isRecover"
    private val recoverNumberPlate: String = "recoverNumberPlate"
    private val invoiceReason: String = "invoiceReason"
    private val invoiceCreatedBy: String = "invoiceCreatedBy"
    private val invoiceDescription: String = "invoiceDescription"
    private val returnPrice: String = "returnPrice"
    private val returnWorkHourCost: String = "returnWorkHourCost"
    private val returnItemCost: String = "returnItemCost"
    private val invoiceWorkHourCost: String = "invoiceWorkHourCost"
    private val invoiceItemCost: String = "invoiceItemCost"
    private val invoicePrice: String = "invoicePrice"
    private val isInvoiced: String = "isInvoiced"
    private val isProposed: String = "isProposed"

    private val proposedBy: String = "proposedBy"
    private val proposedDescription: String = "proposedDescription"
    private val proposedAt: String = "proposedAt"
    private val isConformProposed: String = "isConformProposed"
    private val conformProposedBy: String = "conformProposedBy"
    private val conformProposedDescription: String = "conformProposedDescription"
    private val conformProposedAt: String = "conformProposedAt"
    private val recoverDate: String = "recoverDate"
    private val invoiceCreatedByName: String = "invoiceCreatedByName"
    private val proposalCreatedByName: String = "proposalCreatedByName"


    override fun onCreate(db: SQLiteDatabase?) {
        db?.execSQL(
            "create table "
                    + mechanicEvent + " ("
                    + eventDetail + " TEXT, "
                    + kmDetail + " TEXT, "
                    + workReportSteps + " TEXT, "
                    + id + " TEXT)"
        )

        db?.execSQL(
            "create table "
                    + event + " ("
                    + id + " TEXT, "
                    + leadId + " TEXT, "
                    + title + " TEXT, "
                    + description + " TEXT, "
                    + contactId + " TEXT, "
                    + createdBy + " TEXT, "
                    + parentEventId + " TEXT, "
                    + calendarWorkPlanId + " TEXT, "
                    + customerWorkPlanId + " TEXT, "
                    + objectType + " TEXT, "
                    + actionDate + " TEXT, "
                    + mobileStationId + " TEXT, "
                    + fileName + " TEXT, "
                    + fileLocation + " TEXT, "
                    + completed + " TEXT, "
                    + assignTo + " TEXT, "
                    + startDate + " TEXT, "
                    + endDate + " TEXT, "
                    + workWithUserId + " TEXT, "
                    + appointmentRepeatCount + " TEXT, "
                    + appointmentRepeatOption + " TEXT, "
                    + remindCron + " TEXT, "
                    + repeatAppointmentMainId + " TEXT, "
                    + isVisible + " TEXT, "
                    + parentId + " TEXT, "
                    + isAllday + " TEXT, "
                    + eventNotification + " TEXT, "
                    + notificationDuration + " TEXT, "
                    + notificationOption + " TEXT, "
                    + mainEventId + " TEXT, "
                    + workWithIds + " TEXT, "
                    + isConfirm + " TEXT, "
                    + inviteEmail + " TEXT, "
                    + callAppointment + " TEXT, "
                    + appointmentRequestFrom + " TEXT, "
                    + isPending + " TEXT, "
                    + deleted + " TEXT, "
                    + confirmedAt + " TEXT, "
                    + isClosed + " TEXT, "
                    + isWorkNotDone + " TEXT, "
                    + closedAt + " TEXT, "
                    + travelStart + " TEXT, "
                    + travelEnd + " TEXT, "
                    + travelTime + " TEXT, "
                    + totalKm + " TEXT, "
                    + isEventStart + " TEXT, "
                    + isTravelCompleted + " TEXT, "
                    + towRequestAccepted + " TEXT, "
                    + isPicked + " TEXT, "
                    + isManualReport + " TEXT, "
                    + isPauseTravel + " TEXT, "
                    + workStartTime + " TEXT, "
                    + workEndTime + " TEXT, "
                    + mechanicWorkStartTime + " TEXT, "
                    + mechanicWorkEndTime + " TEXT, "
                    + mechanicTravelStartTime + " TEXT, "
                    + mechanicTravelEndTime + " TEXT, "
                    + mechanicTravelBreakStart + " TEXT, "
                    + mechanicTravelBreakEnd + " TEXT, "
                    + mechanicTravelRestart + " TEXT, "
                    + mobileStationLat + " TEXT, "
                    + mobileStationLon + " TEXT, "
                    + sourceAddress + " TEXT, "
                    + destinationAddress + " TEXT, "
                    + dropAddress + " TEXT, "
                    + currentStep + " TEXT, "
                    + closeReason + " TEXT, "
                    + previousEventId + " TEXT, "
                    + isDayClose + " TEXT, "
                    + isReportConfirm + " TEXT, "
                    + isEventReopen + " TEXT, "
                    + isReminderSent + " TEXT, "
                    + carId + " TEXT, "
                    + reportConfirmAt + " TEXT, "
                    + reportConfirmBy + " TEXT, "
                    + createdAt + " TEXT, "
                    + updatedAt + " TEXT, "
                    + deletedAt + " TEXT, "
                    + userName + " TEXT, "
                    + calendarColor + " TEXT, "
                    + businessName + " TEXT, "
                    + firstName + " TEXT, "
                    + lastName + " TEXT, "
                    + email + " TEXT, "
                    + mobile + " TEXT, "
                    + displayId + " TEXT, "
                    + numberPlate + " TEXT, "
                    + statusId + " TEXT, "
                    + priority + " TEXT, "
                    + leadTypeId + " TEXT, "
                    + orderId + " TEXT, "
                    + lat + " TEXT, "
                    + lon + " TEXT, "
                    + address + " TEXT, "
                    + dropLon + " TEXT, "
                    + enterKm + " TEXT, "
                    + calendarWorkDisplayId + " TEXT, "
                    + note + " TEXT, "
                    + isNoteRead + " TEXT, "
                    + sedeName + " TEXT, "
                    + officeCalendarColor + " TEXT, "
                    + makeName + " TEXT, "
                    + modelName + " TEXT)"
        )

        db?.execSQL(
            "create table "
                    + kmDetailData + " ("
                    + lead + " TEXT, "
                    + lastRequest + " TEXT, "
                    + previousRequestEvent + " TEXT, "
                    + previousRequestMobileStation + " TEXT, "
                    + id + " TEXT)"
        )

        db?.execSQL(
            "create table "
                    + kmLeadData + " ("
                    + id + " TEXT, "
                    + displayId + " TEXT, "
                    + numberPlate + " TEXT, "
                    + contactId + " TEXT, "
                    + createdBy + " TEXT, "
                    + parentLeadId + " TEXT, "
                    + customerDisplayId + " TEXT, "
                    + customerDocumentId + " TEXT, "
                    + lastUpdatedBy + " TEXT, "
                    + leadTitle + " TEXT, "
                    + description + " TEXT, "
                    + pipelineId + " TEXT, "
                    + phaseId + " TEXT, "
                    + ownerId + " TEXT, "
                    + leadValue + " TEXT, "
                    + isArchived + " TEXT, "
                    + priority + " TEXT, "
                    + parentId + " TEXT, "
                    + billingAddressId + " TEXT, "
                    + shippingAddressId + " TEXT, "
                    + leadTypeId + " TEXT, "
                    + carId + " TEXT, "
                    + officeLocationId + " TEXT, "
                    + statusId + " TEXT, "
                    + orderStatusId + " TEXT, "
                    + trafficSource + " TEXT, "
                    + requestUrl + " TEXT, "
                    + mechanicId + " TEXT, "
                    + renewCounter + " TEXT, "
                    + accessToken + " TEXT, "
                    + updatedBy + " TEXT, "
                    + locationType + " TEXT, "
                    + lat + " TEXT, "
                    + lon + " TEXT, "
                    + address + " TEXT, "
                    + dropLat + " TEXT, "
                    + dropLon + " TEXT, "
                    + dropAddress + " TEXT, "
                    + warehouseInstruction + " TEXT, "
                    + stockNote + " TEXT, "
                    + itemNote + " TEXT, "
                    + isProblemIdentify + " TEXT, "
                    + isWarningLight + " TEXT, "
                    + warningLights + " TEXT, "
                    + testCentral + " TEXT, "
                    + orderId + " TEXT, "
                    + isCreatedByMechanic + " TEXT, "
                    + configuredBy + " TEXT, "
                    + isInspection + " TEXT, "
                    + isNew + " TEXT, "
                    + isRead + " TEXT, "
                    + isManual + " TEXT, "
                    + isUrgent + " TEXT, "
                    + isFutureRequest + " TEXT, "
                    + sosIcon + " TEXT, "
                    + customerWorkPlanId + " TEXT, "
                    + reportType + " TEXT, "
                    + isReportConfirm + " TEXT, "
                    + reportDescription + " TEXT, "
                    + sosRequestId + " TEXT, "
                    + enterKm + " TEXT, "
                    + isDayClose + " TEXT, "
                    + closeReason + " TEXT, "
                    + configuredByLocationId + " TEXT, "
                    + isWheelChange + " TEXT, "
                    + isAuthorization + " TEXT, "
                    + authorizationCode + " TEXT, "
                    + driverCode + " TEXT, "
                    + isGa + " TEXT, "
                    + offerPdf + " TEXT, "
                    + offerCreatedBy + " TEXT, "
                    + createdFrom + " TEXT, "
                    + emojiSelection + " TEXT, "
                    + deleted + " TEXT, "
                    + createdAt + " TEXT, "
                    + updatedAt + " TEXT, "
                    + firstName + " TEXT, "
                    + lastName + " TEXT, "
                    + businessName + " TEXT, "
                    + fullName + " TEXT, "
                    + email + " TEXT, "
                    + mobile + " TEXT, "
                    + ownerName + " TEXT, "
                    + ownerEmail + " TEXT, "
                    + ownerMobile + " TEXT, "
                    + createdByName + " TEXT, "
                    + configuredByName + " TEXT, "
                    + pipelineName + " TEXT, "
                    + phaseName + " TEXT, "
                    + locationName + " TEXT, "
                    + locationAddress + " TEXT, "
                    + makeName + " TEXT, "
                    + modelName + " TEXT, "
                    + statusName + " TEXT, "
                    + vin + " TEXT, "
                    + locationId + " TEXT, "
                    + sedeName + " TEXT, "
                    + appointmentCount + " TEXT, "
                    + kmPhotos + " TEXT, "
                    + eventId + " TEXT)"
        )

        db?.execSQL(
            "create table "
                    + kmPhoto + " ("
                    + id + " TEXT, "
                    + leadId + " TEXT, "
                    + stepId + " TEXT, "
                    + carId + " TEXT, "
                    + driverId + " TEXT, "
                    + categoryId + " TEXT, "
                    + presetCategoryId + " TEXT, "
                    + orderDetailId + " TEXT, "
                    + fileName + " TEXT, "
                    + fileLocation + " TEXT, "
                    + optionType + " TEXT, "
                    + fileType + " TEXT, "
                    + wheelType + " TEXT, "
                    + generalType + " TEXT, "
                    + createdBy + " TEXT, "
                    + deleted + " TEXT, "
                    + createdAt + " TEXT, "
                    + updatedAt + " TEXT, "
                    + stepName + " TEXT, "
                    + driverName + " TEXT, "
                    + eventId + " TEXT)"
        )

        db?.execSQL(
            "create table "
                    + kmLastRequest + " ("
                    + id + " TEXT, "
                    + displayId + " TEXT, "
                    + numberPlate + " TEXT, "
                    + contactId + " TEXT, "
                    + createdBy + " TEXT, "
                    + parentLeadId + " TEXT, "
                    + customerDisplayId + " TEXT, "
                    + customerDocumentId + " TEXT, "
                    + lastUpdatedBy + " TEXT, "
                    + leadTitle + " TEXT, "
                    + description + " TEXT, "
                    + pipelineId + " TEXT, "
                    + phaseId + " TEXT, "
                    + ownerId + " TEXT, "
                    + leadValue + " TEXT, "
                    + isArchived + " TEXT, "
                    + priority + " TEXT, "
                    + parentId + " TEXT, "
                    + billingAddressId + " TEXT, "
                    + shippingAddressId + " TEXT, "
                    + leadTypeId + " TEXT, "
                    + carId + " TEXT, "
                    + officeLocationId + " TEXT, "
                    + statusId + " TEXT, "
                    + orderStatusId + " TEXT, "
                    + trafficSource + " TEXT, "
                    + requestUrl + " TEXT, "
                    + mechanicId + " TEXT, "
                    + renewCounter + " TEXT, "
                    + accessToken + " TEXT, "
                    + updatedBy + " TEXT, "
                    + locationType + " TEXT, "
                    + lat + " TEXT, "
                    + lon + " TEXT, "
                    + address + " TEXT, "
                    + dropLat + " TEXT, "
                    + dropLon + " TEXT, "
                    + dropAddress + " TEXT, "
                    + warehouseInstruction + " TEXT, "
                    + stockNote + " TEXT, "
                    + itemNote + " TEXT, "
                    + isProblemIdentify + " TEXT, "
                    + isWarningLight + " TEXT, "
                    + warningLights + " TEXT, "
                    + testCentral + " TEXT, "
                    + orderId + " TEXT, "
                    + isCreatedByMechanic + " TEXT, "
                    + configuredBy + " TEXT, "
                    + isInspection + " TEXT, "
                    + isNew + " TEXT, "
                    + isRead + " TEXT, "
                    + isManual + " TEXT, "
                    + isUrgent + " TEXT, "
                    + isFutureRequest + " TEXT, "
                    + sosIcon + " TEXT, "
                    + customerWorkPlanId + " TEXT, "
                    + reportType + " TEXT, "
                    + isReportConfirm + " TEXT, "
                    + reportDescription + " TEXT, "
                    + sosRequestId + " TEXT, "
                    + enterKm + " TEXT, "
                    + isDayClose + " TEXT, "
                    + closeReason + " TEXT, "
                    + configuredByLocationId + " TEXT, "
                    + isWheelChange + " TEXT, "
                    + isAuthorization + " TEXT, "
                    + authorizationCode + " TEXT, "
                    + driverCode + " TEXT, "
                    + isGa + " TEXT, "
                    + offerPdf + " TEXT, "
                    + offerCreatedBy + " TEXT, "
                    + createdFrom + " TEXT, "
                    + emojiSelection + " TEXT, "
                    + deleted + " TEXT, "
                    + createdAt + " TEXT, "
                    + updatedAt + " TEXT, "
                    + updatedByName + " TEXT, "
                    + eventId + " TEXT)"
        )

        db?.execSQL(
            "create table "
                    + kmPreviousRequestEvent + " ("
                    + id + " TEXT, "
                    + leadId + " TEXT, "
                    + title + " TEXT, "
                    + description + " TEXT, "
                    + contactId + " TEXT, "
                    + createdBy + " TEXT, "
                    + parentEventId + " TEXT, "
                    + calendarWorkPlanId + " TEXT, "
                    + customerWorkPlanId + " TEXT, "
                    + objectType + " TEXT, "
                    + actionDate + " TEXT, "
                    + mobileStationId + " TEXT, "
                    + fileName + " TEXT, "
                    + fileLocation + " TEXT, "
                    + completed + " TEXT, "
                    + assignTo + " TEXT, "
                    + startDate + " TEXT, "
                    + endDate + " TEXT, "
                    + workWithUserId + " TEXT, "
                    + appointmentRepeatCount + " TEXT, "
                    + appointmentRepeatOption + " TEXT, "
                    + remindCron + " TEXT, "
                    + repeatAppointmentMainId + " TEXT, "
                    + isVisible + " TEXT, "
                    + parentId + " TEXT, "
                    + isAllday + " TEXT, "
                    + eventNotification + " TEXT, "
                    + notificationDuration + " TEXT, "
                    + notificationOption + " TEXT, "
                    + mainEventId + " TEXT, "
                    + workWithIds + " TEXT, "
                    + isConfirm + " TEXT, "
                    + inviteEmail + " TEXT, "
                    + callAppointment + " TEXT, "
                    + appointmentRequestFrom + " TEXT, "
                    + isPending + " TEXT, "
                    + deleted + " TEXT, "
                    + confirmedAt + " TEXT, "
                    + isClosed + " TEXT, "
                    + closedAt + " TEXT, "
                    + travelStart + " TEXT, "
                    + travelEnd + " TEXT, "
                    + travelTime + " TEXT, "
                    + totalKm + " TEXT, "
                    + isEventStart + " TEXT, "
                    + isTravelCompleted + " TEXT, "
                    + towRequestAccepted + " TEXT, "
                    + isPicked + " TEXT, "
                    + isManualReport + " TEXT, "
                    + isPauseTravel + " TEXT, "
                    + workStartTime + " TEXT, "
                    + workEndTime + " TEXT, "
                    + mechanicWorkStartTime + " TEXT, "
                    + mechanicWorkEndTime + " TEXT, "
                    + mechanicTravelStartTime + " TEXT, "
                    + mechanicTravelEndTime + " TEXT, "
                    + mechanicTravelBreakStart + " TEXT, "
                    + mechanicTravelBreakEnd + " TEXT, "
                    + mechanicTravelRestart + " TEXT, "
                    + mobileStationLat + " TEXT, "
                    + mobileStationLon + " TEXT, "
                    + sourceAddress + " TEXT, "
                    + destinationAddress + " TEXT, "
                    + dropAddress + " TEXT, "
                    + workHours + " TEXT, "
                    + currentStep + " TEXT, "
                    + closeReason + " TEXT, "
                    + isWorkNotDone + " TEXT, "
                    + previousEventId + " TEXT, "
                    + isDayClose + " TEXT, "
                    + isReportConfirm + " TEXT, "
                    + isEventReopen + " TEXT, "
                    + isReminderSent + " TEXT, "
                    + carId + " TEXT, "
                    + reportConfirmAt + " TEXT, "
                    + reportConfirmBy + " TEXT, "
                    + createdAt + " TEXT, "
                    + updatedAt + " TEXT, "
                    + deletedAt + " TEXT, "
                    + userName + " TEXT, "
                    + calendarColor + " TEXT, "
                    + businessName + " TEXT, "
                    + firstName + " TEXT, "
                    + lastName + " TEXT, "
                    + email + " TEXT, "
                    + mobile + " TEXT, "
                    + displayId + " TEXT, "
                    + numberPlate + " TEXT, "
                    + statusId + " TEXT, "
                    + priority + " TEXT, "
                    + leadTypeId + " TEXT, "
                    + orderId + " TEXT, "
                    + lat + " TEXT, "
                    + lon + " TEXT, "
                    + address + " TEXT, "
                    + dropLat + " TEXT, "
                    + dropLon + " TEXT, "
                    + enterKm + " TEXT, "
                    + calendarWorkDisplayId + " TEXT, "
                    + note + " TEXT, "
                    + isNoteRead + " TEXT, "
                    + customerWorkPlanStatusId + " TEXT, "
                    + sedeName + " TEXT, "
                    + officeCalendarColor + " TEXT, "
                    + makeName + " TEXT, "
                    + modelName + " TEXT, "
                    + eventId + " TEXT)"
        )

        db?.execSQL(
            "create table "
                    + kmPreviousRequestMobileStation + " ("
                    + id + " TEXT, "
                    + carId + " TEXT, "
                    + displayId + " TEXT, "
                    + name + " TEXT, "
                    + address + " TEXT, "
                    + state + " TEXT, "
                    + postalCode + " TEXT, "
                    + lat + " TEXT, "
                    + lon + " TEXT, "
                    + customerId + " TEXT, "
                    + locationType + " TEXT, "
                    + parentId + " TEXT, "
                    + officeIcon + " TEXT, "
                    + calendarColor + " TEXT, "
                    + partnerName + " TEXT, "
                    + deleted + " TEXT, "
                    + createdAt + " TEXT, "
                    + updatedAt + " TEXT, "
                    + latitude + " TEXT, "
                    + longitude + " TEXT, "
                    + mslid + " TEXT, "
                    + numberPlate + " TEXT, "
                    + eventId + " TEXT)"
        )

        db?.execSQL(
            "create table "
                    + eventWorkReportSteps + " ("
                    + id + " TEXT, "
                    + carId + " TEXT, "
                    + leadId + " TEXT, "
                    + presetCategoryId + " TEXT, "
                    + presetDescription + " TEXT, "
                    + season + " TEXT, "
                    + width + " TEXT, "
                    + ratio + " TEXT, "
                    + diameter + " TEXT, "
                    + wheelBrand + " TEXT, "
                    + oldSeason + " TEXT, "
                    + oldWidth + " TEXT, "
                    + oldRatio + " TEXT, "
                    + oldDiameter + " TEXT, "
                    + oldWheelBrand + " TEXT, "
                    + newWheelSeason + " TEXT, "
                    + check1 + " TEXT, "
                    + check2 + " TEXT, "
                    + check3 + " TEXT, "
                    + isCompleted + " TEXT, "
                    + isSkip + " TEXT, "
                    + reason + " TEXT, "
                    + createdBy + " TEXT, "
                    + deleted + " TEXT, "
                    + createdAt + " TEXT, "
                    + updatedAt + " TEXT, "
                    + presetCategoryName + " TEXT, "
                    + icon + " TEXT, "
                    + stepType + " TEXT, "
                    + leadItems + " TEXT, "
                    + categories + " TEXT, "
                    + images + " TEXT, "
                    + eventId + " TEXT, "
                    + isCreatedByMechanic + " TEXT)"
        )

        db?.execSQL(
            "create table "
                    + kmLeadItems + " ("
                    + id + " TEXT, "
                    + orderId + " TEXT, "
                    + supplierId + " TEXT, "
                    + productId + " TEXT, "
                    + categoryId + " TEXT, "
                    + subCategoryId + " TEXT, "
                    + presetCategoryId + " TEXT, "
                    + stepId + " TEXT, "
                    + categorySideId + " TEXT, "
                    + installType + " TEXT, "
                    + reportNote + " TEXT, "
                    + inspectionDescription + " TEXT, "
                    + mechanicNote + " TEXT, "
                    + photos + " TEXT, "
                    + documents + " TEXT, "
                    + title + " TEXT, "
                    + sku + " TEXT, "
                    + qty + " TEXT, "
                    + itemCost + " TEXT, "
                    + itemRealCost + " TEXT, "
                    + installedQty + " TEXT, "
                    + isInstalled + " TEXT, "
                    + installedDescription + " TEXT, "
                    + installedImages + " TEXT, "
                    + repairSuggestion + " TEXT, "
                    + damageLevel + " TEXT, "
                    + hourQty + " TEXT, "
                    + hourCost + " TEXT, "
                    + hourRealCost + " TEXT, "
                    + totalItemCost + " TEXT, "
                    + totalHourCost + " TEXT, "
                    + totalRealItemCost + " TEXT, "
                    + totalRealHourCost + " TEXT, "
                    + itemMarginDiscount + " TEXT, "
                    + wheelMm + " TEXT, "
                    + wheelPercentage + " TEXT, "
                    + wheelType + " TEXT, "
                    + isAvailable + " TEXT, "
                    + isCaricato + " TEXT, "
                    + isOrdered + " TEXT, "
                    + isArrived + " TEXT, "
                    + isLoaded + " TEXT, "
                    + isTicket + " TEXT, "
                    + isBufferStock + " TEXT, "
                    + deliveryDate + " TEXT, "
                    + expectedDeliveryDate + " TEXT, "
                    + userId + " TEXT, "
                    + orderDate + " TEXT, "
                    + itemAvailable + " TEXT, "
                    + itemToOrder + " TEXT, "
                    + isRejected + " TEXT, "
                    + tempStatus + " TEXT, "
                    + reason + " TEXT, "
                    + isGa + " TEXT, "
                    + isFlag + " TEXT, "
                    + deleted + " TEXT, "
                    + updatedAt + " TEXT, "
                    + createdAt + " TEXT, "
                    + categoryName + " TEXT, "
                    + categoryImage + " TEXT, "
                    + subCategoryName + " TEXT, "
                    + subCategoryImage + " TEXT, "
                    + productImage + " TEXT, "
                    + brandImage + " TEXT, "
                    + productDescription + " TEXT, "
                    + brandName + " TEXT, "
                    + brandCode + " TEXT, "
                    + supplierLoginEnable + " TEXT, "
                    + supplierName + " TEXT, "
                    + images + " TEXT, "
                    + eventId + " TEXT)"
        )

        db?.execSQL(
            "create table "
                    + kmCategories + " ("
                    + id + " TEXT, "
                    + name + " TEXT, "
                    + orderBy + " TEXT, "
                    + parentId + " TEXT, "
                    + testDriveId + " TEXT, "
                    + image + " TEXT, "
                    + autoPartiId + " TEXT, "
                    + categoryLink + " TEXT, "
                    + categoryType + " TEXT, "
                    + option1 + " TEXT, "
                    + option2 + " TEXT, "
                    + option3 + " TEXT, "
                    + option4 + " TEXT, "
                    + option5 + " TEXT, "
                    + option6 + " TEXT, "
                    + option7 + " TEXT, "
                    + option8 + " TEXT, "
                    + option9 + " TEXT, "
                    + deleted + " TEXT, "
                    + isPhoto + " TEXT, "
                    + createdAt + " TEXT, "
                    + updatedAt + " TEXT, "
                    + montata + " TEXT, "
                    + sMontata + " TEXT, "
                    + photoMontata + " TEXT, "
                    + photoSpessimetro + " TEXT, "
                    + photoDot + " TEXT, "
                    + isSelected + " TEXT, "
                    + isDottedFileUpload + " TEXT, "
                    + isDottedFileUpload2 + " TEXT, "
                    + products + " TEXT, "
                    + eventId + " TEXT)"
        )

        db?.execSQL(
            "create table "
                    + kmProducts + " ("
                    + id + " TEXT, "
                    + image + " TEXT, "
                    + brandImage + " TEXT, "
                    + brandName + " TEXT, "
                    + brandCode + " TEXT, "
                    + productLink + " TEXT, "
                    + sku + " TEXT, "
                    + barcode + " TEXT, "
                    + title + " TEXT, "
                    + description + " TEXT, "
                    + oldPrice + " TEXT, "
                    + newPrice + " TEXT, "
                    + isFavourite + " TEXT, "
                    + deleted + " TEXT, "
                    + createdAt + " TEXT, "
                    + updatedAt + " TEXT, "
                    + orderDetails + " TEXT, "
                    + eventId + " TEXT)"
        )


        db?.execSQL(
            "create table "
                    + kmOrderDetails + " ("
                    + id + " TEXT, "
                    + orderId + " TEXT, "
                    + supplierId + " TEXT, "
                    + productId + " TEXT, "
                    + categoryId + " TEXT, "
                    + subCategoryId + " TEXT, "
                    + presetCategoryId + " TEXT, "
                    + stepId + " TEXT, "
                    + categorySideId + " TEXT, "
                    + installType + " TEXT, "
                    + reportNote + " TEXT, "
                    + inspectionDescription + " TEXT, "
                    + mechanicNote + " TEXT, "
                    + photos + " TEXT, "
                    + documents + " TEXT, "
                    + title + " TEXT, "
                    + sku + " TEXT, "
                    + qty + " TEXT, "
                    + itemCost + " TEXT, "
                    + itemRealCost + " TEXT, "
                    + installedQty + " TEXT, "
                    + isInstalled + " TEXT, "
                    + installedDescription + " TEXT, "
                    + installedImages + " TEXT, "
                    + repairSuggestion + " TEXT, "
                    + damageLevel + " TEXT, "
                    + hourQty + " TEXT, "
                    + hourCost + " TEXT, "
                    + hourRealCost + " TEXT, "
                    + totalItemCost + " TEXT, "
                    + totalHourCost + " TEXT, "
                    + totalRealItemCost + " TEXT, "
                    + totalRealHourCost + " TEXT, "
                    + itemMarginDiscount + " TEXT, "
                    + wheelMm + " TEXT, "
                    + wheelPercentage + " TEXT, "
                    + wheelType + " TEXT, "
                    + isAvailable + " TEXT, "
                    + isCaricato + " TEXT, "
                    + isOrdered + " TEXT, "
                    + isArrived + " TEXT, "
                    + isLoaded + " TEXT, "
                    + isTicket + " TEXT, "
                    + isBufferStock + " TEXT, "
                    + deliveryDate + " TEXT, "
                    + expectedDeliveryDate + " TEXT, "
                    + userId + " TEXT, "
                    + orderDate + " TEXT, "
                    + itemAvailable + " TEXT, "
                    + itemToOrder + " TEXT, "
                    + isRejected + " TEXT, "
                    + tempStatus + " TEXT, "
                    + reason + " TEXT, "
                    + isGa + " TEXT, "
                    + isFlag + " TEXT, "
                    + isRecover + " TEXT, "
                    + recoverNumberPlate + " TEXT, "
                    + invoiceReason + " TEXT, "
                    + invoiceCreatedBy + " TEXT, "
                    + invoiceDescription + " TEXT, "
                    + returnPrice + " TEXT, "
                    + returnWorkHourCost + " TEXT, "
                    + returnItemCost + " TEXT, "
                    + invoiceWorkHourCost + " TEXT, "
                    + invoiceItemCost + " TEXT, "
                    + invoicePrice + " TEXT, "
                    + isInvoiced + " TEXT, "
                    + isProposed + " TEXT, "
                    + proposedBy + " TEXT, "
                    + proposedDescription + " TEXT, "
                    + proposedAt + " TEXT, "
                    + isConformProposed + " TEXT, "
                    + conformProposedBy + " TEXT, "
                    + conformProposedDescription + " TEXT, "
                    + conformProposedAt + " TEXT, "
                    + recoverDate + " TEXT, "
                    + mobileStationId + " TEXT, "
                    + deleted + " TEXT, "
                    + updatedAt + " TEXT, "
                    + createdAt + " TEXT, "
                    + categoryName + " TEXT, "
                    + categoryImage + " TEXT, "
                    + subCategoryName + " TEXT, "
                    + subCategoryImage + " TEXT, "
                    + productImage + " TEXT, "
                    + brandImage + " TEXT, "
                    + productDescription + " TEXT, "
                    + brandName + " TEXT, "
                    + brandCode + " TEXT, "
                    + supplierLoginEnable + " TEXT, "
                    + supplierName + " TEXT, "
                    + invoiceCreatedByName + " TEXT, "
                    + proposalCreatedByName + " TEXT,"
                    + eventId + " TEXT)"
        )

        db?.execSQL(
            "create table "
                    + montataData + " ("
                    + id + " TEXT, "
                    + orderId + " TEXT, "
                    + supplierId + " TEXT, "
                    + productId + " TEXT, "
                    + categoryId + " TEXT, "
                    + subCategoryId + " TEXT, "
                    + presetCategoryId + " TEXT, "
                    + stepId + " TEXT, "
                    + categorySideId + " TEXT, "
                    + installType + " TEXT, "
                    + reportNote + " TEXT, "
                    + inspectionDescription + " TEXT, "
                    + mechanicNote + " TEXT, "
                    + photos + " TEXT, "
                    + documents + " TEXT, "
                    + title + " TEXT, "
                    + sku + " TEXT, "
                    + qty + " TEXT, "
                    + itemCost + " TEXT, "
                    + itemRealCost + " TEXT, "
                    + installedQty + " TEXT, "
                    + isInstalled + " TEXT, "
                    + installedDescription + " TEXT, "
                    + installedImages + " TEXT, "
                    + repairSuggestion + " TEXT, "
                    + damageLevel + " TEXT, "
                    + hourQty + " TEXT, "
                    + hourCost + " TEXT, "
                    + hourRealCost + " TEXT, "
                    + totalItemCost + " TEXT, "
                    + totalHourCost + " TEXT, "
                    + totalRealItemCost + " TEXT, "
                    + totalRealHourCost + " TEXT, "
                    + itemMarginDiscount + " TEXT, "
                    + wheelMm + " TEXT, "
                    + wheelPercentage + " TEXT, "
                    + wheelType + " TEXT, "
                    + isAvailable + " TEXT, "
                    + isCaricato + " TEXT, "
                    + isOrdered + " TEXT, "
                    + isArrived + " TEXT, "
                    + isLoaded + " TEXT, "
                    + isTicket + " TEXT, "
                    + isBufferStock + " TEXT, "
                    + deliveryDate + " TEXT, "
                    + expectedDeliveryDate + " TEXT, "
                    + userId + " TEXT, "
                    + orderDate + " TEXT, "
                    + itemAvailable + " TEXT, "
                    + itemToOrder + " TEXT, "
                    + isRejected + " TEXT, "
                    + tempStatus + " TEXT, "
                    + reason + " TEXT, "
                    + isGa + " TEXT, "
                    + deleted + " TEXT, "
                    + updatedAt + " TEXT, "
                    + createdAt + " TEXT)"
        )

    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        println("oldVersion = $oldVersion | newVersion = $newVersion")
    }


    fun addData(data: MechanicEventJson): Boolean {

        addEvent(data.eventDetail!!)
        addKmDetail(data.kmDetail!!, data.eventDetail?.id)
        for (temp in data.workReportSteps!!) {
            addWorkReportSteps(temp, data.eventDetail?.id)
        }

        val db = writableDatabase
        val values = ContentValues()

        values.put(eventDetail, data.eventDetail?.id)
        values.put(kmDetail, data.eventDetail?.id)
        values.put(workReportSteps, data.eventDetail?.id)
        values.put(id, data.eventDetail?.id)

        val result = db.insert(mechanicEvent, null, values)
        if (db.isOpen) {
            db.close()
        }
        return result != -1L
    }

    fun viewData(idTemp: Int): MechanicEventJson {

        val cursor: Cursor = writableDatabase.rawQuery(
            "select * from $mechanicEvent where $id = '$idTemp'", null
        )

        val temp = MechanicEventJson()

        if (cursor.count != 0) {
            while (cursor.moveToNext()) {

                temp.eventDetail = getEvent(cursor.getInt(0))
                temp.kmDetail = getKmDetail(cursor.getInt(1))
                temp.workReportSteps = getWorkReportSteps(cursor.getInt(2))

            }
        }

        cursor.close()

        return temp
    }


    private fun addWorkReportSteps(data: MechanicEventWorkReportSteps, idTemp: Int?): Boolean {

        for (temp in data.leadItems!!) {
            addLeadItem(temp, data.id)
        }
        if (data.categories != null) {
            for (temp in data.categories!!) {
                addCategories(temp, data.id)
            }
        }
        for (temp in data.images) {
            if (temp.id != null) {
                addKmPhoto(temp, data.id)
            }
        }

        val db = writableDatabase
        val values = ContentValues()

        values.put(id, data.id)
        values.put(carId, data.carId)
        values.put(leadId, data.leadId)
        values.put(presetCategoryId, data.presetCategoryId)
        values.put(presetDescription, data.presetDescription)
        values.put(season, data.season)
        values.put(width, data.width)
        values.put(ratio, data.ratio)
        values.put(diameter, data.diameter)
        values.put(wheelBrand, data.wheelBrand)
        values.put(oldSeason, data.oldSeason)
        values.put(oldWidth, data.oldWidth)
        values.put(oldRatio, data.oldRatio)
        values.put(oldDiameter, data.oldDiameter)
        values.put(oldWheelBrand, data.oldWheelBrand)
        values.put(newWheelSeason, data.newWheelSeason)
        values.put(check1, data.check1)
        values.put(check2, data.check2)
        values.put(check3, data.check3)
        values.put(isCompleted, data.isCompleted)
        values.put(isSkip, data.isSkip)
        values.put(reason, data.reason)
        values.put(createdBy, data.createdBy)
        values.put(deleted, data.deleted)
        values.put(createdAt, data.createdAt)
        values.put(updatedAt, data.updatedAt)
        values.put(presetCategoryName, data.presetCategoryName)
        values.put(icon, data.icon)
        values.put(stepType, data.stepType)
        values.put(leadItems, data.id)
        values.put(categories, data.id)
        values.put(images, data.id)
        values.put(eventId, idTemp)
        values.put(isCreatedByMechanic, data.isCreatedByMechanic)

        val result = db.insert(eventWorkReportSteps, null, values)
        if (db.isOpen) {
            db.close()
        }
        return result != -1L

    }

    private fun getWorkReportSteps(idTemp: Int): ArrayList<MechanicEventWorkReportSteps> {

        val cursor: Cursor = writableDatabase.rawQuery(
            "select * from $eventWorkReportSteps where $eventId = '$idTemp'", null
        )

        val data = ArrayList<MechanicEventWorkReportSteps>()

        if (cursor.count != 0) {
            while (cursor.moveToNext()) {

                val temp = MechanicEventWorkReportSteps()

                temp.id = cursor.getInt(0)
                temp.carId = cursor.getInt(1)
                temp.leadId = cursor.getInt(2)
                temp.presetCategoryId = cursor.getInt(3)
                temp.presetDescription = cursor.getString(4)
                temp.season = cursor.getString(5)
                temp.width = cursor.getString(6)
                temp.ratio = cursor.getString(7)
                temp.diameter = cursor.getString(8)
                temp.wheelBrand = cursor.getString(9)
                temp.oldSeason = cursor.getString(10)
                temp.oldWidth = cursor.getString(11)
                temp.oldRatio = cursor.getString(12)
                temp.oldDiameter = cursor.getString(13)
                temp.oldWheelBrand = cursor.getString(14)
                temp.newWheelSeason = cursor.getString(15)
                temp.check1 = cursor.getString(16)
                temp.check2 = cursor.getString(17)
                temp.check3 = cursor.getString(18)
                temp.isCompleted = cursor.getString(19)
                temp.isSkip = cursor.getString(20)
                temp.reason = cursor.getString(21)
                temp.createdBy = cursor.getInt(22)
                temp.deleted = cursor.getString(23)
                temp.createdAt = cursor.getString(24)
                temp.updatedAt = cursor.getString(25)
                temp.presetCategoryName = cursor.getString(26)
                temp.icon = cursor.getString(27)
                temp.stepType = cursor.getString(28)
                temp.leadItems = getLeadItem(cursor.getInt(29))
                temp.categories = getCategories(cursor.getInt(30))
                temp.images = getKmPhoto(cursor.getInt(31))
                temp.eventId = cursor.getInt(32)
                temp.isCreatedByMechanic = cursor.getString(33)

                data.add(temp)
            }
        }

        cursor.close()

        return removeDuplicates(data)
    }


    private fun addLeadItem(data: MechanicKmLeadItems, idTemp: Int?): Boolean {

        data.images?.let {
            for (temp in data.images!!) {
                if (temp.id != null) {
                    addKmPhoto(temp, idTemp)
                }
            }
        }

        val db = writableDatabase
        val values = ContentValues()

        values.put(id, data.id)
        values.put(orderId, data.orderId)
        values.put(supplierId, data.supplierId)
        values.put(productId, data.productId)
        values.put(categoryId, data.categoryId)
        values.put(subCategoryId, data.subCategoryId)
        values.put(presetCategoryId, data.presetCategoryId)
        values.put(stepId, data.stepId)
        values.put(categorySideId, data.categorySideId)
        values.put(installType, data.installType)
        values.put(reportNote, data.reportNote)
        values.put(inspectionDescription, data.inspectionDescription)
        values.put(mechanicNote, data.mechanicNote)
        values.put(photos, data.photos)
        values.put(documents, data.documents)
        values.put(title, data.title)
        values.put(sku, data.sku)
        values.put(qty, data.qty)
        values.put(itemCost, data.itemCost)
        values.put(itemRealCost, data.itemRealCost)
        values.put(installedQty, data.installedQty)
        values.put(isInstalled, data.isInstalled)
        values.put(installedDescription, data.installedDescription)
        values.put(installedImages, data.installedImages)
        values.put(repairSuggestion, data.repairSuggestion)
        values.put(damageLevel, data.damageLevel)
        values.put(hourQty, data.hourQty)
        values.put(hourCost, data.hourCost)
        values.put(hourRealCost, data.hourRealCost)
        values.put(totalItemCost, data.totalItemCost)
        values.put(totalHourCost, data.totalHourCost)
        values.put(totalRealItemCost, data.totalRealItemCost)
        values.put(totalRealHourCost, data.totalRealHourCost)
        values.put(itemMarginDiscount, data.itemMarginDiscount)
        values.put(wheelMm, data.wheelMm)
        values.put(wheelPercentage, data.wheelPercentage)
        values.put(wheelType, data.wheelType)
        values.put(isAvailable, data.isAvailable)
        values.put(isCaricato, data.isCaricato)
        values.put(isOrdered, data.isOrdered)
        values.put(isArrived, data.isArrived)
        values.put(isLoaded, data.isLoaded)
        values.put(isTicket, data.isTicket)
        values.put(isBufferStock, data.isBufferStock)
        values.put(deliveryDate, data.deliveryDate)
        values.put(expectedDeliveryDate, data.expectedDeliveryDate)
        values.put(userId, data.userId)
        values.put(orderDate, data.orderDate)
        values.put(itemAvailable, data.itemAvailable)
        values.put(itemToOrder, data.itemToOrder)
        values.put(isRejected, data.isRejected)
        values.put(tempStatus, data.tempStatus)
        values.put(reason, data.reason)
        values.put(isGa, data.isGa)
        values.put(isFlag, data.isFlag)
        values.put(deleted, data.deleted)
        values.put(updatedAt, data.updatedAt)
        values.put(createdAt, data.createdAt)
        values.put(categoryName, data.categoryName)
        values.put(categoryImage, data.categoryImage)
        values.put(subCategoryName, data.subCategoryName)
        values.put(subCategoryImage, data.subCategoryImage)
        values.put(productImage, data.productImage)
        values.put(brandImage, data.brandImage)
        values.put(productDescription, data.productDescription)
        values.put(brandName, data.brandName)
        values.put(brandCode, data.brandCode)
        values.put(supplierLoginEnable, data.supplierLoginEnable)
        values.put(supplierName, data.supplierName)
        values.put(images, idTemp)
        values.put(eventId, idTemp)

        val result = db.insert(kmLeadItems, null, values)
        if (db.isOpen) {
            db.close()
        }
        return result != -1L
    }

    private fun getLeadItem(idTemp: Int): ArrayList<MechanicKmLeadItems> {

        val cursor: Cursor = writableDatabase.rawQuery(
            "select * from $kmLeadItems where $eventId = '$idTemp'", null
        )

        val data = ArrayList<MechanicKmLeadItems>()

        if (cursor.count != 0) {
            while (cursor.moveToNext()) {

                val temp = MechanicKmLeadItems()

                temp.id = cursor.getInt(0)
                temp.orderId = cursor.getInt(1)
                temp.supplierId = cursor.getString(2)
                temp.productId = cursor.getInt(3)
                temp.categoryId = cursor.getString(4)
                temp.subCategoryId = cursor.getString(5)
                temp.presetCategoryId = cursor.getInt(6)
                temp.stepId = cursor.getString(7)
                temp.categorySideId = cursor.getString(8)
                temp.installType = cursor.getString(9)
                temp.reportNote = cursor.getString(10)
                temp.inspectionDescription = cursor.getString(11)
                temp.mechanicNote = cursor.getString(12)
                temp.photos = cursor.getString(13)
                temp.documents = cursor.getString(14)
                temp.title = cursor.getString(15)
                temp.sku = cursor.getString(16)
                temp.qty = cursor.getFloat(17)
                temp.itemCost = cursor.getString(18)
                temp.itemRealCost = cursor.getString(19)
                temp.installedQty = cursor.getInt(20)
                temp.isInstalled = cursor.getString(21)
                temp.installedDescription = cursor.getString(22)
                temp.installedImages = cursor.getString(23)
                temp.repairSuggestion = cursor.getString(24)
                temp.damageLevel = cursor.getString(25)
                temp.hourQty = cursor.getDouble(26)
                temp.hourCost = cursor.getString(27)
                temp.hourRealCost = cursor.getString(28)
                temp.totalItemCost = cursor.getString(29)
                temp.totalHourCost = cursor.getString(30)
                temp.totalRealItemCost = cursor.getString(31)
                temp.totalRealHourCost = cursor.getString(32)
                temp.itemMarginDiscount = cursor.getString(33)
                temp.wheelMm = cursor.getString(34)
                temp.wheelPercentage = cursor.getString(35)
                temp.wheelType = cursor.getString(36)
                temp.isAvailable = cursor.getString(37)
                temp.isCaricato = cursor.getString(38)
                temp.isOrdered = cursor.getString(39)
                temp.isArrived = cursor.getString(40)
                temp.isLoaded = cursor.getString(41)
                temp.isTicket = cursor.getString(42)
                temp.isBufferStock = cursor.getString(43)
                temp.deliveryDate = cursor.getString(44)
                temp.expectedDeliveryDate = cursor.getString(45)
                temp.userId = cursor.getString(46)
                temp.orderDate = cursor.getString(47)
                temp.itemAvailable = cursor.getInt(48)
                temp.itemToOrder = cursor.getInt(49)
                temp.isRejected = cursor.getString(50)
                temp.tempStatus = cursor.getInt(51)
                temp.reason = cursor.getString(52)
                temp.isGa = cursor.getString(53)
                temp.isFlag = cursor.getString(54)
                temp.deleted = cursor.getString(55)
                temp.updatedAt = cursor.getString(56)
                temp.createdAt = cursor.getString(57)
                temp.categoryName = cursor.getString(58)
                temp.categoryImage = cursor.getString(59)
                temp.subCategoryName = cursor.getString(60)
                temp.subCategoryImage = cursor.getString(61)
                temp.productImage = cursor.getString(62)
                temp.brandImage = cursor.getString(63)
                temp.productDescription = cursor.getString(64)
                temp.brandName = cursor.getString(65)
                temp.brandCode = cursor.getString(66)
                temp.supplierLoginEnable = cursor.getString(67)
                temp.supplierName = cursor.getString(68)
                temp.images = getKmPhoto(cursor.getInt(69))

                data.add(temp)
            }
        }

        cursor.close()

        return removeDuplicates(data)
    }


    private fun addCategories(data: MechanicCategories, idTemp: Int?): Boolean {

        if (data.montata?.id != null) {
            addMontata(data.montata!!)
        }
        if (data.sMontata?.id != null) {
            addMontata(data.sMontata!!)
        }

        if (data.products != null) {
            for (temp in data.products!!) {
                addProducts(temp, data.id)
            }
        }

        if (data.photoMontata != null) {
            if (data.photoMontata!!.id != null) {
                addKmPhoto(data.photoMontata!!, data.photoMontata!!.id)
            }
        }
        if (data.photoSpessimetro != null) {
            if (data.photoSpessimetro!!.id != null) {
                addKmPhoto(data.photoSpessimetro!!, data.photoSpessimetro!!.id)
            }
        }
        if (data.photoDot != null) {
            if (data.photoDot!!.id != null) {
                addKmPhoto(data.photoDot!!, data.photoDot!!.id)
            }
        }

        val db = writableDatabase
        val values = ContentValues()

        values.put(id, data.id)
        values.put(name, data.name)
        values.put(orderBy, data.orderBy)
        values.put(parentId, data.parentId)
        values.put(testDriveId, data.testDriveId)
        values.put(image, data.image)
        values.put(autoPartiId, data.autoPartiId)
        values.put(categoryLink, data.categoryLink)
        values.put(categoryType, data.categoryType)
        values.put(option1, data.option1)
        values.put(option2, data.option2)
        values.put(option3, data.option3)
        values.put(option4, data.option4)
        values.put(option5, data.option5)
        values.put(option6, data.option6)
        values.put(option7, data.option7)
        values.put(option8, data.option8)
        values.put(option9, data.option9)
        values.put(deleted, data.deleted)
        values.put(isPhoto, data.isPhoto)
        values.put(createdAt, data.createdAt)
        values.put(updatedAt, data.updatedAt)
        values.put(montata, data.montata?.id)
        values.put(sMontata, data.sMontata?.id)
        values.put(photoMontata, data.photoMontata?.id)
        values.put(photoSpessimetro, data.photoSpessimetro?.id)
        values.put(photoDot, data.photoDot?.id)
        values.put(isSelected, data.isSelected)
        values.put(isDottedFileUpload, data.isDottedFileUpload)
        values.put(isDottedFileUpload2, data.isDottedFileUpload2)
        values.put(products, data.id)
        values.put(eventId, idTemp)

        val result = db.insert(kmCategories, null, values)
        if (db.isOpen) {
            db.close()
        }
        return result != -1L
    }

    private fun addProducts(data: MechanicProducts, idTemp: Int?): Boolean {

        data.orderDetails?.let { data.id?.let { it1 -> addOrderDetails(it, it1) } }
        val db = writableDatabase
        val values = ContentValues()

        values.put(id, data.id)
        values.put(image, data.image)
        values.put(brandImage, data.brandImage)
        values.put(brandName, data.brandName)
        values.put(brandCode, data.brandCode)
        values.put(productLink, data.productLink)
        values.put(sku, data.sku)
        values.put(barcode, data.barcode)
        values.put(title, data.title)
        values.put(description, data.description)
        values.put(oldPrice, data.oldPrice)
        values.put(newPrice, data.newPrice)
        values.put(isFavourite, data.isFavourite)
        values.put(deleted, data.deleted)
        values.put(createdAt, data.createdAt)
        values.put(updatedAt, data.updatedAt)
        values.put(orderDetails, data.id)
        values.put(eventId, idTemp)


        val result = db.insert(kmProducts, null, values)
        if (db.isOpen) {
            db.close()
        }
        return result != -1L
    }


    private fun getCategories(idTemp: Int): ArrayList<MechanicCategories> {

        val cursor: Cursor = writableDatabase.rawQuery(
            "select * from $kmCategories where $eventId = '$idTemp'", null
        )

        val data = ArrayList<MechanicCategories>()

        if (cursor.count != 0) {
            while (cursor.moveToNext()) {

                val temp = MechanicCategories()

                temp.id = cursor.getInt(0)
                temp.name = cursor.getString(1)
                temp.orderBy = cursor.getString(2)
                temp.parentId = cursor.getInt(3)
                temp.testDriveId = cursor.getString(4)
                temp.image = cursor.getString(5)
                temp.autoPartiId = cursor.getString(6)
                temp.categoryLink = cursor.getString(7)
                temp.categoryType = cursor.getString(8)
                temp.option1 = cursor.getString(9)
                temp.option2 = cursor.getString(10)
                temp.option3 = cursor.getString(11)
                temp.option4 = cursor.getString(12)
                temp.option5 = cursor.getString(13)
                temp.option6 = cursor.getString(14)
                temp.option7 = cursor.getString(15)
                temp.option8 = cursor.getString(16)
                temp.option9 = cursor.getString(17)
                temp.deleted = cursor.getString(18)
                temp.isPhoto = cursor.getString(19)
                temp.createdAt = cursor.getString(20)
                temp.updatedAt = cursor.getString(21)
                temp.montata = getMontata(cursor.getInt(22))
                temp.sMontata = getMontata(cursor.getInt(23))
                temp.photoMontata = getKmPhotoSingle(cursor.getInt(24))
                temp.photoSpessimetro = getKmPhotoSingle(cursor.getInt(25))
                temp.photoDot = getKmPhotoSingle(cursor.getInt(26))
                temp.isSelected = cursor.getString(27).toBoolean()
                temp.isDottedFileUpload = cursor.getString(28).toBoolean()
                temp.isDottedFileUpload2 = cursor.getString(29).toBoolean()
                temp.products = getProducts(cursor.getInt(30).toString())
                temp.eventId = cursor.getInt(31)

                data.add(temp)
            }
        }

        cursor.close()

        return removeDuplicates(data)
    }


    private fun getProducts(idTemp: String): ArrayList<MechanicProducts> {

        val cursor: Cursor = writableDatabase.rawQuery(
            "select * from $kmProducts where $eventId = '$idTemp'", null
        )

        val data = ArrayList<MechanicProducts>()

        if (cursor.count != 0) {
            while (cursor.moveToNext()) {

                val temp = MechanicProducts()

                temp.id = cursor.getInt(0)
                temp.image = cursor.getString(1)
                temp.brandImage = cursor.getString(2)
                temp.brandName = cursor.getString(3)
                temp.brandCode = cursor.getString(4)
                temp.productLink = cursor.getString(5)
                temp.sku = cursor.getString(6)
                temp.barcode = cursor.getString(7)
                temp.title = cursor.getString(8)
                temp.description = cursor.getString(9)
                temp.oldPrice = cursor.getString(10)
                temp.newPrice = cursor.getString(11)
                temp.isFavourite = cursor.getString(12)
                temp.deleted = cursor.getString(13)
                temp.createdAt = cursor.getString(14)
                temp.updatedAt = cursor.getString(15)
                temp.orderDetails = getOrderDetails(cursor.getInt(16))
                temp.eventId = cursor.getInt(17)

                data.add(temp)
            }
        }

        cursor.close()

        return removeDuplicates(data)
    }

    private fun getOrderDetails(idTemp: Int): MechanicOrderDetails {

        val cursor: Cursor = writableDatabase.rawQuery(
            "select * from $kmOrderDetails where $eventId = '$idTemp'", null
        )

        val temp = MechanicOrderDetails()

        if (cursor.count != 0) {
            while (cursor.moveToNext()) {

                temp.id = cursor.getInt(0)
                temp.orderId = cursor.getInt(1)
                temp.supplierId = cursor.getString(2)
                temp.productId = cursor.getInt(3)
                temp.categoryId = cursor.getInt(4)
                temp.subCategoryId = cursor.getInt(5)
                temp.presetCategoryId = cursor.getInt(6)
                temp.stepId = cursor.getInt(7)
                temp.categorySideId = cursor.getString(8)
                temp.installType = cursor.getString(9)
                temp.reportNote = cursor.getString(10)
                temp.inspectionDescription = cursor.getString(11)
                temp.mechanicNote = cursor.getString(12)
                temp.photos = cursor.getString(13)
                temp.documents = cursor.getString(14)
                temp.title = cursor.getString(15)
                temp.sku = cursor.getString(16)
                temp.qty = cursor.getInt(17)
                temp.itemCost = cursor.getString(18)
                temp.itemRealCost = cursor.getString(19)
                temp.installedQty = cursor.getInt(20)
                temp.isInstalled = cursor.getString(21)
                temp.installedDescription = cursor.getString(22)
                temp.installedImages = cursor.getString(23)
                temp.repairSuggestion = cursor.getString(24)
                temp.damageLevel = cursor.getString(25)
                temp.hourQty = cursor.getString(26)
                temp.hourCost = cursor.getString(27)
                temp.hourRealCost = cursor.getString(28)
                temp.totalItemCost = cursor.getString(29)
                temp.totalHourCost = cursor.getString(30)
                temp.totalRealItemCost = cursor.getString(31)
                temp.totalRealHourCost = cursor.getString(32)
                temp.itemMarginDiscount = cursor.getString(33)
                temp.wheelMm = cursor.getString(34)
                temp.wheelPercentage = cursor.getString(35)
                temp.wheelType = cursor.getString(36)
                temp.isAvailable = cursor.getString(37)
                temp.isCaricato = cursor.getString(38)
                temp.isOrdered = cursor.getString(39)
                temp.isArrived = cursor.getString(40)
                temp.isLoaded = cursor.getString(41)
                temp.isTicket = cursor.getString(42)
                temp.isBufferStock = cursor.getString(43)
                temp.deliveryDate = cursor.getString(44)
                temp.expectedDeliveryDate = cursor.getString(45)
                temp.userId = cursor.getString(46)
                temp.orderDate = cursor.getString(47)
                temp.itemAvailable = cursor.getInt(48)
                temp.itemToOrder = cursor.getInt(49)
                temp.isRejected = cursor.getString(50)
                temp.tempStatus = cursor.getInt(51)
                temp.reason = cursor.getString(52)
                temp.isGa = cursor.getString(53)
                temp.isFlag = cursor.getString(54)
                temp.isRecover = cursor.getString(55)
                temp.recoverNumberPlate = cursor.getString(56)
                temp.invoiceReason = cursor.getString(57)
                temp.invoiceCreatedBy = cursor.getString(58)
                temp.invoiceDescription = cursor.getString(59)
                temp.returnPrice = cursor.getString(60)
                temp.returnWorkHourCost = cursor.getString(61)
                temp.returnItemCost = cursor.getString(62)
                temp.invoiceWorkHourCost = cursor.getString(63)
                temp.invoiceItemCost = cursor.getString(64)
                temp.invoicePrice = cursor.getString(65)
                temp.isInvoiced = cursor.getString(66)
                temp.isProposed = cursor.getString(67)
                temp.proposedBy = cursor.getString(68)
                temp.proposedDescription = cursor.getString(69)
                temp.proposedAt = cursor.getString(70)
                temp.isConformProposed = cursor.getString(71)
                temp.conformProposedBy = cursor.getString(72)
                temp.conformProposedDescription = cursor.getString(73)
                temp.conformProposedAt = cursor.getString(74)
                temp.recoverDate = cursor.getString(75)
                temp.mobileStationId = cursor.getString(76)
                temp.deleted = cursor.getString(77)
                temp.updatedAt = cursor.getString(78)
                temp.createdAt = cursor.getString(79)
                temp.categoryName = cursor.getString(80)
                temp.categoryImage = cursor.getString(81)
                temp.subCategoryName = cursor.getString(82)
                temp.subCategoryImage = cursor.getString(83)
                temp.productImage = cursor.getString(84)
                temp.brandImage = cursor.getString(85)
                temp.productDescription = cursor.getString(86)
                temp.brandName = cursor.getString(87)
                temp.brandCode = cursor.getString(88)
                temp.supplierLoginEnable = cursor.getString(89)
                temp.supplierName = cursor.getString(90)
                temp.invoiceCreatedByName = cursor.getString(91)
                temp.proposalCreatedByName = cursor.getString(92)
                temp.eventId = cursor.getInt(93)

            }
        }

        cursor.close()

        return temp
    }

    private fun addOrderDetails(data: MechanicOrderDetails, idTemp: Int): Boolean {
        val db = writableDatabase
        val values = ContentValues()

        values.put(id, data.id)
        values.put(orderId, data.orderId)
        values.put(supplierId, data.supplierId)
        values.put(productId, data.productId)
        values.put(categoryId, data.categoryId)
        values.put(subCategoryId, data.subCategoryId)
        values.put(presetCategoryId, data.presetCategoryId)
        values.put(stepId, data.stepId)
        values.put(categorySideId, data.categorySideId)
        values.put(installType, data.installType)
        values.put(reportNote, data.reportNote)
        values.put(inspectionDescription, data.inspectionDescription)
        values.put(mechanicNote, data.mechanicNote)
        values.put(photos, data.photos)
        values.put(documents, data.documents)
        values.put(title, data.title)
        values.put(sku, data.sku)
        values.put(qty, data.qty)
        values.put(itemCost, data.itemCost)
        values.put(itemRealCost, data.itemRealCost)
        values.put(installedQty, data.installedQty)
        values.put(isInstalled, data.isInstalled)
        values.put(installedDescription, data.installedDescription)
        values.put(installedImages, data.installedImages)
        values.put(repairSuggestion, data.repairSuggestion)
        values.put(damageLevel, data.damageLevel)
        values.put(hourQty, data.hourQty)
        values.put(hourCost, data.hourCost)
        values.put(hourRealCost, data.hourRealCost)
        values.put(totalItemCost, data.totalItemCost)
        values.put(totalHourCost, data.totalHourCost)
        values.put(totalRealItemCost, data.totalRealItemCost)
        values.put(totalRealHourCost, data.totalRealHourCost)
        values.put(itemMarginDiscount, data.itemMarginDiscount)
        values.put(wheelMm, data.wheelMm)
        values.put(wheelPercentage, data.wheelPercentage)
        values.put(wheelType, data.wheelType)
        values.put(isAvailable, data.isAvailable)
        values.put(isCaricato, data.isCaricato)
        values.put(isOrdered, data.isOrdered)
        values.put(isArrived, data.isArrived)
        values.put(isLoaded, data.isLoaded)
        values.put(isTicket, data.isTicket)
        values.put(isBufferStock, data.isBufferStock)
        values.put(deliveryDate, data.deliveryDate)
        values.put(expectedDeliveryDate, data.expectedDeliveryDate)
        values.put(userId, data.userId)
        values.put(orderDate, data.orderDate)
        values.put(itemAvailable, data.itemAvailable)
        values.put(itemToOrder, data.itemToOrder)
        values.put(isRejected, data.isRejected)
        values.put(tempStatus, data.tempStatus)
        values.put(reason, data.reason)
        values.put(isGa, data.isGa)
        values.put(isFlag, data.isFlag)
        values.put(isRecover, data.isRecover)
        values.put(recoverNumberPlate, data.recoverNumberPlate)
        values.put(invoiceReason, data.invoiceReason)
        values.put(invoiceCreatedBy, data.invoiceCreatedBy)
        values.put(invoiceDescription, data.categoryImage)
        values.put(returnPrice, data.returnPrice)
        values.put(returnWorkHourCost, data.returnWorkHourCost)
        values.put(returnItemCost, data.returnItemCost)
        values.put(invoiceWorkHourCost, data.invoiceWorkHourCost)
        values.put(invoiceItemCost, data.invoiceItemCost)
        values.put(invoicePrice, data.invoicePrice)
        values.put(isInvoiced, data.isInvoiced)
        values.put(isProposed, data.isProposed)
        values.put(proposedBy, data.proposedBy)
        values.put(proposedDescription, data.proposedDescription)
        values.put(proposedAt, data.proposedAt)
        values.put(isConformProposed, data.isConformProposed)
        values.put(conformProposedBy, data.conformProposedBy)
        values.put(conformProposedDescription, data.conformProposedDescription)
        values.put(conformProposedAt, data.conformProposedAt)
        values.put(recoverDate, data.recoverDate)
        values.put(mobileStationId, data.mobileStationId)
        values.put(deleted, data.deleted)
        values.put(updatedAt, data.updatedAt)
        values.put(createdAt, data.createdAt)
        values.put(categoryName, data.categoryName)
        values.put(categoryImage, data.categoryImage)
        values.put(subCategoryName, data.subCategoryName)
        values.put(subCategoryImage, data.subCategoryImage)
        values.put(productImage, data.productImage)
        values.put(brandImage, data.brandImage)
        values.put(productDescription, data.productDescription)
        values.put(brandName, data.brandName)
        values.put(brandCode, data.brandCode)
        values.put(supplierLoginEnable, data.supplierLoginEnable)
        values.put(supplierName, data.supplierName)
        values.put(invoiceCreatedByName, invoiceCreatedByName)
        values.put(proposalCreatedByName, proposalCreatedByName)
        values.put(eventId, idTemp)

        val result = db.insert(kmOrderDetails, null, values)
        if (db.isOpen) {
            db.close()
        }
        return result != -1L
    }


    private fun addEvent(data: MechanicEvent): Boolean {

        val db = writableDatabase
        val values = ContentValues()

        values.put(id, data.id)
        values.put(leadId, data.leadId)
        values.put(title, data.title)
        values.put(description, data.description)
        values.put(contactId, data.contactId)
        values.put(createdBy, data.createdBy)
        values.put(parentEventId, data.parentEventId)
        values.put(calendarWorkPlanId, data.calendarWorkPlanId)
        values.put(customerWorkPlanId, data.customerWorkPlanId)
        values.put(objectType, data.objectType)
        values.put(actionDate, data.actionDate)
        values.put(mobileStationId, data.mobileStationId)
        values.put(fileName, data.fileName)
        values.put(fileLocation, data.fileLocation)
        values.put(completed, data.completed)
        values.put(assignTo, data.assignTo)
        values.put(startDate, data.startDate)
        values.put(endDate, data.endDate)
        values.put(workWithUserId, data.workWithUserId)
        values.put(appointmentRepeatCount, data.appointmentRepeatCount)
        values.put(appointmentRepeatOption, data.appointmentRepeatOption)
        values.put(remindCron, data.remindCron)
        values.put(repeatAppointmentMainId, data.repeatAppointmentMainId)
        values.put(isVisible, data.isVisible)
        values.put(parentId, data.parentId)
        values.put(isAllday, data.isAllday)
        values.put(eventNotification, data.eventNotification)
        values.put(notificationDuration, data.notificationDuration)
        values.put(notificationOption, data.notificationOption)
        values.put(mainEventId, data.mainEventId)
        values.put(workWithIds, data.workWithIds)
        values.put(isConfirm, data.isConfirm)
        values.put(inviteEmail, data.inviteEmail)
        values.put(callAppointment, data.callAppointment)
        values.put(appointmentRequestFrom, data.appointmentRequestFrom)
        values.put(isPending, data.isPending)
        values.put(deleted, data.deleted)
        values.put(confirmedAt, data.confirmedAt)
        values.put(isClosed, data.isClosed)
        values.put(isWorkNotDone, data.isWorkNotDone)
        values.put(closedAt, data.closedAt)
        values.put(travelStart, data.travelStart)
        values.put(travelEnd, data.travelEnd)
        values.put(travelTime, data.travelTime)
        values.put(totalKm, data.totalKm)
        values.put(isEventStart, data.isEventStart)
        values.put(isTravelCompleted, data.isTravelCompleted)
        values.put(towRequestAccepted, data.towRequestAccepted)
        values.put(isPicked, data.isPicked)
        values.put(isManualReport, data.isManualReport)
        values.put(isPauseTravel, data.isPauseTravel)
        values.put(workStartTime, data.workStartTime)
        values.put(workEndTime, data.workEndTime)
        values.put(mechanicWorkStartTime, data.mechanicWorkStartTime)
        values.put(mechanicWorkEndTime, data.mechanicWorkEndTime)
        values.put(mechanicTravelStartTime, data.mechanicTravelStartTime)
        values.put(mechanicTravelEndTime, data.mechanicTravelEndTime)
        values.put(mechanicTravelBreakStart, data.mechanicTravelBreakStart)
        values.put(mechanicTravelBreakEnd, data.mechanicTravelBreakEnd)
        values.put(mechanicTravelRestart, data.mechanicTravelRestart)
        values.put(mobileStationLat, data.mobileStationLat)
        values.put(mobileStationLon, data.mobileStationLon)
        values.put(sourceAddress, data.sourceAddress)
        values.put(destinationAddress, data.destinationAddress)
        values.put(dropAddress, data.dropAddress)
        values.put(currentStep, data.currentStep)
        values.put(closeReason, data.closeReason)
        values.put(previousEventId, data.previousEventId)
        values.put(isDayClose, data.isDayClose)
        values.put(isReportConfirm, data.isReportConfirm)
        values.put(isEventReopen, data.isEventReopen)
        values.put(isReminderSent, data.isReminderSent)
        values.put(carId, data.carId)
        values.put(reportConfirmAt, data.reportConfirmAt)
        values.put(reportConfirmBy, data.reportConfirmBy)
        values.put(createdAt, data.createdAt)
        values.put(updatedAt, data.updatedAt)
        values.put(deletedAt, data.deletedAt)
        values.put(userName, data.userName)
        values.put(calendarColor, data.calendarColor)
        values.put(businessName, data.businessName)
        values.put(firstName, data.firstName)
        values.put(lastName, data.lastName)
        values.put(email, data.email)
        values.put(mobile, data.mobile)
        values.put(displayId, data.displayId)
        values.put(numberPlate, data.numberPlate)
        values.put(statusId, data.statusId)
        values.put(priority, data.priority)
        values.put(leadTypeId, data.leadTypeId)
        values.put(orderId, data.orderId)
        values.put(lat, data.lat)
        values.put(lon, data.lon)
        values.put(address, data.address)
        values.put(dropLon, data.dropLon)
        values.put(enterKm, data.enterKm)
        values.put(calendarWorkDisplayId, data.calendarWorkDisplayId)
        values.put(note, data.note)
        values.put(isNoteRead, data.isNoteRead)
        values.put(sedeName, data.sedeName)
        values.put(officeCalendarColor, data.officeCalendarColor)
        values.put(makeName, data.makeName)
        values.put(modelName, data.modelName)

        val result = db.insert(event, null, values)
        if (db.isOpen) {
            db.close()
        }
        return result != -1L

    }

    private fun getEvent(idTemp: Int): MechanicEvent {

        val cursor: Cursor = writableDatabase.rawQuery(
            "select * from $event where $id = '$idTemp'", null
        )

        val temp = MechanicEvent()

        if (cursor.count != 0) {
            while (cursor.moveToNext()) {

                temp.id = cursor.getInt(0)
                temp.leadId = cursor.getInt(1)
                temp.title = cursor.getString(2)
                temp.description = cursor.getString(3)
                temp.contactId = cursor.getInt(4)
                temp.createdBy = cursor.getInt(5)
                temp.parentEventId = cursor.getInt(6)
                temp.calendarWorkPlanId = cursor.getInt(7)
                temp.customerWorkPlanId = cursor.getInt(8)
                temp.objectType = cursor.getString(9)
                temp.actionDate = cursor.getString(10)
                temp.mobileStationId = cursor.getInt(11)
                temp.fileName = cursor.getString(12)
                temp.fileLocation = cursor.getString(13)
                temp.completed = cursor.getString(14)
                temp.assignTo = cursor.getInt(15)
                temp.startDate = cursor.getString(16)
                temp.endDate = cursor.getString(17)
                temp.workWithUserId = cursor.getString(18)
                temp.appointmentRepeatCount = cursor.getString(19)
                temp.appointmentRepeatOption = cursor.getString(20)
                temp.remindCron = cursor.getString(21)
                temp.repeatAppointmentMainId = cursor.getString(22)
                temp.isVisible = cursor.getInt(23)
                temp.parentId = cursor.getInt(24)
                temp.isAllday = cursor.getInt(25)
                temp.eventNotification = cursor.getString(26)
                temp.notificationDuration = cursor.getString(27)
                temp.notificationOption = cursor.getString(28)
                temp.mainEventId = cursor.getString(29)
                temp.workWithIds = cursor.getString(30)
                temp.isConfirm = cursor.getString(31)
                temp.inviteEmail = cursor.getString(32)
                temp.callAppointment = cursor.getString(33)
                temp.appointmentRequestFrom = cursor.getString(34)
                temp.isPending = cursor.getString(35)
                temp.deleted = cursor.getString(36)
                temp.confirmedAt = cursor.getString(37)
                temp.isClosed = cursor.getString(38)
                temp.isWorkNotDone = cursor.getString(39)
                temp.closedAt = cursor.getString(40)
                temp.travelStart = cursor.getString(41)
                temp.travelEnd = cursor.getString(42)
                temp.travelTime = cursor.getDouble(43)
                temp.totalKm = cursor.getFloat(44)
                temp.isEventStart = cursor.getString(45)
                temp.isTravelCompleted = cursor.getString(46)
                temp.towRequestAccepted = cursor.getString(47)
                temp.isPicked = cursor.getString(48)
                temp.isManualReport = cursor.getString(49)
                temp.isPauseTravel = cursor.getString(50)
                temp.workStartTime = cursor.getString(51)
                temp.workEndTime = cursor.getString(52)
                temp.mechanicWorkStartTime = cursor.getString(53)
                temp.mechanicWorkEndTime = cursor.getString(54)
                temp.mechanicTravelStartTime = cursor.getString(55)
                temp.mechanicTravelEndTime = cursor.getString(56)
                temp.mechanicTravelBreakStart = cursor.getString(57)
                temp.mechanicTravelBreakEnd = cursor.getString(58)
                temp.mechanicTravelRestart = cursor.getString(59)
                temp.mobileStationLat = cursor.getDouble(60)
                temp.mobileStationLon = cursor.getDouble(61)
                temp.sourceAddress = cursor.getString(62)
                temp.destinationAddress = cursor.getString(63)
                temp.dropAddress = cursor.getString(64)
                temp.currentStep = cursor.getString(65)
                temp.closeReason = cursor.getString(66)
                temp.previousEventId = cursor.getString(67)
                temp.isDayClose = cursor.getString(68)
                temp.isReportConfirm = cursor.getString(69)
                temp.isEventReopen = cursor.getString(70)
                temp.isReminderSent = cursor.getString(71)
                temp.carId = cursor.getInt(72)
                temp.reportConfirmAt = cursor.getString(73)
                temp.reportConfirmBy = cursor.getString(74)
                temp.createdAt = cursor.getString(75)
                temp.updatedAt = cursor.getString(76)
                temp.deletedAt = cursor.getString(77)
                temp.userName = cursor.getString(78)
                temp.calendarColor = cursor.getString(79)
                temp.businessName = cursor.getString(80)
                temp.firstName = cursor.getString(81)
                temp.lastName = cursor.getString(82)
                temp.email = cursor.getString(83)
                temp.mobile = cursor.getString(84)
                temp.displayId = cursor.getString(85)
                temp.numberPlate = cursor.getString(86)
                temp.statusId = cursor.getInt(87)
                temp.priority = cursor.getInt(88)
                temp.leadTypeId = cursor.getInt(89)
                temp.orderId = cursor.getInt(90)
                temp.lat = cursor.getDouble(91)
                temp.lon = cursor.getDouble(92)
                temp.address = cursor.getString(93)
                temp.dropLon = cursor.getString(94)
                temp.enterKm = cursor.getInt(95)
                temp.calendarWorkDisplayId = cursor.getString(96)
                temp.note = cursor.getString(97)
                temp.isNoteRead = cursor.getString(98)
                temp.sedeName = cursor.getString(99)
                temp.officeCalendarColor = cursor.getString(100)
                temp.makeName = cursor.getString(101)
                temp.modelName = cursor.getString(102)
            }
        }

        cursor.close()

        return temp
    }


    private fun addMontata(data: MechanicMontata): Boolean {

        val db = writableDatabase
        val values = ContentValues()

        values.put(id, data.id)
        values.put(orderId, data.orderId)
        values.put(supplierId, data.supplierId)
        values.put(productId, data.productId)
        values.put(categoryId, data.categoryId)
        values.put(subCategoryId, data.subCategoryId)
        values.put(presetCategoryId, data.presetCategoryId)
        values.put(stepId, data.stepId)
        values.put(categorySideId, data.categorySideId)
        values.put(installType, data.installType)
        values.put(reportNote, data.reportNote)
        values.put(inspectionDescription, data.inspectionDescription)
        values.put(mechanicNote, data.mechanicNote)
        values.put(photos, data.photos)
        values.put(documents, data.documents)
        values.put(title, data.title)
        values.put(sku, data.sku)
        values.put(qty, data.qty)
        values.put(itemCost, data.itemCost)
        values.put(itemRealCost, data.itemRealCost)
        values.put(installedQty, data.installedQty)
        values.put(isInstalled, data.isInstalled)
        values.put(installedDescription, data.installedDescription)
        values.put(installedImages, data.installedImages)
        values.put(repairSuggestion, data.repairSuggestion)
        values.put(damageLevel, data.damageLevel)
        values.put(hourQty, data.hourQty)
        values.put(hourCost, data.hourCost)
        values.put(hourRealCost, data.hourRealCost)
        values.put(totalItemCost, data.totalItemCost)
        values.put(totalHourCost, data.totalHourCost)
        values.put(totalRealItemCost, data.totalRealItemCost)
        values.put(totalRealHourCost, data.totalRealHourCost)
        values.put(itemMarginDiscount, data.itemMarginDiscount)
        values.put(wheelMm, data.wheelMm)
        values.put(wheelPercentage, data.wheelPercentage)
        values.put(wheelType, data.wheelType)
        values.put(isAvailable, data.isAvailable)
        values.put(isCaricato, data.isCaricato)
        values.put(isOrdered, data.isOrdered)
        values.put(isArrived, data.isArrived)
        values.put(isLoaded, data.isLoaded)
        values.put(isTicket, data.isTicket)
        values.put(isBufferStock, data.isBufferStock)
        values.put(deliveryDate, data.deliveryDate)
        values.put(expectedDeliveryDate, data.expectedDeliveryDate)
        values.put(userId, data.userId)
        values.put(orderDate, data.orderDate)
        values.put(itemAvailable, data.itemAvailable)
        values.put(itemToOrder, data.itemToOrder)
        values.put(isRejected, data.isRejected)
        values.put(tempStatus, data.tempStatus)
        values.put(reason, data.reason)
        values.put(isGa, data.isGa)
        values.put(deleted, data.deleted)
        values.put(updatedAt, data.updatedAt)
        values.put(createdAt, data.createdAt)

        val result = db.insert(montataData, null, values)
        if (db.isOpen) {
            db.close()
        }
        return result != -1L

    }

    private fun getMontata(idTemp: Int): MechanicMontata {

        val cursor: Cursor = writableDatabase.rawQuery(
            "select * from $montataData where $id = '$idTemp'", null
        )

        val temp = MechanicMontata()

        if (cursor.count != 0) {
            while (cursor.moveToNext()) {

                temp.id = cursor.getInt(0)
                temp.orderId = cursor.getInt(1)
                temp.supplierId = cursor.getString(2)
                temp.productId = cursor.getInt(3)
                temp.categoryId = cursor.getInt(4)
                temp.subCategoryId = cursor.getInt(5)
                temp.presetCategoryId = cursor.getInt(6)
                temp.stepId = cursor.getString(7)
                temp.categorySideId = cursor.getString(8)
                temp.installType = cursor.getString(9)
                temp.reportNote = cursor.getString(10)
                temp.inspectionDescription = cursor.getString(11)
                temp.mechanicNote = cursor.getString(12)
                temp.photos = cursor.getString(13)
                temp.documents = cursor.getString(14)
                temp.title = cursor.getString(15)
                temp.sku = cursor.getString(16)
                temp.qty = cursor.getInt(17)
                temp.itemCost = cursor.getString(18)
                temp.itemRealCost = cursor.getString(19)
                temp.installedQty = cursor.getInt(20)
                temp.isInstalled = cursor.getString(21)
                temp.installedDescription = cursor.getString(22)
                temp.installedImages = cursor.getString(23)
                temp.repairSuggestion = cursor.getString(24)
                temp.damageLevel = cursor.getString(25)
                temp.hourQty = cursor.getDouble(26)
                temp.hourCost = cursor.getString(27)
                temp.hourRealCost = cursor.getString(28)
                temp.totalItemCost = cursor.getString(29)
                temp.totalHourCost = cursor.getString(30)
                temp.totalRealItemCost = cursor.getString(31)
                temp.totalRealHourCost = cursor.getString(32)
                temp.itemMarginDiscount = cursor.getString(33)
                temp.wheelMm = cursor.getString(34)
                temp.wheelPercentage = cursor.getString(35)
                temp.wheelType = cursor.getString(36)
                temp.isAvailable = cursor.getString(37)
                temp.isCaricato = cursor.getString(38)
                temp.isOrdered = cursor.getString(39)
                temp.isArrived = cursor.getString(40)
                temp.isLoaded = cursor.getString(41)
                temp.isTicket = cursor.getString(42)
                temp.isBufferStock = cursor.getString(43)
                temp.deliveryDate = cursor.getString(44)
                temp.expectedDeliveryDate = cursor.getString(45)
                temp.userId = cursor.getString(46)
                temp.orderDate = cursor.getString(47)
                temp.itemAvailable = cursor.getInt(48)
                temp.itemToOrder = cursor.getInt(49)
                temp.isRejected = cursor.getString(50)
                temp.tempStatus = cursor.getInt(51)
                temp.reason = cursor.getString(52)
                temp.isGa = cursor.getString(53)
                temp.deleted = cursor.getString(54)
                temp.updatedAt = cursor.getString(55)
                temp.createdAt = cursor.getString(56)

            }
        }

        cursor.close()

        return temp
    }


    private fun addKmDetail(data: MechanicKmDetail, idTemp: Int?): Boolean {

        addKmLead(data.lead!!, idTemp)
        if (data.lastRequest != null) {
            addLastRequest(data.lastRequest!!, idTemp)
        }
        addKmPreviousRequestEvent(data.previousRequestEvent!!, idTemp)
        addKmPreviousRequestMobileStation(data.previousRequestMobileStation!!, idTemp)

        val db = writableDatabase
        val values = ContentValues()

        values.put(lead, idTemp)
        values.put(lastRequest, idTemp)
        values.put(previousRequestEvent, idTemp)
        values.put(previousRequestMobileStation, idTemp)
        values.put(id, idTemp)

        val result = db.insert(kmDetailData, null, values)
        if (db.isOpen) {
            db.close()
        }
        return result != -1L
    }

    private fun getKmDetail(idTemp: Int): MechanicKmDetail {

        val cursor: Cursor = writableDatabase.rawQuery(
            "select * from $kmDetailData where $id = '$idTemp'", null
        )

        val temp = MechanicKmDetail()

        if (cursor.count != 0) {
            while (cursor.moveToNext()) {

                temp.lead = getLead(cursor.getInt(0))
                temp.lastRequest = getLastRequest(cursor.getInt(1))
                temp.previousRequestEvent = getPreviousRequestEvent(cursor.getInt(2))
                temp.previousRequestMobileStation =
                    getPreviousRequestMobileStation(cursor.getInt(3))

            }
        }

        cursor.close()

        return temp
    }


    fun addKmLead(data: MechanicKmLead, idTemp: Int?): Boolean {

        for (temp in data.kmPhotos!!) {
            if (temp?.id != null) {
                addKmPhoto(temp, idTemp)
            }
        }

        val db = writableDatabase
        val values = ContentValues()

        values.put(id, data.id)
        values.put(displayId, data.displayId)
        values.put(numberPlate, data.numberPlate)
        values.put(contactId, data.contactId)
        values.put(createdBy, data.createdBy)
        values.put(parentLeadId, data.parentLeadId)
        values.put(customerDisplayId, data.customerDisplayId)
        values.put(customerDocumentId, data.customerDocumentId)
        values.put(lastUpdatedBy, data.lastUpdatedBy)
        values.put(leadTitle, data.leadTitle)
        values.put(description, data.description)
        values.put(pipelineId, data.pipelineId)
        values.put(phaseId, data.phaseId)
        values.put(ownerId, data.ownerId)
        values.put(leadValue, data.leadValue)
        values.put(isArchived, data.isArchived)
        values.put(priority, data.priority)
        values.put(parentId, data.parentId)
        values.put(billingAddressId, data.billingAddressId)
        values.put(shippingAddressId, data.shippingAddressId)
        values.put(leadTypeId, data.leadTypeId)
        values.put(carId, data.carId)
        values.put(officeLocationId, data.officeLocationId)
        values.put(statusId, data.statusId)
        values.put(orderStatusId, data.orderStatusId)
        values.put(trafficSource, data.trafficSource)
        values.put(requestUrl, data.requestUrl)
        values.put(mechanicId, data.mechanicId)
        values.put(renewCounter, data.renewCounter)
        values.put(accessToken, data.accessToken)
        values.put(updatedBy, data.updatedBy)
        values.put(locationType, data.locationType)
        values.put(lat, data.lat)
        values.put(lon, data.lon)
        values.put(address, data.address)
        values.put(dropLat, data.dropLat)
        values.put(dropLon, data.dropLon)
        values.put(dropAddress, data.dropAddress)
        values.put(warehouseInstruction, data.warehouseInstruction)
        values.put(stockNote, data.stockNote)
        values.put(itemNote, data.itemNote)
        values.put(isProblemIdentify, data.isProblemIdentify)
        values.put(isWarningLight, data.isWarningLight)
        values.put(warningLights, data.warningLights)
        values.put(testCentral, data.testCentral)
        values.put(orderId, data.orderId)
        values.put(isCreatedByMechanic, data.isCreatedByMechanic)
        values.put(configuredBy, data.configuredBy)
        values.put(isInspection, data.isInspection)
        values.put(isNew, data.isNew)
        values.put(isRead, data.isRead)
        values.put(isManual, data.isManual)
        values.put(isUrgent, data.isUrgent)
        values.put(isFutureRequest, data.isFutureRequest)
        values.put(sosIcon, data.sosIcon)
        values.put(customerWorkPlanId, data.customerWorkPlanId)
        values.put(reportType, data.reportType)
        values.put(isReportConfirm, data.isReportConfirm)
        values.put(reportDescription, data.reportDescription)
        values.put(sosRequestId, data.sosRequestId)
        values.put(enterKm, data.enterKm)
        values.put(isDayClose, data.isDayClose)
        values.put(closeReason, data.closeReason)
        values.put(configuredByLocationId, data.configuredByLocationId)
        values.put(isWheelChange, data.isWheelChange)
        values.put(isAuthorization, data.isAuthorization)
        values.put(authorizationCode, data.authorizationCode)
        values.put(driverCode, data.driverCode)
        values.put(isGa, data.isGa)
        values.put(offerPdf, data.offerPdf)
        values.put(offerCreatedBy, data.offerCreatedBy)
        values.put(createdFrom, data.createdFrom)
        values.put(emojiSelection, data.emojiSelection)
        values.put(deleted, data.deleted)
        values.put(createdAt, data.createdAt)
        values.put(updatedAt, data.updatedAt)
        values.put(firstName, data.firstName)
        values.put(lastName, data.lastName)
        values.put(businessName, data.businessName)
        values.put(fullName, data.fullName)
        values.put(email, data.email)
        values.put(mobile, data.mobile)
        values.put(ownerName, data.ownerName)
        values.put(ownerEmail, data.ownerEmail)
        values.put(ownerMobile, data.ownerMobile)
        values.put(createdByName, data.createdByName)
        values.put(configuredByName, data.configuredByName)
        values.put(pipelineName, data.pipelineName)
        values.put(phaseName, data.phaseName)
        values.put(locationName, data.locationName)
        values.put(locationAddress, data.locationAddress)
        values.put(makeName, data.makeName)
        values.put(modelName, data.modelName)
        values.put(statusName, data.statusName)
        values.put(vin, data.vin)
        values.put(locationId, data.locationId)
        values.put(sedeName, data.sedeName)
        values.put(appointmentCount, data.appointmentCount)
        values.put(kmPhotos, idTemp)
        values.put(eventId, idTemp)

        val result = db.insert(kmLeadData, null, values)
        if (db.isOpen) {
            db.close()
        }
        return result != -1L

    }

    fun getLead(idTemp: Int): MechanicKmLead {

        val cursor: Cursor = writableDatabase.rawQuery(
            "select * from $kmLeadData where $eventId = '$idTemp'", null
        )

        val temp = MechanicKmLead()

        if (cursor.count != 0) {
            while (cursor.moveToNext()) {

                temp.id = cursor.getInt(0)
                temp.displayId = cursor.getString(1)
                temp.numberPlate = cursor.getString(2)
                temp.contactId = cursor.getInt(3)
                temp.createdBy = cursor.getInt(4)
                temp.parentLeadId = cursor.getString(5)
                temp.customerDisplayId = cursor.getString(6)
                temp.customerDocumentId = cursor.getString(7)
                temp.lastUpdatedBy = cursor.getString(8)
                temp.leadTitle = cursor.getString(9)
                temp.description = cursor.getString(10)
                temp.pipelineId = cursor.getString(11)
                temp.phaseId = cursor.getString(12)
                temp.ownerId = cursor.getInt(13)
                temp.leadValue = cursor.getString(14)
                temp.isArchived = cursor.getString(15)
                temp.priority = cursor.getInt(16)
                temp.parentId = cursor.getInt(17)
                temp.billingAddressId = cursor.getString(18)
                temp.shippingAddressId = cursor.getString(19)
                temp.leadTypeId = cursor.getInt(20)
                temp.carId = cursor.getInt(21)
                temp.officeLocationId = cursor.getInt(22)
                temp.statusId = cursor.getInt(23)
                temp.orderStatusId = cursor.getString(24)
                temp.trafficSource = cursor.getString(25)
                temp.requestUrl = cursor.getString(26)
                temp.mechanicId = cursor.getString(27)
                temp.renewCounter = cursor.getString(28)
                temp.accessToken = cursor.getString(29)
                temp.updatedBy = cursor.getInt(30)
                temp.locationType = cursor.getString(31)
                temp.lat = cursor.getDouble(32)
                temp.lon = cursor.getDouble(33)
                temp.address = cursor.getString(34)
                temp.dropLat = cursor.getString(35)
                temp.dropLon = cursor.getString(36)
                temp.dropAddress = cursor.getString(37)
                temp.warehouseInstruction = cursor.getString(38)
                temp.stockNote = cursor.getString(39)
                temp.itemNote = cursor.getString(40)
                temp.isProblemIdentify = cursor.getString(41)
                temp.isWarningLight = cursor.getString(42)
                temp.warningLights = cursor.getString(43)
                temp.testCentral = cursor.getString(44)
                temp.orderId = cursor.getInt(45)
                temp.isCreatedByMechanic = cursor.getString(46)
                temp.configuredBy = cursor.getInt(47)
                temp.isInspection = cursor.getString(48)
                temp.isNew = cursor.getString(49)
                temp.isRead = cursor.getString(50)
                temp.isManual = cursor.getString(51)
                temp.isUrgent = cursor.getString(52)
                temp.isFutureRequest = cursor.getString(53)
                temp.sosIcon = cursor.getString(54)
                temp.customerWorkPlanId = cursor.getInt(55)
                temp.reportType = cursor.getString(56)
                temp.isReportConfirm = cursor.getString(57)
                temp.reportDescription = cursor.getString(58)
                temp.sosRequestId = cursor.getString(59)
                temp.enterKm = cursor.getInt(60)
                temp.isDayClose = cursor.getString(61)
                temp.closeReason = cursor.getString(62)
                temp.configuredByLocationId = cursor.getString(63)
                temp.isWheelChange = cursor.getString(64)
                temp.isAuthorization = cursor.getString(65)
                temp.authorizationCode = cursor.getString(66)
                temp.driverCode = cursor.getString(67)
                temp.isGa = cursor.getString(68)
                temp.offerPdf = cursor.getString(69)
                temp.offerCreatedBy = cursor.getString(70)
                temp.createdFrom = cursor.getString(71)
                temp.emojiSelection = cursor.getString(72)
                temp.deleted = cursor.getString(73)
                temp.createdAt = cursor.getString(74)
                temp.updatedAt = cursor.getString(75)
                temp.firstName = cursor.getString(76)
                temp.lastName = cursor.getString(77)
                temp.businessName = cursor.getString(78)
                temp.fullName = cursor.getString(79)
                temp.email = cursor.getString(80)
                temp.mobile = cursor.getString(81)
                temp.ownerName = cursor.getString(82)
                temp.ownerEmail = cursor.getString(83)
                temp.ownerMobile = cursor.getString(84)
                temp.createdByName = cursor.getString(85)
                temp.configuredByName = cursor.getString(86)
                temp.pipelineName = cursor.getString(87)
                temp.phaseName = cursor.getString(88)
                temp.locationName = cursor.getString(89)
                temp.locationAddress = cursor.getString(90)
                temp.makeName = cursor.getString(91)
                temp.modelName = cursor.getString(92)
                temp.statusName = cursor.getString(93)
                temp.vin = cursor.getString(94)
                temp.locationId = cursor.getInt(95)
                temp.sedeName = cursor.getString(96)
                temp.appointmentCount = cursor.getInt(97)
                temp.kmPhotos = getKmPhoto(cursor.getInt(98))
                temp.eventId = cursor.getInt(99)
            }
        }

        cursor.close()

        return temp

    }


    fun addKmPhoto(data: MechanicKmPhotos, idTemp: Int?): Boolean {

        val db = writableDatabase
        val values = ContentValues()

        values.put(id, data.id)
        values.put(leadId, data.leadId)
        values.put(stepId, data.stepId)
        values.put(carId, data.carId)
        values.put(driverId, data.driverId)
        values.put(categoryId, data.categoryId)
        values.put(presetCategoryId, data.presetCategoryId)
        values.put(orderDetailId, data.orderDetailId)
        values.put(fileName, data.fileName)
        values.put(fileLocation, data.fileLocation)
        values.put(optionType, data.optionType)
        values.put(fileType, data.fileType)
        values.put(wheelType, data.wheelType)
        values.put(generalType, data.generalType)
        values.put(createdBy, data.createdBy)
        values.put(deleted, data.deleted)
        values.put(createdAt, data.createdAt)
        values.put(updatedAt, data.updatedAt)
        values.put(stepName, data.stepName)
        values.put(driverName, data.driverName)
        values.put(eventId, idTemp)

        val result = db.insert(kmPhoto, null, values)
        if (db.isOpen) {
            db.close()
        }
        return result != -1L

    }

    private fun getKmPhoto(idTemp: Int): ArrayList<MechanicKmPhotos> {

        val cursor: Cursor = writableDatabase.rawQuery(
            "select * from $kmPhoto where $eventId = '$idTemp'", null
        )

        val data = ArrayList<MechanicKmPhotos>()

        if (cursor.count != 0) {
            while (cursor.moveToNext()) {

                val temp = MechanicKmPhotos()

                temp.id = cursor.getInt(0)
                temp.leadId = cursor.getInt(1)
                temp.stepId = cursor.getString(2)
                temp.carId = cursor.getInt(3)
                temp.driverId = cursor.getString(4)
                temp.categoryId = cursor.getString(5)
                temp.presetCategoryId = cursor.getString(6)
                temp.orderDetailId = cursor.getInt(7)
                temp.fileName = cursor.getString(8)
                temp.fileLocation = cursor.getString(9)
                temp.optionType = cursor.getString(10)
                temp.fileType = cursor.getString(11)
                temp.wheelType = cursor.getString(12)
                temp.generalType = cursor.getString(13)
                temp.createdBy = cursor.getInt(14)
                temp.deleted = cursor.getString(15)
                temp.createdAt = cursor.getString(16)
                temp.updatedAt = cursor.getString(17)
                temp.stepName = cursor.getString(18)
                temp.driverName = cursor.getString(19)

                data.add(temp)
            }
        }

        cursor.close()

        return removeDuplicates(data)
    }

    private fun getKmPhotoSingle(idTemp: Int): MechanicKmPhotos {

        val cursor: Cursor = writableDatabase.rawQuery(
            "select * from $kmPhoto where $eventId = '$idTemp'", null
        )

        val temp = MechanicKmPhotos()

        if (cursor.count != 0) {
            while (cursor.moveToNext()) {

                temp.id = cursor.getInt(0)
                temp.leadId = cursor.getInt(1)
                temp.stepId = cursor.getString(2)
                temp.carId = cursor.getInt(3)
                temp.driverId = cursor.getString(4)
                temp.categoryId = cursor.getString(5)
                temp.presetCategoryId = cursor.getString(6)
                temp.orderDetailId = cursor.getInt(7)
                temp.fileName = cursor.getString(8)
                temp.fileLocation = cursor.getString(9)
                temp.optionType = cursor.getString(10)
                temp.fileType = cursor.getString(11)
                temp.wheelType = cursor.getString(12)
                temp.generalType = cursor.getString(13)
                temp.createdBy = cursor.getInt(14)
                temp.deleted = cursor.getString(15)
                temp.createdAt = cursor.getString(16)
                temp.updatedAt = cursor.getString(17)
                temp.stepName = cursor.getString(18)
                temp.driverName = cursor.getString(19)
            }
        }

        cursor.close()

        return temp
    }


    private fun addLastRequest(data: MechanicKmLastRequest, idTemp: Int?): Boolean {
        val db = writableDatabase
        val values = ContentValues()

        values.put(id, data.id)
        values.put(displayId, data.displayId)
        values.put(numberPlate, data.numberPlate)
        values.put(contactId, data.contactId)
        values.put(createdBy, data.createdBy)
        values.put(parentLeadId, data.parentLeadId)
        values.put(customerDisplayId, data.customerDisplayId)
        values.put(customerDocumentId, data.customerDocumentId)
        values.put(lastUpdatedBy, data.lastUpdatedBy)
        values.put(leadTitle, data.leadTitle)
        values.put(description, data.description)
        values.put(pipelineId, data.pipelineId)
        values.put(phaseId, data.phaseId)
        values.put(ownerId, data.ownerId)
        values.put(leadValue, data.leadValue)
        values.put(isArchived, data.isArchived)
        values.put(priority, data.priority)
        values.put(parentId, data.parentId)
        values.put(billingAddressId, data.billingAddressId)
        values.put(shippingAddressId, data.shippingAddressId)
        values.put(leadTypeId, data.leadTypeId)
        values.put(carId, data.carId)
        values.put(officeLocationId, data.officeLocationId)
        values.put(statusId, data.statusId)
        values.put(orderStatusId, data.orderStatusId)
        values.put(trafficSource, data.trafficSource)
        values.put(requestUrl, data.requestUrl)
        values.put(mechanicId, data.mechanicId)
        values.put(renewCounter, data.renewCounter)
        values.put(accessToken, data.accessToken)
        values.put(updatedBy, data.updatedBy)
        values.put(locationType, data.locationType)
        values.put(lat, data.lat)
        values.put(lon, data.lon)
        values.put(address, data.address)
        values.put(dropLat, data.dropLat)
        values.put(dropLon, data.dropLon)
        values.put(dropAddress, data.dropAddress)
        values.put(warehouseInstruction, data.warehouseInstruction)
        values.put(stockNote, data.stockNote)
        values.put(itemNote, data.itemNote)
        values.put(isProblemIdentify, data.isProblemIdentify)
        values.put(isWarningLight, data.isWarningLight)
        values.put(warningLights, data.warningLights)
        values.put(testCentral, data.testCentral)
        values.put(orderId, data.orderId)
        values.put(isCreatedByMechanic, data.isCreatedByMechanic)
        values.put(configuredBy, data.configuredBy)
        values.put(isInspection, data.isInspection)
        values.put(isNew, data.isNew)
        values.put(isRead, data.isRead)
        values.put(isManual, data.isManual)
        values.put(isUrgent, data.isUrgent)
        values.put(isFutureRequest, data.isFutureRequest)
        values.put(sosIcon, data.sosIcon)
        values.put(customerWorkPlanId, data.customerWorkPlanId)
        values.put(reportType, data.reportType)
        values.put(isReportConfirm, data.isReportConfirm)
        values.put(reportDescription, data.reportDescription)
        values.put(sosRequestId, data.sosRequestId)
        values.put(enterKm, data.enterKm)
        values.put(isDayClose, data.isDayClose)
        values.put(closeReason, data.closeReason)
        values.put(configuredByLocationId, data.configuredByLocationId)
        values.put(isWheelChange, data.isWheelChange)
        values.put(isAuthorization, data.isAuthorization)
        values.put(authorizationCode, data.authorizationCode)
        values.put(driverCode, data.driverCode)
        values.put(isGa, data.isGa)
        values.put(offerPdf, data.offerPdf)
        values.put(offerCreatedBy, data.offerCreatedBy)
        values.put(createdFrom, data.createdFrom)
        values.put(emojiSelection, data.emojiSelection)
        values.put(deleted, data.deleted)
        values.put(createdAt, data.createdAt)
        values.put(updatedAt, data.updatedAt)
        values.put(updatedByName, data.updatedByName)
        values.put(eventId, idTemp)


        val result = db.insert(kmLastRequest, null, values)
        if (db.isOpen) {
            db.close()
        }
        return result != -1L
    }

    private fun getLastRequest(idTemp: Int): MechanicKmLastRequest {

        val cursor: Cursor = writableDatabase.rawQuery(
            "select * from $kmLastRequest where $eventId = '$idTemp'", null
        )

        val temp = MechanicKmLastRequest()

        if (cursor.count != 0) {
            while (cursor.moveToNext()) {

                temp.id = cursor.getInt(0)
                temp.displayId = cursor.getString(1)
                temp.numberPlate = cursor.getString(2)
                temp.contactId = cursor.getInt(3)
                temp.createdBy = cursor.getInt(4)
                temp.parentLeadId = cursor.getString(5)
                temp.customerDisplayId = cursor.getString(6)
                temp.customerDocumentId = cursor.getString(7)
                temp.lastUpdatedBy = cursor.getString(8)
                temp.leadTitle = cursor.getString(9)
                temp.description = cursor.getString(10)
                temp.pipelineId = cursor.getString(11)
                temp.phaseId = cursor.getString(12)
                temp.ownerId = cursor.getInt(13)
                temp.leadValue = cursor.getString(14)
                temp.isArchived = cursor.getString(15)
                temp.priority = cursor.getInt(16)
                temp.parentId = cursor.getInt(17)
                temp.billingAddressId = cursor.getString(18)
                temp.shippingAddressId = cursor.getString(19)
                temp.leadTypeId = cursor.getInt(20)
                temp.carId = cursor.getInt(21)
                temp.officeLocationId = cursor.getInt(22)
                temp.statusId = cursor.getInt(23)
                temp.orderStatusId = cursor.getInt(24)
                temp.trafficSource = cursor.getString(25)
                temp.requestUrl = cursor.getString(26)
                temp.mechanicId = cursor.getString(27)
                temp.renewCounter = cursor.getString(28)
                temp.accessToken = cursor.getString(29)
                temp.updatedBy = cursor.getString(30)
                temp.locationType = cursor.getString(31)
                temp.lat = cursor.getDouble(32)
                temp.lon = cursor.getDouble(33)
                temp.address = cursor.getString(34)
                temp.dropLat = cursor.getString(35)
                temp.dropLon = cursor.getString(36)
                temp.dropAddress = cursor.getString(37)
                temp.warehouseInstruction = cursor.getString(38)
                temp.stockNote = cursor.getString(39)
                temp.itemNote = cursor.getString(40)
                temp.isProblemIdentify = cursor.getString(41)
                temp.isWarningLight = cursor.getString(42)
                temp.warningLights = cursor.getString(43)
                temp.testCentral = cursor.getString(44)
                temp.orderId = cursor.getInt(45)
                temp.isCreatedByMechanic = cursor.getString(46)
                temp.configuredBy = cursor.getInt(47)
                temp.isInspection = cursor.getString(48)
                temp.isNew = cursor.getString(49)
                temp.isRead = cursor.getString(50)
                temp.isManual = cursor.getString(51)
                temp.isUrgent = cursor.getString(52)
                temp.isFutureRequest = cursor.getString(53)
                temp.sosIcon = cursor.getString(54)
                temp.customerWorkPlanId = cursor.getInt(55)
                temp.reportType = cursor.getString(56)
                temp.isReportConfirm = cursor.getString(57)
                temp.reportDescription = cursor.getString(58)
                temp.sosRequestId = cursor.getString(59)
                temp.enterKm = cursor.getString(60)
                temp.isDayClose = cursor.getString(61)
                temp.closeReason = cursor.getString(62)
                temp.configuredByLocationId = cursor.getString(63)
                temp.isWheelChange = cursor.getString(64)
                temp.isAuthorization = cursor.getString(65)
                temp.authorizationCode = cursor.getString(66)
                temp.driverCode = cursor.getString(67)
                temp.isGa = cursor.getString(68)
                temp.offerPdf = cursor.getString(69)
                temp.offerCreatedBy = cursor.getString(70)
                temp.createdFrom = cursor.getString(71)
                temp.emojiSelection = cursor.getString(72)
                temp.deleted = cursor.getString(73)
                temp.createdAt = cursor.getString(74)
                temp.updatedAt = cursor.getString(75)
                temp.updatedByName = cursor.getString(76)
                temp.eventId = cursor.getInt(77)
            }
        }

        cursor.close()

        return temp

    }


    private fun addKmPreviousRequestEvent(
        data: MechanicKmPreviousRequestEvent,
        idTemp: Int?
    ): Boolean {
        val db = writableDatabase
        val values = ContentValues()

        values.put(id, data.id)
        values.put(leadId, data.leadId)
        values.put(title, data.title)
        values.put(description, data.description)
        values.put(contactId, data.contactId)
        values.put(createdBy, data.createdBy)
        values.put(parentEventId, data.parentEventId)
        values.put(calendarWorkPlanId, data.calendarWorkPlanId)
        values.put(customerWorkPlanId, data.customerWorkPlanId)
        values.put(objectType, data.objectType)
        values.put(actionDate, data.actionDate)
        values.put(mobileStationId, data.mobileStationId)
        values.put(fileName, data.fileName)
        values.put(fileLocation, data.fileLocation)
        values.put(completed, data.completed)
        values.put(assignTo, data.assignTo)
        values.put(startDate, data.startDate)
        values.put(endDate, data.endDate)
        values.put(workWithUserId, data.workWithUserId)
        values.put(appointmentRepeatCount, data.appointmentRepeatCount)
        values.put(appointmentRepeatOption, data.appointmentRepeatOption)
        values.put(remindCron, data.remindCron)
        values.put(repeatAppointmentMainId, data.repeatAppointmentMainId)
        values.put(isVisible, data.isVisible)
        values.put(parentId, data.parentId)
        values.put(isAllday, data.isAllday)
        values.put(eventNotification, data.eventNotification)
        values.put(notificationDuration, data.notificationDuration)
        values.put(notificationOption, data.notificationOption)
        values.put(mainEventId, data.mainEventId)
        values.put(workWithIds, data.workWithIds)
        values.put(isConfirm, data.isConfirm)
        values.put(inviteEmail, data.inviteEmail)
        values.put(callAppointment, data.callAppointment)
        values.put(appointmentRequestFrom, data.appointmentRequestFrom)
        values.put(isPending, data.isPending)
        values.put(deleted, data.deleted)
        values.put(confirmedAt, data.confirmedAt)
        values.put(isClosed, data.isClosed)
        values.put(closedAt, data.closedAt)
        values.put(travelStart, data.travelStart)
        values.put(travelEnd, data.travelEnd)
        values.put(travelTime, data.travelTime)
        values.put(totalKm, data.totalKm)
        values.put(isEventStart, data.isEventStart)
        values.put(isTravelCompleted, data.isTravelCompleted)
        values.put(towRequestAccepted, data.towRequestAccepted)
        values.put(isPicked, data.isPicked)
        values.put(isManualReport, data.isManualReport)
        values.put(isPauseTravel, data.isPauseTravel)
        values.put(workStartTime, data.workStartTime)
        values.put(workEndTime, data.workEndTime)
        values.put(mechanicWorkStartTime, data.mechanicWorkStartTime)
        values.put(mechanicWorkEndTime, data.mechanicWorkEndTime)
        values.put(mechanicTravelStartTime, data.mechanicTravelStartTime)
        values.put(mechanicTravelEndTime, data.mechanicTravelEndTime)
        values.put(mechanicTravelBreakStart, data.mechanicTravelBreakStart)
        values.put(mechanicTravelBreakEnd, data.mechanicTravelBreakEnd)
        values.put(mechanicTravelRestart, data.mechanicTravelRestart)
        values.put(mobileStationLat, data.mobileStationLat)
        values.put(mobileStationLon, data.mobileStationLon)
        values.put(sourceAddress, data.sourceAddress)
        values.put(destinationAddress, data.destinationAddress)
        values.put(dropAddress, data.dropAddress)
        values.put(workHours, data.workHours)
        values.put(currentStep, data.currentStep)
        values.put(closeReason, data.closeReason)
        values.put(isWorkNotDone, data.isWorkNotDone)
        values.put(previousEventId, data.previousEventId)
        values.put(isDayClose, data.isDayClose)
        values.put(isReportConfirm, data.isReportConfirm)
        values.put(isEventReopen, data.isEventReopen)
        values.put(isReminderSent, data.isReminderSent)
        values.put(carId, data.carId)
        values.put(reportConfirmAt, data.reportConfirmAt)
        values.put(reportConfirmBy, data.reportConfirmBy)
        values.put(createdAt, data.createdAt)
        values.put(updatedAt, data.updatedAt)
        values.put(deletedAt, data.deletedAt)
        values.put(userName, data.userName)
        values.put(calendarColor, data.calendarColor)
        values.put(businessName, data.businessName)
        values.put(firstName, data.firstName)
        values.put(lastName, data.lastName)
        values.put(email, data.email)
        values.put(mobile, data.mobile)
        values.put(displayId, data.displayId)
        values.put(numberPlate, data.numberPlate)
        values.put(statusId, data.statusId)
        values.put(priority, data.priority)
        values.put(leadTypeId, data.leadTypeId)
        values.put(orderId, data.orderId)
        values.put(lat, data.lat)
        values.put(lon, data.lon)
        values.put(address, data.address)
        values.put(dropLat, data.dropLat)
        values.put(dropLon, data.dropLon)
        values.put(enterKm, data.enterKm)
        values.put(calendarWorkDisplayId, data.calendarWorkDisplayId)
        values.put(note, data.note)
        values.put(isNoteRead, data.isNoteRead)
        values.put(customerWorkPlanStatusId, data.customerWorkPlanStatusId)
        values.put(sedeName, data.sedeName)
        values.put(officeCalendarColor, data.officeCalendarColor)
        values.put(makeName, data.makeName)
        values.put(modelName, data.modelName)
        values.put(eventId, idTemp)

        val result = db.insert(kmPreviousRequestEvent, null, values)
        if (db.isOpen) {
            db.close()
        }
        return result != -1L
    }

    private fun getPreviousRequestEvent(idTemp: Int): MechanicKmPreviousRequestEvent {

        val cursor: Cursor = writableDatabase.rawQuery(
            "select * from $kmPreviousRequestEvent where $id = '$idTemp'", null
        )

        val temp = MechanicKmPreviousRequestEvent()

        if (cursor.count != 0) {
            while (cursor.moveToNext()) {

                temp.id = cursor.getInt(0)
                temp.leadId = cursor.getInt(1)
                temp.title = cursor.getString(2)
                temp.description = cursor.getString(3)
                temp.contactId = cursor.getInt(4)
                temp.createdBy = cursor.getInt(5)
                temp.parentEventId = cursor.getInt(6)
                temp.calendarWorkPlanId = cursor.getInt(7)
                temp.customerWorkPlanId = cursor.getInt(8)
                temp.objectType = cursor.getString(9)
                temp.actionDate = cursor.getString(10)
                temp.mobileStationId = cursor.getInt(11)
                temp.fileName = cursor.getString(12)
                temp.fileLocation = cursor.getString(13)
                temp.completed = cursor.getString(14)
                temp.assignTo = cursor.getInt(15)
                temp.startDate = cursor.getString(16)
                temp.endDate = cursor.getString(17)
                temp.workWithUserId = cursor.getString(18)
                temp.appointmentRepeatCount = cursor.getString(19)
                temp.appointmentRepeatOption = cursor.getString(20)
                temp.remindCron = cursor.getString(21)
                temp.repeatAppointmentMainId = cursor.getString(22)
                temp.isVisible = cursor.getInt(23)
                temp.parentId = cursor.getInt(24)
                temp.isAllday = cursor.getInt(25)
                temp.eventNotification = cursor.getString(26)
                temp.notificationDuration = cursor.getString(27)
                temp.notificationOption = cursor.getString(28)
                temp.mainEventId = cursor.getString(29)
                temp.workWithIds = cursor.getString(30)
                temp.isConfirm = cursor.getString(31)
                temp.inviteEmail = cursor.getString(32)
                temp.callAppointment = cursor.getString(33)
                temp.appointmentRequestFrom = cursor.getString(34)
                temp.isPending = cursor.getString(35)
                temp.deleted = cursor.getString(36)
                temp.confirmedAt = cursor.getString(37)
                temp.isClosed = cursor.getString(38)
                temp.closedAt = cursor.getString(39)
                temp.travelStart = cursor.getString(40)
                temp.travelEnd = cursor.getString(41)
                temp.travelTime = cursor.getDouble(42)
                temp.totalKm = cursor.getFloat(43)
                temp.isEventStart = cursor.getString(44)
                temp.isTravelCompleted = cursor.getString(45)
                temp.towRequestAccepted = cursor.getString(46)
                temp.isPicked = cursor.getString(47)
                temp.isManualReport = cursor.getString(48)
                temp.isPauseTravel = cursor.getString(49)
                temp.workStartTime = cursor.getString(50)
                temp.workEndTime = cursor.getString(51)
                temp.mechanicWorkStartTime = cursor.getString(52)
                temp.mechanicWorkEndTime = cursor.getString(53)
                temp.mechanicTravelStartTime = cursor.getString(54)
                temp.mechanicTravelEndTime = cursor.getString(55)
                temp.mechanicTravelBreakStart = cursor.getString(56)
                temp.mechanicTravelBreakEnd = cursor.getString(57)
                temp.mechanicTravelRestart = cursor.getString(58)
                temp.mobileStationLat = cursor.getDouble(59)
                temp.mobileStationLon = cursor.getDouble(60)
                temp.sourceAddress = cursor.getString(61)
                temp.destinationAddress = cursor.getString(62)
                temp.dropAddress = cursor.getString(63)
                temp.workHours = cursor.getDouble(64)
                temp.currentStep = cursor.getString(65)
                temp.closeReason = cursor.getString(66)
                temp.isWorkNotDone = cursor.getString(67)
                temp.previousEventId = cursor.getString(68)
                temp.isDayClose = cursor.getString(69)
                temp.isReportConfirm = cursor.getString(70)
                temp.isEventReopen = cursor.getString(71)
                temp.isReminderSent = cursor.getString(72)
                temp.carId = cursor.getInt(73)
                temp.reportConfirmAt = cursor.getString(74)
                temp.reportConfirmBy = cursor.getString(75)
                temp.createdAt = cursor.getString(76)
                temp.updatedAt = cursor.getString(77)
                temp.deletedAt = cursor.getString(78)
                temp.userName = cursor.getString(79)
                temp.calendarColor = cursor.getString(80)
                temp.businessName = cursor.getString(81)
                temp.firstName = cursor.getString(82)
                temp.lastName = cursor.getString(83)
                temp.email = cursor.getString(84)
                temp.mobile = cursor.getString(85)
                temp.displayId = cursor.getString(86)
                temp.numberPlate = cursor.getString(87)
                temp.statusId = cursor.getInt(88)
                temp.priority = cursor.getInt(89)
                temp.leadTypeId = cursor.getInt(90)
                temp.orderId = cursor.getInt(91)
                temp.lat = cursor.getDouble(92)
                temp.lon = cursor.getDouble(93)
                temp.address = cursor.getString(94)
                temp.dropLat = cursor.getString(95)
                temp.dropLon = cursor.getString(96)
                temp.enterKm = cursor.getInt(97)
                temp.calendarWorkDisplayId = cursor.getString(98)
                temp.note = cursor.getString(99)
                temp.isNoteRead = cursor.getString(100)
                temp.customerWorkPlanStatusId = cursor.getInt(101)
                temp.sedeName = cursor.getString(102)
                temp.officeCalendarColor = cursor.getString(103)
                temp.makeName = cursor.getString(104)
                temp.modelName = cursor.getString(105)
                temp.eventId = cursor.getInt(106)

            }
        }

        cursor.close()

        return temp

    }


    private fun addKmPreviousRequestMobileStation(
        data: MechanicKmPreviousRequestMobileStation,
        idTemp: Int?
    ): Boolean {
        val db = writableDatabase
        val values = ContentValues()

        values.put(id, data.id)
        values.put(carId, data.carId)
        values.put(displayId, data.displayId)
        values.put(name, data.name)
        values.put(address, data.address)
        values.put(state, data.state)
        values.put(postalCode, data.postalCode)
        values.put(lat, data.lat)
        values.put(lon, data.lon)
        values.put(customerId, data.customerId)
        values.put(locationType, data.locationType)
        values.put(parentId, data.parentId)
        values.put(officeIcon, data.officeIcon)
        values.put(calendarColor, data.calendarColor)
        values.put(partnerName, data.partnerName)
        values.put(deleted, data.deleted)
        values.put(createdAt, data.createdAt)
        values.put(updatedAt, data.updatedAt)
        values.put(latitude, data.latitude)
        values.put(longitude, data.longitude)
        values.put(mslid, data.mslid)
        values.put(numberPlate, data.numberPlate)
        values.put(eventId, idTemp)

        val result = db.insert(kmPreviousRequestMobileStation, null, values)
        if (db.isOpen) {
            db.close()
        }
        return result != -1L
    }

    private fun getPreviousRequestMobileStation(idTemp: Int): MechanicKmPreviousRequestMobileStation {

        val cursor: Cursor = writableDatabase.rawQuery(
            "select * from $kmPreviousRequestMobileStation where $eventId = '$idTemp'", null
        )

        val temp = MechanicKmPreviousRequestMobileStation()

        if (cursor.count != 0) {
            while (cursor.moveToNext()) {

                temp.id = cursor.getInt(0)
                temp.carId = cursor.getInt(1)
                temp.displayId = cursor.getString(2)
                temp.name = cursor.getString(3)
                temp.address = cursor.getString(4)
                temp.state = cursor.getString(5)
                temp.postalCode = cursor.getString(6)
                temp.lat = cursor.getDouble(7)
                temp.lon = cursor.getDouble(8)
                temp.customerId = cursor.getString(9)
                temp.locationType = cursor.getString(10)
                temp.parentId = cursor.getInt(11)
                temp.officeIcon = cursor.getString(12)
                temp.calendarColor = cursor.getString(13)
                temp.partnerName = cursor.getString(14)
                temp.deleted = cursor.getString(15)
                temp.createdAt = cursor.getString(16)
                temp.updatedAt = cursor.getString(17)
                temp.latitude = cursor.getDouble(18)
                temp.longitude = cursor.getDouble(19)
                temp.mslid = cursor.getInt(20)
                temp.numberPlate = cursor.getString(21)
                temp.eventId = cursor.getInt(22)

            }
        }

        cursor.close()

        return temp

    }


    fun deleteData(idTemp: Int): Boolean {

        val cursor: Cursor = writableDatabase.rawQuery(
            "select * from $mechanicEvent where $id = '$idTemp'", null
        )

        var cur1 = ""
        var cur2 = ""
        var cur3 = ""

        if (cursor.count != 0) {
            while (cursor.moveToNext()) {

                cur1 = cursor.getString(0)
                cur2 = cursor.getString(1)
                cur3 = cursor.getString(2)

            }
        }
        cursor.close()

        val cursor2: Cursor = writableDatabase.rawQuery(
            "select * from $kmDetailData where $id = '$idTemp'", null
        )

        var cur21 = ""
        var cur22 = ""
        var cur23 = ""
        var cur24 = ""

        if (cursor2.count != 0) {
            while (cursor2.moveToNext()) {

                cur21 = cursor2.getString(0)
                cur22 = cursor2.getString(1)
                cur23 = cursor2.getString(2)
                cur24 = cursor2.getString(3)

            }
        }
        cursor2.close()

        val cursor3: Cursor = writableDatabase.rawQuery(
            "select * from $eventWorkReportSteps where $eventId = '$idTemp'", null
        )

        val imageDelete1 = ArrayList<Int>()

        if (cursor3.count != 0) {
            while (cursor3.moveToNext()) {
                imageDelete1.add(cursor3.getInt(30))
            }
        }
        cursor3.close()

        val cursor5: Cursor = writableDatabase.rawQuery(
            "select * from $eventWorkReportSteps where $eventId = '$idTemp'", null
        )

        val categoriesData = ArrayList<Int>()

        if (cursor5.count != 0) {
            while (cursor5.moveToNext()) {
                categoriesData.add(cursor5.getInt(29))
            }
        }
        cursor5.close()

        val imageDelete2 = ArrayList<Int>()
        val montataDelete = ArrayList<Int>()
        for (temp in categoriesData) {
            val cursor4: Cursor = writableDatabase.rawQuery(
                "select * from $kmCategories where $eventId = '$temp'", null
            )

            if (cursor4.count != 0) {
                while (cursor4.moveToNext()) {
                    montataDelete.add(cursor4.getInt(22))
                    montataDelete.add(cursor4.getInt(23))
                    imageDelete2.add(cursor4.getInt(24))
                    imageDelete2.add(cursor4.getInt(25))
                    imageDelete2.add(cursor4.getInt(26))
                }
            }
            cursor4.close()
        }

        val db = writableDatabase

        db.delete(event, "$id= ? \n", arrayOf(cur1))
        db.delete(kmPhoto, "$eventId= ? \n", arrayOf(cur21))
        db.delete(kmLeadData, "$eventId= ? \n", arrayOf(cur21))
        db.delete(kmLastRequest, "$eventId= ? \n", arrayOf(cur22))
        db.delete(kmPreviousRequestEvent, "$id= ? \n", arrayOf(cur23))
        db.delete(kmPreviousRequestMobileStation, "$eventId= ? \n", arrayOf(cur24))
        db.delete(kmDetailData, "$id= ? \n", arrayOf(cur2))
        if (cur3 != "") {
            val data = getWorkReportSteps(cur3.toInt())
            for (tem in data) {
                db.delete(kmLeadItems, "$eventId= ? \n", arrayOf(tem.id.toString()))
                db.delete(kmCategories, "$eventId= ? \n", arrayOf(tem.id.toString()))
            }
        }
        db.delete(eventWorkReportSteps, "$eventId= ? \n", arrayOf(cur3))
        for (temp in imageDelete2) {
            db.delete(kmPhoto, "$eventId= ? \n", arrayOf(temp.toString()))
        }
        for (temp in montataDelete) {
            db.delete(montataData, "$id= ? \n", arrayOf(temp.toString()))
        }
        for (temp in imageDelete1) {
            db.delete(kmPhoto, "$eventId= ? \n", arrayOf(temp.toString()))
        }

        val isDeleted = db.delete(
            mechanicEvent,
            "$id= ? \n", arrayOf(idTemp.toString())
        )
        db.close()
        return isDeleted != 0
    }


    fun deletePhoto(idTemp: Int): Boolean {

        val db = writableDatabase

        val isDeleted = db.delete(kmPhoto, "$id= ? \n", arrayOf(idTemp.toString()))
        db.close()
        return isDeleted != 0
    }

    fun deleteKmData(tempId: Int) {
        val db = writableDatabase
        db.delete(kmLeadData, "$eventId= ? \n", arrayOf(tempId.toString()))
        db.close()
    }

    private fun <T> removeDuplicates(list: ArrayList<T>): ArrayList<T> {
        val newList = ArrayList<T>()
        for (element in list) {
            if (!newList.contains(element)) {
                newList.add(element)
            }
        }
        return newList
    }
}