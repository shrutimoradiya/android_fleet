package com.antares.fleetservice.model

import android.net.Uri
import java.io.File

data class TimeCameraModel(
    var     file        : File? = null,
    var     filepath    : String? = null,
    var     fileuri     : Uri? = null,
    var     filename    : String? = null,
)
