package com.antares.fleetservice.model.getCarDocument

import com.google.gson.annotations.SerializedName

data class CarDocumentJson(
    @SerializedName("car" ) var car : Car? = Car()
)
