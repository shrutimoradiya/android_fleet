package com.antares.fleetservice.model.mechanicAttendance

import com.google.gson.annotations.SerializedName

data class Mechanics(
    @SerializedName("id") var id: Int? = null,
    @SerializedName("first_name") var firstName: String? = null,
    @SerializedName("last_name") var lastName: String? = null,
    @SerializedName("email") var email: String? = null,
    @SerializedName("role") var role: String? = null,
    @SerializedName("piva") var piva: String? = null,
    @SerializedName("fiscal_code") var fiscalCode: String? = null,
    @SerializedName("contact_type") var contactType: String? = null,
    @SerializedName("mobile") var mobile: String? = null,
    @SerializedName("calendar_color") var calendarColor: String? = null,
    @SerializedName("photo") var photo: String? = null,
    @SerializedName("parent_id") var parentId: Int? = null,
    @SerializedName("is_main_user") var isMainUser: String? = null,
    @SerializedName("deleted") var deleted: String? = null,
    @SerializedName("created_at") var createdAt: String? = null,
    @SerializedName("full_name") var fullName: String? = null,
    @SerializedName("location_name") var locationName: String? = null,
    @SerializedName("location_address") var locationAddress: String? = null,
    @SerializedName("display_name") var displayName: String? = null,
    @SerializedName("business_name") var businessName: String? = null,
    @SerializedName("user_type") var userType: String? = null,
    var isSelected: Boolean = false
)