package com.antares.fleetservice.model.getFood

import com.antares.fleetservice.model.food.FoodLunch
import com.google.gson.annotations.SerializedName

data class GetFoodData(
    @SerializedName("break_lists"       )   var     breakLists      : ArrayList<FoodLunch>? = null,
    @SerializedName("open_break_detail" )   var     openBreakDetail : String? = null
)