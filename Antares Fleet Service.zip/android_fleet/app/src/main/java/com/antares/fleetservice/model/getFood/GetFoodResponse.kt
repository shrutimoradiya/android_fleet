package com.antares.fleetservice.model.getFood

import com.antares.fleetservice.model.BaseResponse
import com.google.gson.annotations.SerializedName

data class GetFoodResponse(
    @SerializedName("json"  )   var     json    : GetFoodData? = null
) : BaseResponse()