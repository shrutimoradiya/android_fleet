package com.antares.fleetservice.model.mechanicAttendance

import com.google.gson.annotations.SerializedName

data class MechanicAttendanceResponse(
    @SerializedName("code") var code: Int? = null,
    @SerializedName("json") var json: MechanicAttendanceJson? = MechanicAttendanceJson()
)