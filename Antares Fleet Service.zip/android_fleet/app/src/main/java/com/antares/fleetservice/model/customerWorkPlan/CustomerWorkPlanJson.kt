package com.antares.fleetservice.model.customerWorkPlan

import com.google.gson.annotations.SerializedName

data class CustomerWorkPlanJson(
    @SerializedName("customer_work_plans"       )   var     customerWorkPlans       : ArrayList<String> = arrayListOf(),
    @SerializedName("date_customer_work_plans"  )   var     dateCustomerWorkPlans   : ArrayList<String> = arrayListOf(),
    @SerializedName("locations"                 )   var     locations               : ArrayList<Locations> = arrayListOf()
)