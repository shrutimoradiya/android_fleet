package com.antares.fleetservice.model.searchProduct

import com.google.gson.annotations.SerializedName

data class SearchProductResponse(
    @SerializedName("code"  )   var     code    : Int? = null,
    @SerializedName("json"  )   var     json    : SearchProductJson? = SearchProductJson()
)