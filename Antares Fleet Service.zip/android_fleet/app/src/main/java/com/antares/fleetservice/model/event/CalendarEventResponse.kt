package com.antares.fleetservice.model.event

import com.antares.fleetservice.model.BaseResponse
import com.google.gson.annotations.SerializedName

data class CalendarEventResponse(
    @SerializedName("json"  )   var     response    : CalendarEventJson? = null
) : BaseResponse()