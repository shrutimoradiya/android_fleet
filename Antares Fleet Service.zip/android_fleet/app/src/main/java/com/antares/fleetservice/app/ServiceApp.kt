package com.antares.fleetservice.app

import android.app.Application
import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.lifecycle.ViewModelProvider
import com.antares.fleetservice.R
import com.antares.fleetservice.dataBase.ApiCallLeftDB
import com.antares.fleetservice.utils.Constant
import com.antares.fleetservice.view.widget.dialog.AlertDialog
import com.antares.fleetservice.viewmodel.ApiCallViewModel

class ServiceApp : Application() {

    companion object {

        var context: Context? = null
        var mInstance: ServiceApp? = null
    }

    private var apiCallViewModel: ApiCallViewModel? = null

    override fun onCreate() {
        super.onCreate()
        context = this
        mInstance = this

        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        apiCallViewModel = applicationContext?.let {
            ViewModelProvider.AndroidViewModelFactory
                .getInstance(it as Application)
                .create(ApiCallViewModel::class.java)
        }

    }

    fun setConnectivityListener(listener: ConnectivityReceiver.ConnectivityReceiverListener?) {
        ConnectivityReceiver.connectivityReceiverListener = listener
    }

    fun setNetwork(connected: Boolean, context: AppCompatActivity) {
        if (Constant.getBool(context, Constant.connection) != connected) {
            Constant.saveBool(context, Constant.connection, connected)
            if (connected) {
                isOnlineDialog(context)
            } else {
                isOfflineDialog(context)
            }
        }
    }

    private fun isOnlineDialog(contexts: AppCompatActivity) {
        val myDbh = ApiCallLeftDB(context as ServiceApp)
        val list = myDbh.viewData()

        if (list.size != 0) {

            AlertDialog(
                contexts,
                (context as ServiceApp).getString(R.string.online),
                (context as ServiceApp).getString(R.string.internet_on) + list.size,
                false,
                object : AlertDialog.OnOptionSelected {
                    override fun onConfirmClick() {
                        apiCallViewModel?.apiCall(contexts)
                    }

                    override fun onAggiungiMezzoClick() {}
                }
            ).show()

        }
    }

    private fun isOfflineDialog(contexts: AppCompatActivity) {
        AlertDialog(
            contexts,
            (context as ServiceApp).getString(R.string.offline),
            (context as ServiceApp).getString(R.string.internet_off),
            false,
            object : AlertDialog.OnOptionSelected {
                override fun onConfirmClick() {}
                override fun onAggiungiMezzoClick() {}
            }
        ).show()
    }
}