package com.antares.fleetservice.model.getCarDocument

import com.google.gson.annotations.SerializedName

data class CarDocumentResponse (

    @SerializedName("code" ) var code : Int?  = null,
    @SerializedName("json" ) var json : CarDocumentJson? = CarDocumentJson()

)