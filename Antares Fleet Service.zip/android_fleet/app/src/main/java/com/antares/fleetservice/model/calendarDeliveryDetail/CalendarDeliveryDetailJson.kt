package com.antares.fleetservice.model.calendarDeliveryDetail

import com.google.gson.annotations.SerializedName

data class CalendarDeliveryDetailJson(
    @SerializedName("events"    )   var     events  : ArrayList<CalendarDeliveryDetailEvents> = arrayListOf()
)