package com.antares.fleetservice.model.seda

import com.google.gson.annotations.SerializedName

data class SedaResponse(
    @SerializedName("code"  )   var     code    : Int? = null,
    @SerializedName("json"  )   var     json    : SedaJson? = SedaJson()

)