package com.antares.fleetservice.model.mechanic.event

import com.google.gson.annotations.SerializedName

data class MechanicEventJson(
    @SerializedName("event"             )   var     eventDetail     : MechanicEvent? = null,
    @SerializedName("km_detail"         )   var     kmDetail        : MechanicKmDetail? = null,
    @SerializedName("work_report_steps" )   var     workReportSteps : ArrayList<MechanicEventWorkReportSteps>? = null,
    @SerializedName("day_close_history" )   var     dayCloseHistory : MechanicDayCloseHistory?  = null,
    @SerializedName("car"               )   var     car             : MechanicCar?       = null
)
