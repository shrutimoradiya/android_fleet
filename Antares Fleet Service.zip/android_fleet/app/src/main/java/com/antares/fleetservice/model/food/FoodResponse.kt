package com.antares.fleetservice.model.food

import com.antares.fleetservice.model.BaseResponse
import com.google.gson.annotations.SerializedName

data class FoodResponse(
    @SerializedName("mechanic_lunch_list"   )   var     foodLunch       : ArrayList<FoodLunch> = arrayListOf(),
    @SerializedName("mechanic_lunch_detail" )   var     foodLunchDetail : FoodLunchDetail? = FoodLunchDetail()
) : BaseResponse()