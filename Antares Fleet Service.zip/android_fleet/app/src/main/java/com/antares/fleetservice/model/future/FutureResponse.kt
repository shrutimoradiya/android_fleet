package com.antares.fleetservice.model.future

import com.antares.fleetservice.model.BaseResponse
import com.google.gson.annotations.SerializedName

data class FutureResponse(
    @SerializedName("json"  )   var   leadData  : FutureJson? = null
) : BaseResponse()