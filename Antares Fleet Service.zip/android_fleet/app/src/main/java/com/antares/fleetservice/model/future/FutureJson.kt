package com.antares.fleetservice.model.future

import com.antares.fleetservice.model.travel.TravelDetailLead
import com.google.gson.annotations.SerializedName

data class FutureJson(
    @SerializedName("leads" )   var     leadsList   : ArrayList<TravelDetailLead?>? = null
)
