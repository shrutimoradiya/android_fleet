package com.antares.fleetservice.viewmodel

import android.text.TextUtils
import android.util.ArrayMap
import android.util.Patterns
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.MutableLiveData
import com.antares.fleetservice.R
import com.antares.fleetservice.utils.Constant
import com.antares.fleetservice.view.widget.dialog.ProgressDialog


class ForgetPasswordViewModel : BaseViewModel() {

    internal var isChanged = MutableLiveData<Boolean>()

    fun forgetPassword(context: AppCompatActivity, email: String?) {

        if (!isUserNameValid(email)) {
            Toast.makeText(
                context,
                context.resources.getString(R.string.invalid_username),
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        val dialog = ProgressDialog(context)
        dialog.show()

        if (email != null) {

            val map: ArrayMap<String?, Any?> = ArrayMap<String?, Any?>()
            map["created_from"] = Constant.createFrom
            map["email"] = email

            fleetRepository?.forgotPassword(map)?.observeForever {
                it?.let {
                    if (it.code == 200) {
                        isChanged.value = !(isChanged.value ?: false)
                    } else {
                        isChanged.value = false
                    }
                    Toast.makeText(context, it.msg, Toast.LENGTH_SHORT).show()
                    dialog.dismiss()
                }
            }
        }
    }

    private fun isUserNameValid(target: CharSequence?): Boolean {
        return !TextUtils.isEmpty(target) && target?.let {
            Patterns.EMAIL_ADDRESS.matcher(it).matches()
        } == true
    }
}
