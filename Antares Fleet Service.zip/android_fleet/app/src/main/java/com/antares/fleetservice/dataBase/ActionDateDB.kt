package com.antares.fleetservice.dataBase

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.antares.fleetservice.model.users.Users
import com.antares.fleetservice.utils.Constant

class ActionDateDB(context: Context?) : SQLiteOpenHelper(context, "ActionDate.db", null, 1) {

    // table name
    private val actionDate = "ActionDate"

    // row
    private val date: String = "date"

    override fun onCreate(db: SQLiteDatabase?) {
        db?.execSQL(
            "create table "
                    + actionDate + " ("
                    + date + " TEXT)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        println("oldVersion = $oldVersion | newVersion = $newVersion")
    }

    fun addData(data: String): Boolean {

        val db = writableDatabase
        val values = ContentValues()
        values.put(date, data)
        val result = db.insert(actionDate, null, values)
        db.close()

        return result != -1L
    }

    fun viewData(): ArrayList<String> {

        val cursor: Cursor = writableDatabase.rawQuery("select * from $actionDate", null)

        val arrayList = ArrayList<String>()

        if (cursor.count != 0) {
            while (cursor.moveToNext()) {
                arrayList.add(cursor.getString(0))
            }
        }

        return arrayList
    }

    fun deleteData(): Boolean {
        val db1 = writableDatabase
        val isDeleted = db1.delete(actionDate, "", arrayOf())
        db1.close()
        return isDeleted != 0
    }
}