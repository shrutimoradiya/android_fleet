package com.antares.fleetservice.viewmodel

import android.util.ArrayMap
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.antares.fleetservice.model.carList.CarResponse
import com.antares.fleetservice.model.carList.Cars
import com.antares.fleetservice.view.widget.dialog.ProgressDialog
import com.antares.fleetservice.viewCustomer.model.carList.CarsList

class AddPlate1ViewModel :BaseViewModel() {

    internal var carData = MutableLiveData<List<CarsList>>()


    fun getCarList(context: AppCompatActivity, map: ArrayMap<String?, Any?>) {
        val dialog = ProgressDialog(context)
        dialog.show()
        fleetRepository?.getCarList1(map)?.observeForever {
            it?.let {
                carData.value = it
                dialog.dismiss()
            }
        }
    }

    fun getCarSearchList(map: ArrayMap<String?, Any?>) {
        fleetRepository?.getCarList1(map)?.observeForever {
            it?.let {
                carData.value = it
            }
        }
    }
}