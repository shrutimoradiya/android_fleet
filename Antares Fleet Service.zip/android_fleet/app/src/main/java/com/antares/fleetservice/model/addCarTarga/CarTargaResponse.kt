package com.antares.fleetservice.model.addCarTarga

import com.antares.fleetservice.model.models.Models
import com.google.gson.annotations.SerializedName

data class CarTargaResponse(
    @SerializedName("code"             ) var code            : Int?                       = null,
    @SerializedName("car_detail"       ) var carDetail       : CarDetail?                 = CarDetail(),
    @SerializedName("versions"         ) var versions        : ArrayList<Versions>        = arrayListOf(),
    @SerializedName("motornet_version" ) var motornetVersion : ArrayList<MotornetVersion> = arrayListOf(),
    @SerializedName("models"           ) var models          : ArrayList<Models>          = arrayListOf()
)
