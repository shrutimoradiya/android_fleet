package com.antares.fleetservice.model.users

import com.google.gson.annotations.SerializedName

data class UserJson(
    @SerializedName("users" )   var     users   : ArrayList<Users> = arrayListOf()
)