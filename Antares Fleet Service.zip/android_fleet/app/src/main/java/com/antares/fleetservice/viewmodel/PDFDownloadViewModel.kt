package com.antares.fleetservice.viewmodel

import android.content.Context
import android.util.ArrayMap
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.MutableLiveData
import com.antares.fleetservice.model.CommonResponse
import com.antares.fleetservice.model.getCarDocument.CarDocumentJson
import com.antares.fleetservice.model.pinFileList.PinJson
import com.antares.fleetservice.view.widget.dialog.ProgressDialog

class PDFDownloadViewModel :BaseViewModel() {

    internal var homeData = MutableLiveData<CarDocumentJson>()
    internal var saveData = MutableLiveData<CommonResponse>()
    internal var pinData = MutableLiveData<PinJson>()


    fun getCarDocument(map: ArrayMap<String?, Any?>) {
        fleetRepository?.getCarDocument(map)?.observeForever {
            it?.let {
                homeData.value = it
            }
        }
    }

    fun saveNewCar(context: AppCompatActivity, map: ArrayMap<String?, Any?>) {
        val dialog = ProgressDialog(context)
        dialog.show()
        fleetRepository?.postCarDocument(map)?.observeForever {
            it?.let {
                dialog.dismiss()
                saveData.value = it
            }
        }
    }

    fun getPinDocumentList(context: Context, map: ArrayMap<String?, Any?>) {
        val dialog = android.app.ProgressDialog(context)
        dialog.show()
        fleetRepository?.getPin(map)?.observeForever {
            it?.let {
                pinData.value = it
                dialog.dismiss()
            }
        }
    }

}