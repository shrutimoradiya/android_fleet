package com.antares.fleetservice.model.mechanic

import com.antares.fleetservice.model.mechanic.event.DamagePhotos
import com.google.gson.annotations.SerializedName

data class FotoSaveResponse(
    @SerializedName("code"      ) var code     : Int?    = null,
    @SerializedName("msg"       ) var msg      : String? = null,
    @SerializedName("lead_file" ) var leadFile : DamagePhotos? = null
)
