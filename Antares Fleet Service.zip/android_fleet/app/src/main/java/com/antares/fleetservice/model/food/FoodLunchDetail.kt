package com.antares.fleetservice.model.food

import com.google.gson.annotations.SerializedName

data class FoodLunchDetail(
    @SerializedName("mobile_station_id" )   var     mobileStationId : String? = null,
    @SerializedName("date"              )   var     date            : String? = null,
    @SerializedName("from_time"         )   var     fromTime        : String? = null,
    @SerializedName("to_time"           )   var     toTime          : String? = null,
    @SerializedName("photo"             )   var     photo           : String? = null,
    @SerializedName("type"              )   var     type            : String? = null,
    @SerializedName("created_by"        )   var     createdBy       : Int? = null,
    @SerializedName("status"            )   var     status          : String? = null,
    @SerializedName("updated_at"        )   var     updatedAt       : String? = null,
    @SerializedName("created_at"        )   var     createdAt       : String? = null,
    @SerializedName("id"                )   var     id              : Int? = null
)