package com.antares.fleetservice.model.pinFileList

import com.google.gson.annotations.SerializedName

data class PinResponse (
    @SerializedName("code" ) var code : Int?  = null,
    @SerializedName("json" ) var json : PinJson? = PinJson()
)