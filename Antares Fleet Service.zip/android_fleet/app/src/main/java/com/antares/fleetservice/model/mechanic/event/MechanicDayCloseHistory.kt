package com.antares.fleetservice.model.mechanic.event

import com.google.gson.annotations.SerializedName

data class MechanicDayCloseHistory(

    @SerializedName("id"                ) var id              : Int?    = null,
    @SerializedName("date"              ) var date            : String? = null,
    @SerializedName("mobile_station_id" ) var mobileStationId : Int?    = null,
    @SerializedName("closed_by"         ) var closedBy        : Int?    = null,
    @SerializedName("created_from"      ) var createdFrom     : String? = null,
    @SerializedName("created_at"        ) var createdAt       : String? = null,
    @SerializedName("updated_at"        ) var updatedAt       : String? = null
)
