package com.antares.fleetservice.model.mechanic.event

import com.antares.fleetservice.model.MainCheckModel
import com.google.gson.annotations.SerializedName

data class MechanicSubCategories(
    @SerializedName("id"            ) var id           : Int?                    = null,
    @SerializedName("name"          ) var name         : String?                 = null,
    @SerializedName("order_by"      ) var orderBy      : String?                 = null,
    @SerializedName("parent_id"     ) var parentId     : Int?                    = null,
    @SerializedName("test_drive_id" ) var testDriveId  : String?                 = null,
    @SerializedName("image"         ) var image        : String?                 = null,
    @SerializedName("auto_parti_id" ) var autoPartiId  : String?                 = null,
    @SerializedName("category_link" ) var categoryLink : String?                 = null,
    @SerializedName("category_type" ) var categoryType : String?                 = null,
    @SerializedName("option1"       ) var option1      : String?                 = null,
    @SerializedName("option2"       ) var option2      : String?                 = null,
    @SerializedName("option3"       ) var option3      : String?                 = null,
    @SerializedName("option4"       ) var option4      : String?                 = null,
    @SerializedName("option5"       ) var option5      : String?                 = null,
    @SerializedName("option6"       ) var option6      : String?                 = null,
    @SerializedName("option7"       ) var option7      : String?                 = null,
    @SerializedName("option8"       ) var option8      : String?                 = null,
    @SerializedName("option9"       ) var option9      : String?                 = null,
    @SerializedName("deleted"       ) var deleted      : String?                 = null,
    @SerializedName("is_photo"      ) var isPhoto      : String?                 = null,
    @SerializedName("created_at"    ) var createdAt    : String?                 = null,
    @SerializedName("updated_at"    ) var updatedAt    : String?                 = null,
    @SerializedName("main_photo"    ) var mainPhoto    : MainPhoto?              = MainPhoto(),
    @SerializedName("damage_photos" ) var damagePhotos : ArrayList<DamagePhotos> = arrayListOf(),
    @SerializedName("damage_options" ) var damageOptions : ArrayList<String>? = null,
                                      var listCheck          : ArrayList<MainCheckModel> = arrayListOf(),
)
