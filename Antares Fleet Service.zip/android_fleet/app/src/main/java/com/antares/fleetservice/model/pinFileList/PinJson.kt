package com.antares.fleetservice.model.pinFileList

import com.google.gson.annotations.SerializedName

data class PinJson(
    @SerializedName("lead"  ) var lead  : PinLead?            = PinLead(),
    @SerializedName("files" ) var files : ArrayList<PinFiles> = arrayListOf()
)
