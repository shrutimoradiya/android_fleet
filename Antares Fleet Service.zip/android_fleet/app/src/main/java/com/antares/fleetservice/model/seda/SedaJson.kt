package com.antares.fleetservice.model.seda

import com.google.gson.annotations.SerializedName

data class SedaJson(
    @SerializedName("office_locations"  )   var     officeLocations : ArrayList<OfficeLocations> = arrayListOf()
)