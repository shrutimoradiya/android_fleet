package com.antares.fleetservice.viewmodel

import android.util.ArrayMap
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.MutableLiveData
import com.antares.fleetservice.model.CommonResponse
import com.antares.fleetservice.model.carList.Cars
import com.antares.fleetservice.view.widget.dialog.ProgressDialog

class RicercaTargheViewModel : BaseViewModel() {

    internal var carData = MutableLiveData<List<Cars>>()
    internal var carData1 = MutableLiveData<List<Cars>>()
    internal var saveData = MutableLiveData<CommonResponse>()


    fun getCarList(context: AppCompatActivity, map: ArrayMap<String?, Any?>) {
        val dialog = ProgressDialog(context)
        dialog.show()
        fleetRepository?.getCarLocationChangeList(map)?.observeForever {
            it?.let {
                carData.value = it
                dialog.dismiss()
            }
        }
    }

    fun getCarSearchList(map: ArrayMap<String?, Any?>) {
        fleetRepository?.getCarLocationChangeList(map)?.observeForever {
            it?.let {
                carData1.value = it
            }
        }
    }

    fun saveNewCar(context: AppCompatActivity, map: ArrayMap<String?, Any?>) {
        val dialog = ProgressDialog(context)
        dialog.show()
        fleetRepository?.saveChangeCarLocation(map)?.observeForever {
            it?.let {
                dialog.dismiss()
                saveData.value = it
            }
        }
    }
}