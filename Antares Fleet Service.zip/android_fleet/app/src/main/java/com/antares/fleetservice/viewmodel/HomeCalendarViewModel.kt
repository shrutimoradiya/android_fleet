package com.antares.fleetservice.viewmodel

import android.content.Intent
import android.util.ArrayMap
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.MutableLiveData
import com.antares.fleetservice.BuildConfig
import com.antares.fleetservice.dataBase.ContactUsDB
import com.antares.fleetservice.dataBase.MapEventDB
import com.antares.fleetservice.dataBase.MechanicEventDB
import com.antares.fleetservice.dataBase.PresetDB
import com.antares.fleetservice.model.PDFResponse
import com.antares.fleetservice.model.event.CalendarEvent
import com.antares.fleetservice.model.mechanic.home.MechanicHomeJson
import com.antares.fleetservice.utils.Constant
import com.antares.fleetservice.view.activity.UpdateActivity
import com.antares.fleetservice.view.widget.dialog.ProgressDialog

class HomeCalendarViewModel : BaseTravelViewModel() {

    internal var homeData = MutableLiveData<MechanicHomeJson>()
    internal var calendarEventData = MutableLiveData<List<CalendarEvent>>()
    internal var pdfLink = MutableLiveData<PDFResponse>()
    internal var pdfDownloadLink = MutableLiveData<PDFResponse>()

    fun getCalenderEvent(map: ArrayMap<String?, Any?>) {
        fleetRepository?.getCalendarEvent(map)?.observeForever {
            it?.let { it1 ->
                calendarEventData.value = it1
            }
        }
    }

    fun getContactList(context: AppCompatActivity) {

        val dialog = ProgressDialog(context)
        dialog.show()

        val map: ArrayMap<String?, Any?> = ArrayMap<String?, Any?>()
        map["created_from"] = Constant.createFrom
        map["type"] = "users"
        map["role"] = "admin"
        map["is_main_user"] = "Y"
        map["user_type"] = "Customer"

        fleetRepository?.getUserList(map)?.observeForever {
            it?.let {

                val myDbh = ContactUsDB(context)

                myDbh.deleteData()
                for (temp in it) {
                    myDbh.addData(temp)
                }

            }
            dialog.dismiss()

        }
    }

    fun getPresetList(context: AppCompatActivity) {

        val dialog = ProgressDialog(context)
        dialog.show()

        fleetRepository?.getPresetList()?.observeForever {
            it?.let {

                val myDbh = PresetDB(context)

                myDbh.deleteData()
                for (temp in it.presetCategories) {
                    myDbh.addData(temp)
                }

            }
            dialog.dismiss()
        }
    }

    fun saveSubEventData(
        arrId: ArrayList<Int>,
        context: AppCompatActivity,
        version: String?,
        apkUrl: String?,
        date: String?
    ) {

        val myDbh = MechanicEventDB(context)

        if (arrId.size != 0) {
            for (temp in arrId) {
                val dataTemp = myDbh.viewData(temp)
                if (dataTemp.eventDetail == null) {
                    val dialog = ProgressDialog(context)
                    dialog.show()

                    val map: ArrayMap<String?, Any?> = ArrayMap<String?, Any?>()
                    map["created_from"] = Constant.createFrom
                    map["event_id"] = temp
                    map["date"] = date

                    fleetRepository?.getMechanicEventDetail(map)?.observeForever {
                        dialog.dismiss()
                        it?.let {

                            val dataTemp2 = myDbh.viewData(temp)
                            if (dataTemp2.eventDetail != null) {
                                if (myDbh.deleteData(temp)) {
                                    myDbh.addData(it)
                                }
                            } else {
                                myDbh.addData(it)
                            }

                            if (version != BuildConfig.VERSION_NAME) {
                                if (Constant.getBool(context, Constant.isUpdate)) {
                                    val intent = Intent(context, UpdateActivity::class.java)
                                    intent.putExtra(Constant.apkUrl, apkUrl)
                                    context.startActivity(intent)
                                    context.finish()
                                }
                            }
                        }
                    }
                } else {
                    if (version != BuildConfig.VERSION_NAME) {
                        if (Constant.getBool(context, Constant.isUpdate)) {
                            val intent = Intent(context, UpdateActivity::class.java)
                            intent.putExtra(Constant.apkUrl, apkUrl)
                            context.startActivity(intent)
                            context.finish()
                        }
                    }
                }
            }
        } else {
            if (version != BuildConfig.VERSION_NAME) {
                if (Constant.getBool(context, Constant.isUpdate)) {
                    val intent = Intent(context, UpdateActivity::class.java)
                    intent.putExtra(Constant.apkUrl, apkUrl)
                    context.startActivity(intent)
                    context.finish()
                }
            }
        }
    }

    fun saveMapData(
        context: AppCompatActivity,
        arrId: ArrayList<Int>,
        date: String,
        mobileStationId: Int,
        isTravelChange: Boolean
    ) {

        val myDbh = MapEventDB(context)

        for (temp in arrId) {
            val dataTemp = myDbh.viewData(temp)
            if (dataTemp.travelEvent == null || isTravelChange) {
                val dialog = ProgressDialog(context)
                dialog.show()

                val map: ArrayMap<String?, Any?> = ArrayMap<String?, Any?>()
                map["created_from"] = Constant.createFrom
                map["event_id"] = temp
                map["date"] = date
                map["mobile_station_id"] = mobileStationId

                fleetRepository?.getTravelDetail(map)?.observeForever {
                    dialog.dismiss()
                    it?.let {
                        it.eventId = it.travelEvent?.id
                        myDbh.addData(it)
                    }
                }
            }
        }
    }

    fun getCalenderHomeDetail(login_id: Int, mobile_station_id: Int) {
        val start = Constant.fullDateFormat(cal)

        val map: ArrayMap<String?, Any?> = ArrayMap<String?, Any?>()
        map["created_from"] = Constant.createFrom
        map["start"] = start
        map["end"] = start
        map["ids"] = login_id
        map["mobile_station_id"] = mobile_station_id

        fleetRepository?.getCalendarHomeDetail(map)
            ?.observeForever {
                it?.let {
                    homeData.value = it
                }

            }
    }

    fun getPDF(map: ArrayMap<String?, Any?>) {
        fleetRepository?.getPDF(map)
            ?.observeForever {
                it?.let {
                    pdfLink.value = it
                } ?: run {
                    pdfLink.value = null
                }

            }
    }

    fun getPDFDownload(context: AppCompatActivity,map: ArrayMap<String?, Any?>) {
        val dialog = ProgressDialog(context)
        dialog.show()
        fleetRepository?.getPDFDownload(map)
            ?.observeForever {
                dialog.dismiss()
                it?.let {
                    pdfDownloadLink.value = it
                } ?: run {
                    pdfDownloadLink.value = null
                }

            }
    }

    fun deleteSubEvent(
        context: AppCompatActivity,
        login_id: Int,
        mobile_station_id: Int,
        map: ArrayMap<String?, Any?>
    ) {
        val dialog = ProgressDialog(context)
        dialog.show()
        fleetRepository?.deleteRecord(map)?.observeForever {
            Toast.makeText(context, it?.msg, Toast.LENGTH_SHORT).show()
            dialog.dismiss()
            getCalenderHomeDetail(login_id, mobile_station_id)
        }
    }

    fun lettoClick(map: ArrayMap<String?, Any?>) {
        fleetRepository?.lettoClick(map)
    }

}
