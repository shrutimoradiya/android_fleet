package com.antares.fleetservice.model.mechanicAttendance

import com.google.gson.annotations.SerializedName

data class MobileStations(
    @SerializedName("id") var id: Int? = null,
    @SerializedName("car_id") var carId: String? = null,
    @SerializedName("display_id") var displayId: String? = null,
    @SerializedName("name") var name: String? = null,
    @SerializedName("address") var address: String? = null,
    @SerializedName("state") var state: String? = null,
    @SerializedName("postal_code") var postalCode: String? = null,
    @SerializedName("lat") var lat: String? = null,
    @SerializedName("lon") var lon: String? = null,
    @SerializedName("customer_id") var customerId: String? = null,
    @SerializedName("location_type") var locationType: String? = null,
    @SerializedName("office_location_id") var officeLocationId: Int? = null,
    @SerializedName("parent_id") var parentId: Int? = null,
    @SerializedName("office_icon") var officeIcon: String? = null,
    @SerializedName("calendar_color") var calendarColor: String? = null,
    @SerializedName("partner_name") var partnerName: String? = null,
    @SerializedName("deleted") var deleted: String? = null,
    @SerializedName("created_at") var createdAt: String? = null,
    @SerializedName("updated_at") var updatedAt: String? = null,
    @SerializedName("first_name") var firstName: String? = null,
    @SerializedName("last_name") var lastName: String? = null,
    @SerializedName("business_name") var businessName: String? = null,
    @SerializedName("latitude") var latitude: String? = null,
    @SerializedName("longitude") var longitude: String? = null,
    @SerializedName("number_plate") var numberPlate: String? = null,
    @SerializedName("make_name") var makeName: String? = null,
    @SerializedName("model_name") var modelName: String? = null,
    @SerializedName("mechanic_name") var mechanicName: String? = null,
    @SerializedName("parent_location") var parentLocation: String? = null
)