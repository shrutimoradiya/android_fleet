package com.antares.fleetservice.model.lead

import com.antares.fleetservice.model.BaseResponse
import com.google.gson.annotations.SerializedName

data class LeadResponse(
    @SerializedName("json"  )   var     leadData    : LeadJson? = null
) : BaseResponse()