package com.antares.fleetservice.viewmodel

import android.util.ArrayMap
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.MutableLiveData
import com.antares.fleetservice.model.CommonResponse
import com.antares.fleetservice.model.carList.Cars
import com.antares.fleetservice.model.customerWorkPlan.CustomerWorkPlanResponse
import com.antares.fleetservice.model.customerWorkPlan.Locations
import com.antares.fleetservice.model.map.DirectionResponses
import com.antares.fleetservice.service.MapRepository
import com.antares.fleetservice.view.widget.dialog.ProgressDialog

class TravelDetailViewModel : BaseTravelViewModel() {

    private var mapRepository = MapRepository.getInstance()
    internal var directionData = MutableLiveData<DirectionResponses>()
    internal var carData = MutableLiveData<List<Cars>>()
    internal var carAddStatus = MutableLiveData<CommonResponse>()
    internal var carAddStatus2 = MutableLiveData<CommonResponse>()
    internal var carLocation = MutableLiveData<CustomerWorkPlanResponse>()

    fun getTravelDetail(map: ArrayMap<String?, Any?>) {
        fleetRepository?.getTravelDetail(map)?.observeForever {
            it?.let {
                travelData.value = it
            }
        }
    }

    fun getCarList(context: AppCompatActivity, map: ArrayMap<String?, Any?>) {
        val dialog = ProgressDialog(context)
        dialog.show()
        fleetRepository?.getCarList(map)?.observeForever {
            it?.let {
                carData.value = it
                dialog.dismiss()
            }
        }
    }

    fun customerWorkPlanList(context: AppCompatActivity, map: ArrayMap<String?, Any?>) {
        val dialog = ProgressDialog(context)
        dialog.show()
        fleetRepository?.customerWorkPlanList(map)?.observeForever {
            it?.let {
                carLocation.value = it
                dialog.dismiss()
            }
        }
    }

    fun changeCarLocation(context: AppCompatActivity, map: ArrayMap<String?, Any?>) {
        val dialog = ProgressDialog(context)
        dialog.show()
        fleetRepository?.changeCarLocation(map)?.observeForever {
            it?.let {
                carAddStatus2.value = it
                dialog.dismiss()
            }
        }
    }

    fun addCar(context: AppCompatActivity, map: ArrayMap<String?, Any?>) {
        val dialog = ProgressDialog(context)
        dialog.show()
        fleetRepository?.addCar(map)?.observeForever {
            it?.let {
                carAddStatus.value = it
                Toast.makeText(context, it.msg, Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
        }
    }

    fun getCarSearchList(map: ArrayMap<String?, Any?>) {
        fleetRepository?.getCarList(map)?.observeForever {
            it?.let {
                carData.value = it
            }
        }
    }

    fun getDirection(origin: String, destination: String, apiKey: String) {
        mapRepository?.getDirection(
            origin = origin,
            destination = destination,
            apiKey = apiKey
        )?.observeForever {
            it?.let {
                directionData.value = it
            }
        }
    }

}
