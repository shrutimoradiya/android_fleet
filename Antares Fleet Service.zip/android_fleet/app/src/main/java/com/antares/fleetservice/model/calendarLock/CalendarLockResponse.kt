package com.antares.fleetservice.model.calendarLock

import com.google.gson.annotations.SerializedName

data class CalendarLockResponse(
    @SerializedName("code"  )   var     code    : Int? = null,
    @SerializedName("json"  )   var     json    : CalendarLockJson? = CalendarLockJson()
)