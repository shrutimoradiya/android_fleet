package com.antares.fleetservice.viewmodel

import android.util.ArrayMap
import androidx.lifecycle.MutableLiveData
import com.antares.fleetservice.model.calendarLock.CalendarLockEvent
import com.antares.fleetservice.utils.Constant

class CalendarLockViewModel : BaseViewModel() {

    internal var lockData = MutableLiveData<ArrayList<CalendarLockEvent>>()

    fun getLockData(mobile_station_id: Int, date: String) {

        val map: ArrayMap<String?, Any?> = ArrayMap<String?, Any?>()
        map["created_from"] = Constant.createFrom
        map["date"] = date
        map["mobile_station_id"] = mobile_station_id

        fleetRepository?.getLockData(map)?.observeForever { it ->
            it?.let { it1 ->
                it1.json?.events?.let {
                    lockData.value = it
                }
            }
        }
    }

    fun postLockData(map: ArrayMap<String?, Any?>?, mobile_station_id: Int, date: String) {
        fleetRepository?.postLockData(map = map)?.observeForever {
            getLockData(
                mobile_station_id,
                date
            )
        }
    }
}
