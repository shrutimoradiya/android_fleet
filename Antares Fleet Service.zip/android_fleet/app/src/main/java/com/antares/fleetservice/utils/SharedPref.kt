package com.antares.fleetservice.utils

import android.content.Context
import android.content.SharedPreferences

class SharedPref(context: Context) {
    private val context: Context
    private val sharedPreferences: SharedPreferences
    private val editor: SharedPreferences.Editor

    var isLogin: Boolean
        get() = sharedPreferences.getBoolean("isLogin", false)
        set(isLogin) {
            isLogin.let {
                editor.putBoolean("isLogin", it)
                editor.apply()
            }
        }

    var isCustomerLogin: Boolean
        get() = sharedPreferences.getBoolean("isCustomerLogin", false)
        set(isLogin) {
            isLogin.let {
                editor.putBoolean("isCustomerLogin", it)
                editor.apply()
            }
        }

    var isFirstTimeLaunch: Boolean
        get() = sharedPreferences.getBoolean("IsFirstTimeLaunch", true)
        set(IsFirstTimeLaunch) {
            IsFirstTimeLaunch.let {
                editor.putBoolean("IsFirstTimeLaunch", it)
                editor.apply()
            }
        }

    var userInfo: String?
        get() = sharedPreferences.getString("userInfo", "")
        set(userInfo) {
            userInfo.let {
                editor.putString("userInfo", it)
                editor.apply()
            }
        }

    var token: String?
        get() = sharedPreferences.getString("token", "")
        set(userInfo) {
            userInfo.let {
                editor.putString("token", it)
                editor.apply()
            }
        }

    init {
        this.context = context
        sharedPreferences =
            context.getSharedPreferences("fleet_service_settings", Context.MODE_PRIVATE)
        editor = sharedPreferences.edit()
    }
}
