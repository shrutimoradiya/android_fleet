package com.antares.fleetservice.viewmodel

import android.util.ArrayMap
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.MutableLiveData
import com.antares.fleetservice.model.CommonResponse
import com.antares.fleetservice.model.addCarTarga.CarTargaResponse
import com.antares.fleetservice.model.getCarDetail.CarDetailJson
import com.antares.fleetservice.model.getCarDetail.CarDetailVersionResponse
import com.antares.fleetservice.model.getCarDetail.CarYearModel
import com.antares.fleetservice.model.models.ModelsJson
import com.antares.fleetservice.model.seda.OfficeLocations
import com.antares.fleetservice.model.seda.SedaJson
import com.antares.fleetservice.model.seda.SedaResponse
import com.antares.fleetservice.view.widget.dialog.ProgressDialog

class AddCarViewModel : BaseViewModel() {

    internal var carDetailData = MutableLiveData<CarDetailJson>()
    internal var sedaData = MutableLiveData<SedaJson>()
    internal var sedaData1 = MutableLiveData<CarTargaResponse>()
    internal var modelData = MutableLiveData<ModelsJson>()
    internal var saveData = MutableLiveData<CommonResponse>()
    internal var versionData = MutableLiveData<CarDetailVersionResponse>()



    fun getCarDetail(context: AppCompatActivity, map: ArrayMap<String?, Any?>) {
        val dialog = ProgressDialog(context)
        dialog.show()
        fleetRepository?.getCarDetail(map)?.observeForever {
            it?.let {
                dialog.dismiss()
                carDetailData.value = it
            }
        }
    }

    fun getSedaDetail(context: AppCompatActivity, map: ArrayMap<String?, Any?>) {
        val dialog = ProgressDialog(context)
        dialog.show()
        fleetRepository?.getSedaDetail(map)
            ?.observeForever {
                it?.let {
                    dialog.dismiss()
                    sedaData.value = it
                }
            }
    }

    fun getSedaDetail1(context: AppCompatActivity, map: ArrayMap<String?, Any?>) {
        val dialog = ProgressDialog(context)
        dialog.show()
        fleetRepository?.getCarTargaDetail(map)
            ?.observeForever {
                it?.let {
                    dialog.dismiss()
                    sedaData1.value = it
                }
            }
    }

    fun getVersionDetail(context: AppCompatActivity, map: ArrayMap<String?, Any?>) {
        val dialog = ProgressDialog(context)
        dialog.show()
        fleetRepository?.getCarVersionDetail(map)
            ?.observeForever {
                it?.let {
                    dialog.dismiss()
                   versionData.value= it
                }
            }
    }
//
//    fun getModelDetail(context: AppCompatActivity, map: ArrayMap<String?, Any?>) {
//        val dialog = ProgressDialog(context)
//        dialog.show()
//        fleetRepository?.getModelDetail(map)?.observeForever {
//            it?.let {
//                dialog.dismiss()
//                modelData.value = it
//            }
//        }
//    }



    fun saveNewCar(context: AppCompatActivity, map: ArrayMap<String?, Any?>) {
        val dialog = ProgressDialog(context)
        dialog.show()
        fleetRepository?.saveNewCar(map)?.observeForever {
            it?.let {
                dialog.dismiss()
                saveData.value = it
            }
        }
    }




}
