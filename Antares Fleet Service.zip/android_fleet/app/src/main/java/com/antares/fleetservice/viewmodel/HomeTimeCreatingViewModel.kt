package com.antares.fleetservice.viewmodel

import android.util.ArrayMap
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.MutableLiveData
import com.antares.fleetservice.R
import com.antares.fleetservice.model.BaseResponsePreset
import com.antares.fleetservice.model.lead.LeadCar
import com.antares.fleetservice.model.presentProduct.PresentProductResponse
import com.antares.fleetservice.model.searchProduct.SearchProduct
import com.antares.fleetservice.model.travel.TravelDetailLead
import com.antares.fleetservice.utils.Constant
import com.antares.fleetservice.view.widget.dialog.AlertDialog
import com.antares.fleetservice.view.widget.dialog.ProgressDialog
import com.google.gson.Gson

class HomeTimeCreatingViewModel : BaseViewModel() {

    internal var carsList = MutableLiveData<ArrayList<LeadCar?>>()
    internal var productsList = MutableLiveData<ArrayList<SearchProduct>>()
    internal var futureLeadsList = MutableLiveData<ArrayList<TravelDetailLead?>?>()
    private var dataChange = MutableLiveData<Boolean>()
    internal var presentProductList = MutableLiveData<PresentProductResponse>()
    internal var addStatus = MutableLiveData<BaseResponsePreset>()


    fun getCarList(map: ArrayMap<String?, Any?>) {
        fleetRepository?.getCarList2(map)?.observeForever {
            it?.let {
                carsList.value = it
            }
        }
    }

    fun getProductsList(map: ArrayMap<String?, Any?>) {
        fleetRepository?.getProductsList(map)?.observeForever {
            it?.let {
                presentProductList.value = it
            }
        }
    }

    fun searchProductsList(map: ArrayMap<String?, Any?>) {
        fleetRepository?.searchProductsList(map)?.observeForever {
            it?.let {
                productsList.value = it.json?.products
            }
        }
    }

    fun deleteWorkSteps(context: AppCompatActivity, date: String, map: ArrayMap<String?, Any?>) {
        val dialog = ProgressDialog(context)
        dialog.show()
        fleetRepository?.deleteRecord(map)?.observeForever {
            Toast.makeText(context, it?.msg, Toast.LENGTH_SHORT).show()
            dialog.dismiss()
            getFutureData(date)
        }
    }

    fun postLeadData(
        context: AppCompatActivity,
        map: ArrayMap<String?, Any?>,
    ) {
        val dialog = ProgressDialog(context)
        dialog.show()
        fleetRepository?.addFutureCarOffline(map = map)?.observeForever {
            dialog.dismiss()
            Log.e("postLeadData: ", Gson().toJson(it))

            if (it?.code == 200) {
                context.onBackPressed()
                Toast.makeText(context, it.msg, Toast.LENGTH_SHORT).show()
            } else {
                it?.msg?.let { it1 ->
                    AlertDialog(
                        context,
                        context.getString(R.string.oops),
                        it1,
                        false,
                        object : AlertDialog.OnOptionSelected {
                            override fun onConfirmClick() {}
                            override fun onAggiungiMezzoClick() {}
                        }
                    ).show()
                }
            }
        }
    }

    fun getFutureData(date: String) {

        val map: ArrayMap<String?, Any?> = ArrayMap<String?, Any?>()
        map["created_from"] = Constant.createFrom
        map["date"] = date

        fleetRepository?.getFutureLeads(map)?.observeForever {
            futureLeadsList.value = it
        }
    }

    fun postProductsList(context: AppCompatActivity, map: ArrayMap<String?, Any?>) {
        val dialog = ProgressDialog(context)
        dialog.show()
        fleetRepository?.postProductsList(map)?.observeForever {
            Toast.makeText(context, it!!.msg, Toast.LENGTH_SHORT).show()
            dialog.dismiss()
            dataChange.value = !(dataChange.value ?: false)
            addStatus.value = it
        }
    }

    fun addSearchData(
        context: AppCompatActivity,
        sku: String,
        title: String
    ) {
        if (sku.isEmpty()) {
            Toast.makeText(
                context,
                context.resources.getString(R.string.no_data_found),
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        if (title.isEmpty()) {
            Toast.makeText(
                context,
                context.resources.getString(R.string.no_data_found),
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        val map: ArrayMap<String?, Any?> = ArrayMap<String?, Any?>()
        map["created_from"] = Constant.createFrom
        map["sub_category_id"] = 917
        map["sku"] = sku
        map["title"] = title

        fleetRepository?.addSearchData(map)?.observeForever {
            dataChange.value = !(dataChange.value ?: false)
            context.onBackPressed()
        }
    }

}
