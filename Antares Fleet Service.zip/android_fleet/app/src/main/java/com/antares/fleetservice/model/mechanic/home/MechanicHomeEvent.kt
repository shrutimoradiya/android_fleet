package com.antares.fleetservice.model.mechanic.home

import com.google.gson.annotations.SerializedName

data class MechanicHomeEvent(
    @SerializedName("detail"    )   var   detail    : MechanicHomeEventDetail? = null,
                                    var   isDayClose: Boolean = false


)
