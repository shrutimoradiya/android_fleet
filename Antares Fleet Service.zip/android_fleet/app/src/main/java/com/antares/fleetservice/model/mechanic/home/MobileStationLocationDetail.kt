package com.antares.fleetservice.model.mechanic.home

import com.google.gson.annotations.SerializedName

data class MobileStationLocationDetail(
    @SerializedName("id"                )   var     id              : Int? = null,
    @SerializedName("car_id"            )   var     carId           : Int? = null,
    @SerializedName("display_id"        )   var     displayId       : String? = null,
    @SerializedName("name"              )   var     name            : String? = null,
    @SerializedName("address"           )   var     address         : String? = null,
    @SerializedName("state"             )   var     state           : String? = null,
    @SerializedName("postal_code"       )   var     postalCode      : String? = null,
    @SerializedName("lat"               )   var     lat             : Double? = null,
    @SerializedName("lon"               )   var     lon             : Double? = null,
    @SerializedName("customer_id"       )   var     customerId      : String? = null,
    @SerializedName("location_type"     )   var     locationType    : String? = null,
    @SerializedName("parent_id"         )   var     parentId        : Int? = null,
    @SerializedName("office_icon"       )   var     officeIcon      : String? = null,
    @SerializedName("calendar_color"    )   var     calendarColor   : String? = null,
    @SerializedName("partner_name"      )   var     partnerName     : String? = null,
    @SerializedName("deleted"           )   var     deleted         : String? = null,
    @SerializedName("created_at"        )   var     createdAt       : String? = null,
    @SerializedName("updated_at"        )   var     updatedAt       : String? = null,
    @SerializedName("latitude"          )   var     latitude        : Double? = null,
    @SerializedName("longitude"         )   var     longitude       : Double? = null,
    @SerializedName("mslid"             )   var     mslid           : Int? = null
)
