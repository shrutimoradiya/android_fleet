package com.antares.fleetservice.dataBase

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.antares.fleetservice.model.ApiCallModel
import com.antares.fleetservice.utils.Constant

class PostCallApiDB(context: Context?) : SQLiteOpenHelper(context, "PostCallApiDB.db", null, 1) {

    // table name
    private val postCall = "PostCallApi"

    // row
    private val id: String = "id"
    private val api: String = "api"
    private val map: String = "map"
    private val leadId: String = "leadId"
    private val presetCategoryId: String = "presetCategoryId"

    override fun onCreate(db: SQLiteDatabase?) {
        db?.execSQL(
            "create table "
                    + postCall + " ("
                    + id + " TEXT, "
                    + api + " TEXT, "
                    + map + " TEXT, "
                    + leadId + " TEXT, "
                    + presetCategoryId + " TEXT) "
        )
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        println("oldVersion = $oldVersion | newVersion = $newVersion")
    }

    fun addData(
        context: Context,
        apiData: String,
        mapData: String,
        leadIdData: Int,
        presetCategoryIdData: Int
    ): Boolean {

        val db = writableDatabase
        val values = ContentValues()

        if (Constant.getData(context, Constant.SAVE_ID) == null) {
            Constant.saveData(context, Constant.SAVE_ID, 0)
        }

        Constant.saveData(
            context,
            Constant.SAVE_ID,
            (Constant.getData(context, Constant.SAVE_ID) + 1)
        )

        values.put(id, Constant.getData(context, Constant.SAVE_ID))
        values.put(api, apiData)
        values.put(map, mapData)
        values.put(leadId, leadIdData)
        values.put(presetCategoryId, presetCategoryIdData)

        val result = db.insert(postCall, null, values)
        if (db.isOpen) {
            db.close()
        }
        return result != -1L
    }

    fun viewData(): ArrayList<ApiCallModel> {

        val cursor: Cursor = writableDatabase.rawQuery(
            "select * from $postCall", null
        )

        val data = ArrayList<ApiCallModel>()

        if (cursor.count != 0) {
            while (cursor.moveToNext()) {

                val temp = ApiCallModel()

                temp.id = cursor.getInt(0)
                temp.api = cursor.getString(1)
                temp.map = cursor.getString(2)
                temp.leadId = cursor.getInt(3)
                temp.presetCategoryId = cursor.getInt(4)

                data.add(temp)
            }
        }

        cursor.close()

        return data
    }

    fun deleteData(idTemp: Int): Boolean {

        val db = writableDatabase

        val isDeleted = db.delete(
            postCall,
            "$id= ? \n", arrayOf(idTemp.toString())
        )
        db.close()
        return isDeleted != 0
    }
}