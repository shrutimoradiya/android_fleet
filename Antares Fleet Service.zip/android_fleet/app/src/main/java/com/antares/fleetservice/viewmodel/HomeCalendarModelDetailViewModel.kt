package com.antares.fleetservice.viewmodel

import android.content.Intent
import android.os.Looper
import android.util.ArrayMap
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.antares.fleetservice.R
import com.antares.fleetservice.model.CommonResponse
import com.antares.fleetservice.model.futureLead.FutureLeadJson
import com.antares.fleetservice.model.mechanic.FotoSaveResponse
import com.antares.fleetservice.model.mechanic.event.MechanicEventJson
import com.antares.fleetservice.utils.Constant
import com.antares.fleetservice.view.activity.LoginActivity
import com.antares.fleetservice.view.activity.MainActivity
import com.antares.fleetservice.view.activity.WelcomeActivity
import com.antares.fleetservice.view.fragment.FragmentCalendar
import com.antares.fleetservice.view.widget.dialog.ProgressDialog
import com.antares.fleetservice.viewCustomer.activity.MainCustomerActivity
import java.util.logging.Handler

class HomeCalendarModelDetailViewModel : BaseTravelViewModel() {

    internal var mechanicEventData = MutableLiveData<MechanicEventJson>()
    internal var mechanicFutureEventData = MutableLiveData<FutureLeadJson>()
    internal var postWorkChanged = MutableLiveData<Int>()
    internal var postWorkChanged2 = MutableLiveData<Int>()


    fun getCalenderModelEventDetail(
        context: AppCompatActivity,
        event_id: Int,
        date: String,
        isProgress: Boolean
    ) {
        val dialog = ProgressDialog(context)
        if (isProgress) {
            dialog.show()
        }

        val map: ArrayMap<String?, Any?> = ArrayMap<String?, Any?>()
        map["created_from"] = Constant.createFrom
        map["event_id"] = event_id
        map["date"] = date

        fleetRepository?.getMechanicEventDetail(map)?.observeForever {
            dialog.dismiss()
            it?.let {
                mechanicEventData.value = it
            }
        }
    }

    fun getTimeModelEventDetail(context: AppCompatActivity, lead_id: Int) {
        val dialog = ProgressDialog(context)
        dialog.show()

        val map: ArrayMap<String?, Any?> = ArrayMap<String?, Any?>()
        map["created_from"] = Constant.createFrom
        map["lead_id"] = lead_id

        fleetRepository?.getTimeMechanicEventDetail(map)?.observeForever {
            dialog.dismiss()
            it?.let {
                mechanicFutureEventData.value = it
            }
        }
    }

    fun saveKM(context: AppCompatActivity, map: ArrayMap<String?, Any?>) {
        val dialog = ProgressDialog(context)
        dialog.show()

        fleetRepository?.postWorkReportEnterKmMap(map = map)?.observeForever { it ->
            dialog.dismiss()
            it?.let {
                postWorkChanged.value = it.code
            }
        }
    }

    fun postPresetClose(
        context: AppCompatActivity,
        event_id: Int,
        date: String,
        map: ArrayMap<String?, Any?>
    ) {
        val dialog = ProgressDialog(context)
        dialog.show()
        fleetRepository?.postPresetClose(map)?.observeForever {
            dialog.dismiss()
            it?.let {
                postWorkChanged.value = it.code
                Toast.makeText(context, it.msg, Toast.LENGTH_SHORT).show()
            }
            getCalenderModelEventDetail(context, event_id, date, true)
        }
    }


    fun checkAllData(
        context: AppCompatActivity,
        map: ArrayMap<String?, Any?>?,
        event_id: Int,
        date: String
    ) {
        val dialogProgress = ProgressDialog(context)
        dialogProgress.show()

        fleetRepository?.checkAllData(map)?.observeForever {

            it?.let { it1 ->
                postWorkChanged.value = it1.code

                val map1: ArrayMap<String?, Any?> = ArrayMap<String?, Any?>()
                map1["created_from"] = Constant.createFrom
                map1["event_id"] = event_id
                map1["date"] = date

                fleetRepository?.getMechanicEventDetail(map1)?.observeForever { it2 ->
                    dialogProgress.dismiss()
                    it2?.let { it3 ->
                        mechanicEventData.value = it3
                    }
                }
            }
        }
    }

    fun postReportImagesMap(
        context: AppCompatActivity,
        event_id: Int,
        date: String,
        map: ArrayMap<String?, Any?>
    ) {
        postWorkChanged.value = 0
        val dialog = ProgressDialog(context)
        dialog.show()

        fleetRepository?.postReportImagesMap(map = map)?.observeForever { it ->
            dialog.dismiss()
            it?.let {
                postWorkChanged.value = it.code
                getCalenderModelEventDetail(context, event_id, date, true)
            }
        }
    }

    fun saveFoto(
        context: AppCompatActivity, map: ArrayMap<String?, Any?>, event_id: Int,
        date: String,
        generalType: String?
    ): LiveData<FotoSaveResponse> {
        val data = MutableLiveData<FotoSaveResponse>()

        val dialog = ProgressDialog(context)
        dialog.show()
        fleetRepository?.savePhoto(map)?.observeForever {
            it?.let {
                dialog.dismiss()
                if (generalType == "Main") {
                    getCalenderModelEventDetail(context, event_id, date, true)
                } else {
                    data.value = it
                }

//                getCalenderModelEventDetail(context, event_id, date, true)
            }
        }
        return data
    }

    fun saveMainFoto(
        context: AppCompatActivity, map: ArrayMap<String?, Any?>,
        event_id: Int,
        date: String
    ) {
        val saveData = MutableLiveData<CommonResponse>()
        val dialog = ProgressDialog(context)
        dialog.show()
        fleetRepository?.saveFotoCarrozzeria(map)?.observeForever {
            it?.let {
                dialog.dismiss()
                getCalenderModelEventDetail(context, event_id, date, true)
                saveData.value = it
            }
        }
    }

    fun deleteWorkSteps(
        context: AppCompatActivity,
        fromScreen: String,
        event_id: Int,
        date: String,
        map: ArrayMap<String?, Any?>
    ) {
        if (Constant.isOnline(context)) {
            val dialog = ProgressDialog(context)
            dialog.show()
            fleetRepository?.deleteRecord(map)?.observeForever {
                dialog.dismiss()
                Toast.makeText(context, it?.msg, Toast.LENGTH_SHORT).show()
                if (fromScreen == Constant.FROM_TIME_KEY) {
                    getTimeModelEventDetail(context, event_id)
                } else {
                    getCalenderModelEventDetail(context, event_id, date, true)
                }
            }
        } else {
            Toast.makeText(context, context.getString(R.string.offline), Toast.LENGTH_SHORT)
                .show()
        }
    }

    fun changeQty(
        context: AppCompatActivity,
        event_id: Int,
        date: String,
        map: ArrayMap<String?, Any?>?
    ) {
        val dialog = ProgressDialog(context)
        dialog.show()
        fleetRepository?.changeQty(map)?.observeForever {
            dialog.dismiss()
            getCalenderModelEventDetail(context, event_id, date, true)
        }
    }

    fun chiudiLavorazioneClick(
        context: AppCompatActivity,
        event_id: Int,
        date: String,
        map: ArrayMap<String?, Any?>
    ) {
        val dialog = ProgressDialog(context)
        dialog.show()
        fleetRepository?.chiudiLavorazioneClick(map)?.observeForever {
            Toast.makeText(context, it!!.msg, Toast.LENGTH_SHORT).show()
            dialog.dismiss()
            getCalenderModelEventDetail(context, event_id, date, true)
        }
    }

    fun reOpenEvent(
        context: AppCompatActivity,
        event_id: Int,
        date: String,
        map: ArrayMap<String?, Any?>
    ) {
        val dialog = ProgressDialog(context)
        dialog.show()
        fleetRepository?.reOpenEvent(map)?.observeForever {
            Toast.makeText(context, it?.msg, Toast.LENGTH_SHORT).show()

            dialog.dismiss()
            getCalenderModelEventDetail(context, event_id, date, true)
        }
    }

    fun singleLeadCloseDay(context: AppCompatActivity, map: ArrayMap<String?, Any?>) {
        val dialog = ProgressDialog(context)
        dialog.show()
        fleetRepository?.singleLeadCloseDay(map)?.observeForever {
            dialog.dismiss()
            postWorkChanged2.value = it?.code
        }
    }

}