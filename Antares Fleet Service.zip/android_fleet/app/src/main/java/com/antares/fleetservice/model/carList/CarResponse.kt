package com.antares.fleetservice.model.carList

import com.google.gson.annotations.SerializedName

data class CarResponse(
    @SerializedName("code"  )   var     code    : Int? = null,
    @SerializedName("json"  )   var     json    : CarJson? = CarJson()
)