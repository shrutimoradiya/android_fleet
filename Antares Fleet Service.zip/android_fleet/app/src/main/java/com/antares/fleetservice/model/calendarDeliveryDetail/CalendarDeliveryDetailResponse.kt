package com.antares.fleetservice.model.calendarDeliveryDetail

import com.google.gson.annotations.SerializedName

data class CalendarDeliveryDetailResponse(
    @SerializedName("code"  )   var     code    : Int? = null,
    @SerializedName("json"  )   var     json    : CalendarDeliveryDetailJson? = CalendarDeliveryDetailJson()
)