package com.antares.fleetservice.model.models

import com.google.gson.annotations.SerializedName

data class ModelsResponse(
    @SerializedName("code"  )   var     code    : Int? = null,
    @SerializedName("json"  )   var     json    : ModelsJson? = ModelsJson()
)